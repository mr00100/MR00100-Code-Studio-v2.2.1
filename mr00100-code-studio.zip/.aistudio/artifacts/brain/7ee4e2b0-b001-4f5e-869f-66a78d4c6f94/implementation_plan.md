# MR00100 Code Studio

MR00100 Code Studio is a complete, high-performance web-based IDE engineered for modern web developers. It provides real-time syntax highlighting, multi-tab code editing, an interactive terminal, seamless cloud synchronization, a complete visual Git version control interface, language extension modules, and an automated deployment pipeline to take projects from code to live preview and production.

## User Review & Critical Decisions

> [!IMPORTANT]
> The architectural directions below synthesize the initial requirements and the user's request for Git version control integration. Review these decisions before proceeding:

- **Confirmed Decision 1: Git Version Control Integration**: A full-featured Source Control panel is integrated alongside the project explorer. Developers can initialize repositories, view file status badges (Modified, Untracked, Staged, Deleted), stage/unstage individual or all changes, craft commit messages with history, switch/create branches, and trigger remote push and pull actions with real-time feedback and diff viewer.
- **Confirmed Decision 2: Project Starter & Template Architecture**: The IDE loads with an interactive React + TypeScript + Tailwind modern web application workspace, with instant one-click switching to HTML5/JS Sandbox, Full-stack REST API, or Custom Empty Workspace.
- **Confirmed Decision 3: Visual Identity & Styling**: VS Code Modern Dark theme paired with crisp cyan/indigo accents, JetBrains Mono font rendering for code, single-elevation panels, and zero-pill typographic metadata hierarchy.
- **Confirmed Decision 4: In-Browser Execution & Deployment Pipeline**: Instant live preview sandbox running in a sandboxed iframe with hot reload on save/edit, paired with an interactive terminal supporting custom scripts (`npm run build`, `npm run dev`, `git status`, `git commit`, `curl`, `tree`, `lint`) and an automated deployment pipeline supporting simulated production builds for Vercel, Netlify, and Google Cloud Run.

---

## 1. Overview & Core Concept

- **What It Does**: MR00100 Code Studio gives developers an all-in-one browser workstation to write, refactor, lint, debug, version-control with Git, preview, and deploy modern web applications.
- **Target Audience / Persona**: Frontend and full-stack web developers, students, and software engineers who need a zero-install, responsive, and robust development environment on any machine or tablet.
- **Key Value**: Delivers the tactile precision and keyboard workflows of desktop VS Code directly in the browser—complete with file tree management, syntax coloration, split preview, terminal simulation, Git branching & commits, and deployment automation.

---

## 2. User Experience & Visual Design

### Key User Flows

1. **Workspace Navigation & File Management**:
   - Activity Bar on the far left lets users toggle between Explorer, Search across files, Source Control (Git), Debugger & Linting, Extensions Marketplace, and Deployment Pipeline.
   - File Explorer provides nested directory trees, quick file creation (`.ts`, `.tsx`, `.css`, `.json`, `.md`, `.html`), file renaming, deletion, and template imports.
2. **Editing, Refactoring & Code Intelligence**:
   - Tabbed editor with active indicators, close buttons, and dirty-file status dots.
   - Line numbering, active line highlight, syntax token coloring (keywords, strings, functions, comments, tags), bracket matching, and indentation guides.
   - Code toolbar offering Quick Actions: Format Document (Prettier-style), Rename Symbol, Extract Variable, Toggle Word Wrap, and Run Linter.
3. **Integrated Git Version Control**:
   - Visual Git workbench showing current branch (`main`), commit input box with keyboard shortcut (`Ctrl/Cmd + Enter`), Staged Changes and Changes sections.
   - Quick stage (`+`) / unstage (`-`) and discard buttons per file.
   - Visual Diff Inspector showing side-by-side or inline additions and deletions.
   - Branch manager modal with branch creation and checkout.
   - Push and Pull buttons with interactive remote synchronization logs.
4. **Interactive Terminal & Debug Console**:
   - Bottom panel with tabs for **Terminal**, **Output / Build Logs**, **Problems & Lint**, and **Debugger**.
   - Interactive shell with command history, autocomplete, standard commands (`ls`, `cat`, `mkdir`, `touch`, `rm`, `git`, `npm run`, `node`, `clear`, `deploy`, `status`).
   - Problems panel flagging syntax warnings and lint recommendations with direct jump-to-line capability.
   - Debugger with variable watch expressions, call stack simulation, and execution controls (Play, Step Over, Step In, Restart).
5. **Real-Time Sandbox & Automated Deployment**:
   - Real-time preview panel rendering the user's HTML/React output with viewport switcher (Desktop, Tablet, Mobile) and console log interceptor.
   - Deployment pipeline view with build validation, artifact bundle generator, environment variable configuration, and one-click deployment targets (Vercel, Netlify, Cloud Run) with step-by-step progress and live URL generation.
6. **Cloud Synchronization & Extensions Ecosystem**:
   - Cloud sync manager offering local browser storage persistence, JSON workspace export/import, and simulated cloud sync with commit timestamps.
   - Extension marketplace with toggleable add-ons: Themes (Tokyo Night, Monokai, SynthWave), Snippet Packs, Language Parsers (TypeScript, Python, Markdown, Tailwind CSS InteliSense), and Keybinding profiles.

### Visual Identity & Theme

- **Aesthetic Direction**: Technical, utilitarian, and ergonomic IDE aesthetic inspired by modern VS Code, eliminating unnecessary decoration and prioritizing focus and code readability.
- **Color Palette**:
  - Dominant Canvas: Deep slate `#0B0F19` (Activity bar: `#070A10`, Sidebar: `#0E1424`, Editor: `#0B0F19`, Bottom bar: `#0A0D16`).
  - Structural Surfaces: Hairline borders `#1E293B`, subtle hover fills `#1E293B/50`.
  - Accent Tones: Electric Cyan `#06B6D4` (focus rings, active tabs, primary actions), Emerald `#10B981` (Git staged / additions / build success), Amber `#F59E0B` (warnings / modified files), Crimson `#EF4444` (errors / deletions).
- **Typography & Hierarchy**:
  - Code & Telemetry: `JetBrains Mono` / monospace with `tabular-nums` for line numbers, timestamps, and terminal output.
  - UI Prose: `Plus Jakarta Sans` / clean geometric sans for navigation labels, menus, and inspector panels.
  - Anti-slop: Unboxed typographic metadata with subtle `·` separators, zero pill badges on cards.
- **Interactive Feedback & Motion**:
  - Micro-interactions $\le 150\text{ms}$ for tab switching, tree collapsing, and panel resizing.
  - Smooth terminal scrolling and real-time keystroke rendering.

---

## 3. Key Product Decisions & Trade-Offs

- **Decision 1: Client-Side Virtual File System & State Engine**:
  - *Chosen Approach*: In-memory reactive virtual file system backed by `localStorage` persistence with export/import capabilities and automated change diffing.
  - *Why*: Ensures zero latency, offline capability, instantaneous file reads/writes, and hermetic reliability inside the AI Studio container without requiring external database dependencies.
  - *Alternatives Considered*: Backend disk persistence—adds network latency and risk of sync conflicts when running in web containers.
- **Decision 2: Comprehensive Syntax Highlighting & Tokenizer**:
  - *Chosen Approach*: Lightweight, performant regex-based multi-language tokenizer supporting TypeScript, JavaScript, HTML, CSS, JSON, and Markdown with line-by-line memoization.
  - *Why*: Instant startup, zero heavy bundle dependencies (avoiding multi-megabyte Monaco webworker setup issues), full control over theme coloring, selection, and line number synchronization.
- **Decision 3: Integrated Git State Machine**:
  - *Chosen Approach*: Embedded visual Git engine tracking file snapshots, staged set, commit DAG, branch references, and remote simulation.
  - *Why*: Gives users authentic Git workflows (staging changes, atomic commits, diff inspection, push/pull status) directly within the IDE UI as explicitly requested.

---

## 4. Technical Architecture & Data Strategy

```
┌────────────────────────────────────────────────────────────────────────┐
│                        MR00100 Code Studio Top Bar                     │
│  [Logo/Wordmark] · [Project Title] · [Branch: main] · [Cloud: Synced]  │
│  [Run/Preview]  [Quick Format]  [Deploy Pipeline]  [Settings]          │
└────────────────────────────────────────────────────────────────────────┘
┌──────┬─────────────────┬───────────────────────────────┬───────────────┐
│ ACT- │ SIDEBAR PANEL   │ EDITOR WORKSPACE              │ LIVE PREVIEW  │
│ IVITY│ (Contextual):   │                               │ & RUNTIME     │
│ BAR  │ ├─ File Tree    │ ┌───────────────────────────┐ │ ┌───────────┐ │
│      │ ├─ Git Source   │ │ Tabs: App.tsx | styles.css│ │ │ Viewport  │ │
│ [📁] │    Control      │ ├───────────────────────────┤ │ │ [Desktop] │ │
│ [🔍] │ ├─ Search/Diff  │ │ [Line#] Real-time Syntax  │ │ │           │ │
│ [🌿] │ ├─ Extensions   │ │         Highlighted Code  │ │ │ Sandboxed │ │
│ [🐛] │ ├─ Deploy Hub   │ │         Active Cursor     │ │ │ Web App   │ │
│ [🧩] │ └─ Settings     │ │         Breakpoints       │ │ │ Preview   │ │
│ [🚀] │                 │ └───────────────────────────┘ │ └───────────┘ │
│      │                 ├───────────────────────────────┴───────────────┤
│ [⚙️] │                 │ BOTTOM CONSOLE DRAWER                         │
│      │                 │ [Terminal] [Problems] [Output] [Debugger]     │
│      │                 │ > npm run build ... Build succeeded in 240ms  │
└──────┴─────────────────┴───────────────────────────────────────────────┘
```

### Data Model & State Entities

- **`WorkspaceFile`**: `{ id, path, name, extension, content, isDirty, isBinary }`
- **`GitState`**: `{ currentBranch, branches, stagedFiles, modifiedFiles, untrackedFiles, commits: [{ hash, message, author, timestamp, changes }], remoteUrl, isAhead, isBehind }`
- **`ExtensionModule`**: `{ id, name, category, author, version, description, icon, enabled, config }`
- **`DeploymentTarget`**: `{ id, name, provider ('vercel' | 'netlify' | 'cloudrun'), status ('idle' | 'building' | 'deployed' | 'failed'), liveUrl, logs: string[], lastDeployedAt }`
- **`LinterDiagnostic`**: `{ file, line, column, severity ('error' | 'warning' | 'info'), message, rule }`
- **`TerminalSession`**: `{ history, commandHistory, cwd, environmentVars }`

### Interactive Component & State Mapping

- **File Tree Interactions**: Click file $\rightarrow$ activates editor tab; right-click / menu $\rightarrow$ new file, new folder, rename, delete; drag/reorder.
- **Editor Keystrokes**: Typing updates buffer in real-time, calculates dirty status, triggers syntax tokenizer and diagnostic evaluation debounced at $300\text{ms}$.
- **Git Actions**:
  - `Stage File (+)`: Moves file path from modified to staged set.
  - `Commit`: Validates non-empty message and non-empty staged set, writes new commit node, updates HEAD, resets staged files.
  - `Branch Switch`: Loads file tree state corresponding to selected branch.
  - `Push / Pull`: Simulates remote repository sync, updates local ahead/behind counters.
- **Terminal Execution**: Interprets parsed CLI arguments, executes commands against virtual file system or runtime engines, appends structured ANSI/styled lines to terminal buffer.
- **Deploy Pipeline**: Validates project dependencies and syntax $\rightarrow$ simulates multi-stage build logs $\rightarrow$ provisions live sandbox URL with copy link and inspect options.
