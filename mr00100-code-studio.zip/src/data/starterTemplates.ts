import { ProjectTemplate } from '../types';

export const STARTER_TEMPLATES: ProjectTemplate[] = [
  {
    id: 'multi-lang',
    name: 'Multi-Language Project',
    description: 'Workspace ready for Python, JavaScript, HTML, C++, and more.',
    badge: 'Universal',
    icon: 'Code',
    files: [
      {
        id: 'file-py',
        name: 'main.py',
        path: 'main.py',
        language: 'python',
        content: `# Python 3 Script in MR00100 Code Studio
def greet(name):
    return f"Hello, {name}! Welcome to MR00100 Code Studio."

def calculate_stats(numbers):
    total = sum(numbers)
    count = len(numbers)
    avg = total / count if count > 0 else 0
    return {"total": total, "average": avg, "max": max(numbers), "min": min(numbers)}

# Run program
print(greet("Developer"))

dataset = [15, 28, 42, 99, 104, 33]
stats = calculate_stats(dataset)
print("Data Analysis:", stats)

print("Running loop demonstration:")
for i in range(5):
    print(f"  Step {i + 1}: Status OK")
`,
      },
      {
        id: 'file-js',
        name: 'index.js',
        path: 'index.js',
        language: 'javascript',
        content: `// JavaScript Execution in MR00100 Studio
console.log("⚡ JavaScript Runtime Online");

function fibonacci(n) {
  const seq = [0, 1];
  for (let i = 2; i < n; i++) {
    seq.push(seq[i - 1] + seq[i - 2]);
  }
  return seq;
}

const numbers = fibonacci(10);
console.log("Fibonacci Sequence (first 10):", numbers.join(", "));
console.log("Timestamp:", new Date().toLocaleTimeString());
`,
      },
      {
        id: 'file-html',
        name: 'index.html',
        path: 'index.html',
        language: 'html',
        content: `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Live Server Preview</title>
  <style>
    body {
      margin: 0;
      min-height: 100vh;
      background: #090d16;
      color: #f1f5f9;
      font-family: system-ui, -apple-system, sans-serif;
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 20px;
    }
    .card {
      background: #111827;
      border: 1px solid #1f2937;
      border-radius: 16px;
      padding: 32px;
      max-width: 480px;
      text-align: center;
      box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.7);
    }
    h1 { margin: 0 0 10px 0; color: #38bdf8; font-size: 24px; font-weight: 700; }
    p { margin: 0 0 20px 0; color: #9ca3af; font-size: 14px; line-height: 1.5; }
    button {
      background: #0ea5e9;
      color: #030712;
      border: none;
      padding: 10px 24px;
      font-size: 14px;
      font-weight: 600;
      border-radius: 10px;
      cursor: pointer;
      transition: all 0.2s;
    }
    button:hover { background: #38bdf8; transform: translateY(-1px); }
  </style>
</head>
<body>
  <div class="card">
    <h1>🌐 Live Server Running</h1>
    <p>Your code is live on port 5500 with instant hot reload. Change HTML or CSS to see updates in real-time.</p>
    <button onclick="alert('Live Server is working perfectly!')">Test Interactive Event</button>
  </div>
</body>
</html>
`,
      },
    ],
  },
  {
    id: 'clean-react-app',
    name: 'React 19 Web App',
    description: 'Clean React 19 single-file application ready for your code.',
    badge: 'React',
    icon: 'Atom',
    files: [
      {
        id: 'file-react-demo',
        name: 'react_demo.jsx',
        path: 'react_demo.jsx',
        language: 'jsx',
        content: `import React, { useState } from 'react';

export default function App() {
  const [count, setCount] = useState(0);

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col items-center justify-center p-6 select-none font-sans">
      <div className="max-w-md w-full bg-slate-900 border border-slate-800 rounded-2xl p-8 text-center space-y-5 shadow-2xl">
        <div className="w-12 h-12 mx-auto rounded-xl bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400 font-bold text-xl">
          ⚡
        </div>
        
        <div>
          <h1 className="text-xl font-bold tracking-tight text-white">MR00100 Code Studio</h1>
          <p className="text-xs text-slate-400 mt-1">Live Sandbox active &bull; Press Run or Ctrl+S</p>
        </div>

        <div className="py-2">
          <button
            onClick={() => setCount(prev => prev + 1)}
            className="px-5 py-2.5 bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-semibold text-sm rounded-xl transition-all shadow-lg shadow-cyan-500/20 active:scale-95 cursor-pointer"
          >
            Count is: {count}
          </button>
        </div>

        <div className="text-[11px] text-slate-500 font-mono">
          Ready for your code in any language
        </div>
      </div>
    </div>
  );
}
`,
      },
    ],
  },
  {
    id: 'empty-workspace',
    name: 'Empty Workspace',
    description: 'Completely blank workspace with zero default files. Build from scratch.',
    badge: 'Blank',
    icon: 'FilePlus',
    files: [],
  }
];
