import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { TopBar } from './components/Navigation/TopBar';
import { ActivityBar, SidebarTab } from './components/Sidebar/ActivityBar';
import { FileExplorer } from './components/Sidebar/FileExplorer';
import { SourceControl } from './components/Sidebar/SourceControl';
import { GlobalSearch } from './components/Sidebar/GlobalSearch';
import { DebuggerPanel } from './components/Sidebar/DebuggerPanel';
import { ExtensionsMarketplace } from './components/Sidebar/ExtensionsMarketplace';
import { DeploymentPipeline } from './components/Sidebar/DeploymentPipeline';
import { CodeEditor } from './components/Editor/CodeEditor';
import { LivePreview } from './components/Preview/LivePreview';
import { InteractiveTerminal } from './components/Terminal/InteractiveTerminal';
import { DiffViewerModal } from './components/Modals/DiffViewerModal';
import { CommandPalette, CommandItem } from './components/Modals/CommandPalette';
import { QuickOpenModal } from './components/Modals/QuickOpenModal';
import { SettingsModal } from './components/Modals/SettingsModal';
import { CloudSyncModal } from './components/Modals/CloudSyncModal';
import { StatusBar } from './components/Status/StatusBar';

import { 
  WorkspaceFile, 
  EditorTab, 
  GitState, 
  Breakpoint, 
  ExtensionModule, 
  DeploymentTarget, 
  EditorSettings, 
  ProjectTemplate 
} from './types';
import { STARTER_TEMPLATES } from './data/starterTemplates';
import { INITIAL_EXTENSIONS } from './data/extensions';
import { lintWorkspaceFile } from './utils/linter';
import { formatCode } from './utils/refactoring';
import { downloadProjectAsZip } from './utils/zipExport';
import { 
  Wand2, 
  Terminal, 
  Eye, 
  Rocket, 
  GitBranch, 
  ArrowUp, 
  ArrowDown, 
  Palette, 
  Settings, 
  Download,
  Trash2
} from 'lucide-react';

const STORAGE_KEY_FILES = 'mr00100_workspace_files_v2';
const STORAGE_KEY_GIT = 'mr00100_git_state_v2';
const STORAGE_KEY_SETTINGS = 'mr00100_editor_settings_v2';
const STORAGE_KEY_EXTENSIONS = 'mr00100_extensions_v2';

export default function App() {
  // Templates state
  const [currentTemplate, setCurrentTemplate] = useState<ProjectTemplate>(STARTER_TEMPLATES[0]);
  
  // Clean workspace files
  const [files, setFiles] = useState<WorkspaceFile[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_FILES);
      if (saved) return JSON.parse(saved);
    } catch {
      // fallback
    }
    return STARTER_TEMPLATES[0].files;
  });

  // Track original snapshot for Git change detection
  const [baseFilesSnapshot, setBaseFilesSnapshot] = useState<Record<string, string>>(() => {
    const map: Record<string, string> = {};
    STARTER_TEMPLATES[0].files.forEach(f => {
      map[f.path] = f.content;
    });
    return map;
  });

  // Open tabs
  const [openTabs, setOpenTabs] = useState<EditorTab[]>(() => {
    if (STARTER_TEMPLATES[0].files.length > 0) {
      return [{
        fileId: STARTER_TEMPLATES[0].files[0].id,
        filePath: STARTER_TEMPLATES[0].files[0].path,
        fileName: STARTER_TEMPLATES[0].files[0].name,
      }];
    }
    return [];
  });
  const [activeFileId, setActiveFileId] = useState<string | null>(() => {
    return STARTER_TEMPLATES[0].files.length > 0 ? STARTER_TEMPLATES[0].files[0].id : null;
  });

  // Sidebar navigation
  const [activeSidebarTab, setActiveSidebarTab] = useState<SidebarTab | null>('explorer');

  // Preview & Terminal drawers (closed by default for a clean, spacious VS Code workspace)
  const [isPreviewOpen, setIsPreviewOpen] = useState(false);
  const [previewViewport, setPreviewViewport] = useState<'desktop' | 'tablet' | 'mobile'>('desktop');
  const [isTerminalOpen, setIsTerminalOpen] = useState(false);
  const [isLiveServerRunning, setIsLiveServerRunning] = useState(false);
  const [terminalForcedTab, setTerminalForcedTab] = useState<'terminal' | 'problems' | 'output' | 'debug'>('terminal');
  const [terminalCommandToRun, setTerminalCommandToRun] = useState<string | null>(null);

  // Settings
  const [settings, setSettings] = useState<EditorSettings>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_SETTINGS);
      if (saved) return JSON.parse(saved);
    } catch {
      // fallback
    }
    return {
      fontSize: 14,
      tabSize: 2,
      theme: 'vs-dark',
      wordWrap: true,
      minimap: false,
      lineNumbers: true,
      autoSave: true,
      fontFamily: 'JetBrains Mono',
    };
  });

  // Extensions
  const [extensions, setExtensions] = useState<ExtensionModule[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_EXTENSIONS);
      if (saved) return JSON.parse(saved);
    } catch {
      // fallback
    }
    return INITIAL_EXTENSIONS;
  });

  // Git State
  const [gitState, setGitState] = useState<GitState>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_GIT);
      if (saved) return JSON.parse(saved);
    } catch {
      // fallback
    }
    return {
      isInitialized: true,
      currentBranch: 'main',
      branches: [
        { name: 'main', isCurrent: true, commitHash: 'c7a912d' },
      ],
      stagedFiles: [],
      commits: [
        {
          hash: 'c7a912d',
          message: 'feat: initialize MR00100 Code Studio workspace',
          author: 'MR00100 Developer',
          timestamp: 'Just now',
          filesChanged: ['src/App.tsx'],
        },
      ],
      remoteUrl: 'git@github.com:mr00100/code-studio-app.git',
      isPushing: false,
      isPulling: false,
      aheadCount: 0,
      behindCount: 0,
      lastSyncedAt: 'Just now',
    };
  });

  // Breakpoints
  const [breakpoints, setBreakpoints] = useState<Breakpoint[]>([
    { id: 'bp-1', file: 'src/App.tsx', line: 4, enabled: true },
  ]);

  // Deployment targets
  const [deploymentTargets, setDeploymentTargets] = useState<DeploymentTarget[]>([
    {
      id: 'vercel',
      name: 'Vercel Edge',
      provider: 'vercel',
      status: 'idle',
      liveUrl: 'https://mr00100-app.vercel.app',
      lastDeployedAt: 'Ready to deploy',
      logs: [
        'Vercel CLI 34.2.1 initialized',
        'Edge middleware routing active',
      ],
      envVars: [
        { key: 'VITE_API_ENDPOINT', value: 'https://api.mr00100.dev' },
        { key: 'NODE_ENV', value: 'production' },
      ],
    },
    {
      id: 'netlify',
      name: 'Netlify Global',
      provider: 'netlify',
      status: 'idle',
      liveUrl: 'https://mr00100-app.netlify.app',
      logs: ['Netlify Build System ready.'],
      envVars: [{ key: 'SITE_ID', value: 'mr00100-prod-net' }],
    },
    {
      id: 'cloudrun',
      name: 'Google Cloud Run',
      provider: 'cloudrun',
      status: 'idle',
      liveUrl: 'https://mr00100-service-804930491465.asia-east1.run.app',
      logs: ['Google Artifact Registry cache warm.'],
      envVars: [{ key: 'PORT', value: '8080' }],
    },
  ]);

  // Modals state
  const [isDiffModalOpen, setIsDiffModalOpen] = useState(false);
  const [diffTargetFile, setDiffTargetFile] = useState<WorkspaceFile | null>(null);
  const [isCommandPaletteOpen, setIsCommandPaletteOpen] = useState(false);
  const [isQuickOpenOpen, setIsQuickOpenOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isCloudSyncOpen, setIsCloudSyncOpen] = useState(false);
  const [lastCloudSyncText, setLastCloudSyncText] = useState('Synced seconds ago');

  // Auto-Save
  useEffect(() => {
    if (settings.autoSave) {
      localStorage.setItem(STORAGE_KEY_FILES, JSON.stringify(files));
      localStorage.setItem(STORAGE_KEY_GIT, JSON.stringify(gitState));
      localStorage.setItem(STORAGE_KEY_SETTINGS, JSON.stringify(settings));
      localStorage.setItem(STORAGE_KEY_EXTENSIONS, JSON.stringify(extensions));
    }
  }, [files, gitState, settings, extensions]);

  // Compute modified status against base snapshot
  useEffect(() => {
    setFiles(prevFiles =>
      prevFiles.map(f => {
        const originalContent = baseFilesSnapshot[f.path];
        const isModified = originalContent !== undefined && originalContent !== f.content;
        return f.isModified !== isModified ? { ...f, isModified } : f;
      })
    );
  }, [baseFilesSnapshot]);

  // Diagnostics
  const isEslintEnabled = extensions.find(e => e.id === 'ext-eslint')?.enabled ?? true;
  const allDiagnostics = useMemo(() => {
    if (!isEslintEnabled) return [];
    return files.flatMap(f => lintWorkspaceFile(f));
  }, [files, isEslintEnabled]);

  // Active file change
  const handleContentChange = useCallback((fileId: string, newContent: string) => {
    setFiles(prev =>
      prev.map(f => {
        if (f.id === fileId) {
          return {
            ...f,
            content: newContent,
            isModified: baseFilesSnapshot[f.path] !== newContent,
          };
        }
        return f;
      })
    );

    setOpenTabs(prev =>
      prev.map(t => (t.fileId === fileId ? { ...t, isDirty: true } : t))
    );
  }, [baseFilesSnapshot]);

  // Save active file
  const handleSaveFile = useCallback((fileId: string) => {
    setOpenTabs(prev =>
      prev.map(t => (t.fileId === fileId ? { ...t, isDirty: false } : t))
    );
    setLastCloudSyncText(`Saved at ${new Date().toLocaleTimeString()}`);
  }, []);

  // Format active document
  const handleFormatDocument = useCallback(() => {
    if (!activeFileId) return;
    const file = files.find(f => f.id === activeFileId);
    if (!file) return;

    const formatted = formatCode(file.content, file.language);
    handleContentChange(file.id, formatted);
  }, [activeFileId, files, handleContentChange]);

  // Toast notification for user actions (VS Code notification pill)
  const [notificationToast, setNotificationToast] = useState<{ message: string; type: 'info' | 'success' | 'live' } | null>(null);

  const showToast = useCallback((message: string, type: 'info' | 'success' | 'live' = 'info') => {
    setNotificationToast({ message, type });
    setTimeout(() => {
      setNotificationToast(prev => (prev?.message === message ? null : prev));
    }, 3500);
  }, []);

  // Download project as ZIP
  const handleDownloadZip = useCallback(() => {
    downloadProjectAsZip(files, currentTemplate.name);
    showToast('Project ZIP downloaded successfully!', 'success');
  }, [files, currentTemplate.name, showToast]);

  // Run Code execution handler (Live Server vs Terminal)
  const handleRunCode = useCallback((mode: 'live-server' | 'terminal') => {
    const activeFile = files.find(f => f.id === activeFileId) || (files.length > 0 ? files[0] : null);

    if (mode === 'live-server') {
      setIsLiveServerRunning(true);
      setIsPreviewOpen(true);
      const targetName = activeFile ? activeFile.name : 'sandbox';
      showToast(`Live Server active on port 5500 • Running ${targetName}`, 'live');
    } else {
      setIsTerminalOpen(true);
      setTerminalForcedTab('terminal');
      if (activeFile) {
        const ext = activeFile.name.toLowerCase();
        let cmd = `run ${activeFile.name}`;
        if (ext.endsWith('.py')) cmd = `python3 ${activeFile.path}`;
        else if (ext.endsWith('.js')) cmd = `node ${activeFile.path}`;
        else if (ext.endsWith('.ts')) cmd = `ts-node ${activeFile.path}`;
        else if (ext.endsWith('.c')) cmd = `gcc ${activeFile.path} -o main && ./main`;
        else if (ext.endsWith('.cpp')) cmd = `g++ ${activeFile.path} -o main && ./main`;
        else if (ext.endsWith('.java')) cmd = `javac ${activeFile.path} && java Main`;
        else if (ext.endsWith('.rs')) cmd = `rustc ${activeFile.path} -o main && ./main`;
        else if (ext.endsWith('.go')) cmd = `go run ${activeFile.path}`;
        else if (ext.endsWith('.php')) cmd = `php ${activeFile.path}`;
        else if (ext.endsWith('.rb')) cmd = `ruby ${activeFile.path}`;
        else if (ext.endsWith('.sh')) cmd = `bash ${activeFile.path}`;
        else if (ext.endsWith('.sql')) cmd = `sqlite3 :memory: < ${activeFile.path}`;

        setTerminalCommandToRun(cmd);
        showToast(`Executing in terminal: ${cmd}`, 'info');
      } else {
        setTerminalCommandToRun('run');
        showToast('Executing code in terminal...', 'info');
      }
    }
  }, [files, activeFileId, showToast]);

  // Language switch handler
  const handleSelectLanguage = useCallback((newLang: string) => {
    if (!activeFileId) return;
    setFiles(prev =>
      prev.map(f => (f.id === activeFileId ? { ...f, language: newLang } : f))
    );
    showToast(`Language set to ${newLang.toUpperCase()}`, 'info');
  }, [activeFileId, showToast]);

  // Toggle Live Server status
  const handleToggleLiveServer = useCallback(() => {
    setIsLiveServerRunning(prev => {
      const next = !prev;
      if (next) {
        setIsPreviewOpen(true);
      }
      return next;
    });
  }, []);

  // Create file with smart language support
  const handleCreateFile = useCallback((filePath: string) => {
    const parts = filePath.split('/');
    const name = parts[parts.length - 1];
    const lower = name.toLowerCase();

    let language = 'javascript';
    let content = `// ${name}\n`;

    if (lower.endsWith('.py')) {
      language = 'python';
      content = `# ${name}\ndef main():\n    print("Hello from Python 3!")\n\nif __name__ == "__main__":\n    main()\n`;
    } else if (lower.endsWith('.c') || lower.endsWith('.h')) {
      language = 'c';
      content = `// ${name}\n#include <stdio.h>\n\nint main() {\n    printf("Hello from C!\\n");\n    return 0;\n}\n`;
    } else if (lower.endsWith('.cpp') || lower.endsWith('.cc')) {
      language = 'cpp';
      content = `// ${name}\n#include <iostream>\n\nint main() {\n    std::cout << "Hello from C++20!" << std::endl;\n    return 0;\n}\n`;
    } else if (lower.endsWith('.java')) {
      language = 'java';
      content = `// ${name}\npublic class Main {\n    public static void main(String[] args) {\n        System.out.println("Hello from Java 21!");\n    }\n}\n`;
    } else if (lower.endsWith('.rs')) {
      language = 'rust';
      content = `// ${name}\nfn main() {\n    println!("Hello from Rust!");\n}\n`;
    } else if (lower.endsWith('.go')) {
      language = 'go';
      content = `// ${name}\npackage main\n\nimport "fmt"\n\nfunc main() {\n    fmt.Println("Hello from Go!")\n}\n`;
    } else if (lower.endsWith('.php')) {
      language = 'php';
      content = `<?php\n// ${name}\necho "Hello from PHP 8!\\n";\n`;
    } else if (lower.endsWith('.rb')) {
      language = 'ruby';
      content = `# ${name}\nputs "Hello from Ruby 3!"\n`;
    } else if (lower.endsWith('.sh') || lower.endsWith('.bash')) {
      language = 'bash';
      content = `#!/usr/bin/env bash\n# ${name}\necho "Hello from Bash shell!"\n`;
    } else if (lower.endsWith('.sql')) {
      language = 'sql';
      content = `-- ${name}\nCREATE TABLE demo (id INTEGER PRIMARY KEY, title TEXT);\nINSERT INTO demo (title) VALUES ('First Record');\nSELECT * FROM demo;\n`;
    } else if (lower.endsWith('.html') || lower.endsWith('.htm')) {
      language = 'html';
      content = `<!DOCTYPE html>\n<html lang="en">\n<head>\n  <meta charset="UTF-8">\n  <title>${name}</title>\n</head>\n<body>\n  <h1>${name}</h1>\n  <p>Live preview ready.</p>\n</body>\n</html>\n`;
    } else if (lower.endsWith('.css')) {
      language = 'css';
      content = `/* ${name} */\nbody {\n  margin: 0;\n  padding: 20px;\n  background: #0f172a;\n  color: #f8fafc;\n}\n`;
    } else if (lower.endsWith('.tsx') || lower.endsWith('.jsx')) {
      language = 'tsx';
      const compName = name.replace(/\.[^/.]+$/, '').replace(/[^a-zA-Z0-9]/g, '');
      content = `import React, { useState } from 'react';\n\nexport default function ${compName || 'Component'}() {\n  const [value, setValue] = useState("Active");\n  return (\n    <div className="p-6 bg-slate-900 text-white rounded-xl">\n      <h2 className="text-lg font-bold">${compName || 'Component'}</h2>\n      <p className="text-slate-400 mt-2">Status: {value}</p>\n    </div>\n  );\n}\n`;
    } else if (lower.endsWith('.json')) {
      language = 'json';
      content = `{\n  "name": "${name.replace(/\.[^/.]+$/, '')}",\n  "version": "1.0.0"\n}\n`;
    } else if (lower.endsWith('.md')) {
      language = 'markdown';
      content = `# ${name}\n\nDocumentation and notes.\n`;
    } else if (lower.endsWith('.ts')) {
      language = 'typescript';
      content = `// ${name}\nconst greeting: string = "Hello TypeScript";\nconsole.log(greeting);\n`;
    } else if (lower.endsWith('.js')) {
      language = 'javascript';
      content = `// ${name}\nconsole.log("Hello from JavaScript");\n`;
    }

    const newFile: WorkspaceFile = {
      id: `file-${Date.now()}`,
      name,
      path: filePath,
      content,
      language,
      isModified: true,
    };

    setFiles(prev => [...prev, newFile]);
    setOpenTabs(prev => [...prev, { fileId: newFile.id, fileName: newFile.name, filePath: newFile.path, isDirty: true }]);
    setActiveFileId(newFile.id);
  }, []);

  // Delete file
  const handleDeleteFile = useCallback((fileId: string) => {
    setFiles(prev => prev.filter(f => f.id !== fileId));
    setOpenTabs(prev => prev.filter(t => t.fileId !== fileId));
    if (activeFileId === fileId) {
      const remaining = openTabs.filter(t => t.fileId !== fileId);
      setActiveFileId(remaining.length > 0 ? remaining[0].fileId : null);
    }
  }, [activeFileId, openTabs]);

  // Clear all files (Empty Workspace)
  const handleClearAllFiles = useCallback(() => {
    setFiles([]);
    setOpenTabs([]);
    setActiveFileId(null);
    setBaseFilesSnapshot({});
  }, []);

  // Rename file
  const handleRenameFile = useCallback((fileId: string, newPath: string) => {
    const parts = newPath.split('/');
    const name = parts[parts.length - 1];
    setFiles(prev =>
      prev.map(f => (f.id === fileId ? { ...f, path: newPath, name } : f))
    );
    setOpenTabs(prev =>
      prev.map(t => (t.fileId === fileId ? { ...t, filePath: newPath, fileName: name } : t))
    );
  }, []);

  // Tab switching and closing
  const handleSelectTab = useCallback((fileId: string) => {
    setActiveFileId(fileId);
  }, []);

  const handleCloseTab = useCallback((fileId: string) => {
    setOpenTabs(prev => {
      const nextTabs = prev.filter(t => t.fileId !== fileId);
      if (activeFileId === fileId) {
        setActiveFileId(nextTabs.length > 0 ? nextTabs[nextTabs.length - 1].fileId : null);
      }
      return nextTabs;
    });
  }, [activeFileId]);

  // Open file in editor
  const handleOpenFile = useCallback((fileId: string) => {
    const file = files.find(f => f.id === fileId);
    if (!file) return;

    if (!openTabs.some(t => t.fileId === fileId)) {
      setOpenTabs(prev => [...prev, { fileId: file.id, fileName: file.name, filePath: file.path }]);
    }
    setActiveFileId(fileId);
  }, [files, openTabs]);

  // Jump to line
  const handleSelectFileAndLine = useCallback((fileIdOrPath: string, line: number) => {
    const file = files.find(f => f.id === fileIdOrPath || f.path === fileIdOrPath);
    if (file) {
      handleOpenFile(file.id);
    }
  }, [files, handleOpenFile]);

  // --- Git Operations ---
  const handleInitRepo = useCallback(() => {
    setGitState(prev => ({
      ...prev,
      isInitialized: true,
      currentBranch: 'main',
      branches: [{ name: 'main', isCurrent: true, commitHash: 'init001' }],
    }));
  }, []);

  const handleStageFile = useCallback((filePath: string) => {
    setGitState(prev => ({
      ...prev,
      stagedFiles: Array.from(new Set([...prev.stagedFiles, filePath])),
    }));
  }, []);

  const handleUnstageFile = useCallback((filePath: string) => {
    setGitState(prev => ({
      ...prev,
      stagedFiles: prev.stagedFiles.filter(p => p !== filePath),
    }));
  }, []);

  const handleStageAll = useCallback(() => {
    const modified = files.filter(f => f.isModified).map(f => f.path);
    setGitState(prev => ({
      ...prev,
      stagedFiles: Array.from(new Set([...prev.stagedFiles, ...modified])),
    }));
  }, [files]);

  const handleUnstageAll = useCallback(() => {
    setGitState(prev => ({ ...prev, stagedFiles: [] }));
  }, []);

  const handleCommit = useCallback((message: string) => {
    const newHash = Math.random().toString(36).substring(2, 9);
    const stagedList = [...gitState.stagedFiles];

    setBaseFilesSnapshot(prev => {
      const next = { ...prev };
      files.forEach(f => {
        if (stagedList.includes(f.path)) {
          next[f.path] = f.content;
        }
      });
      return next;
    });

    setGitState(prev => ({
      ...prev,
      commits: [
        {
          hash: newHash,
          message,
          author: 'MR00100 Developer',
          timestamp: 'Just now',
          filesChanged: stagedList,
        },
        ...prev.commits,
      ],
      stagedFiles: [],
      aheadCount: prev.aheadCount + 1,
    }));
  }, [gitState.stagedFiles, files]);

  const handlePush = useCallback(() => {
    setGitState(prev => ({ ...prev, isPushing: true }));
    setTimeout(() => {
      setGitState(prev => ({
        ...prev,
        isPushing: false,
        aheadCount: 0,
        lastSyncedAt: new Date().toLocaleTimeString(),
      }));
    }, 700);
  }, []);

  const handlePull = useCallback(() => {
    setGitState(prev => ({ ...prev, isPulling: true }));
    setTimeout(() => {
      setGitState(prev => ({
        ...prev,
        isPulling: false,
        behindCount: 0,
        lastSyncedAt: new Date().toLocaleTimeString(),
      }));
    }, 700);
  }, []);

  const handleDiscardChanges = useCallback((filePath: string) => {
    const original = baseFilesSnapshot[filePath];
    if (original !== undefined) {
      setFiles(prev =>
        prev.map(f => (f.path === filePath ? { ...f, content: original, isModified: false } : f))
      );
    }
  }, [baseFilesSnapshot]);

  const handleSwitchBranch = useCallback((branchName: string) => {
    setGitState(prev => ({
      ...prev,
      currentBranch: branchName,
      branches: prev.branches.map(b => ({ ...b, isCurrent: b.name === branchName })),
    }));
  }, []);

  const handleCreateBranch = useCallback((branchName: string) => {
    setGitState(prev => ({
      ...prev,
      currentBranch: branchName,
      branches: [
        ...prev.branches.map(b => ({ ...b, isCurrent: false })),
        { name: branchName, isCurrent: true, commitHash: 'br-' + Date.now().toString(36) },
      ],
    }));
  }, []);

  const handleViewDiff = useCallback((file: WorkspaceFile) => {
    setDiffTargetFile(file);
    setIsDiffModalOpen(true);
  }, []);

  // Breakpoints
  const handleToggleBreakpoint = useCallback((file: string, line: number) => {
    setBreakpoints(prev => {
      const existing = prev.find(b => b.file === file && b.line === line);
      if (existing) {
        return prev.filter(b => !(b.file === file && b.line === line));
      } else {
        return [...prev, { id: `bp-${Date.now()}`, file, line, enabled: true }];
      }
    });
  }, []);

  const handleRemoveBreakpoint = useCallback((bpId: string) => {
    setBreakpoints(prev => prev.filter(b => b.id !== bpId));
  }, []);

  // Extensions Toggle with Immediate Effect
  const handleToggleExtension = useCallback((extId: string) => {
    setExtensions(prev =>
      prev.map(e => {
        if (e.id === extId) {
          const nextState = !e.enabled;
          // Theme toggles
          if (nextState) {
            if (e.id === 'ext-tokyo-night') setSettings(s => ({ ...s, theme: 'tokyo-night' }));
            if (e.id === 'ext-monokai-pro') setSettings(s => ({ ...s, theme: 'monokai' }));
          } else {
            // Revert to vs-dark
            if (e.category === 'theme') {
              setSettings(s => ({ ...s, theme: 'vs-dark' }));
            }
          }
          return { ...e, enabled: nextState };
        }
        return e;
      })
    );
  }, []);

  // Deployment Trigger
  const handleTriggerDeploy = useCallback((targetId: string) => {
    setDeploymentTargets(prev =>
      prev.map(t => {
        if (t.id === targetId) {
          return {
            ...t,
            status: 'building',
            logs: [
              ...t.logs,
              `[${new Date().toLocaleTimeString()}] Deployment triggered.`,
              `[${new Date().toLocaleTimeString()}] Compiling application bundle...`,
            ],
          };
        }
        return t;
      })
    );

    setTimeout(() => {
      setDeploymentTargets(prev =>
        prev.map(t => {
          if (t.id === targetId) {
            return {
              ...t,
              status: 'deploying',
              logs: [
                ...t.logs,
                `[${new Date().toLocaleTimeString()}] Deploying artifacts to global edge...`,
              ],
            };
          }
          return t;
        })
      );
    }, 1200);

    setTimeout(() => {
      setDeploymentTargets(prev =>
        prev.map(t => {
          if (t.id === targetId) {
            return {
              ...t,
              status: 'live',
              lastDeployedAt: 'Just now',
              logs: [
                ...t.logs,
                `[${new Date().toLocaleTimeString()}] ✅ Live release verified.`,
              ],
            };
          }
          return t;
        })
      );
    }, 2400);
  }, []);

  const handleAddEnvVar = useCallback((targetId: string, key: string, value: string) => {
    setDeploymentTargets(prev =>
      prev.map(t => (t.id === targetId ? { ...t, envVars: [...t.envVars, { key, value }] } : t))
    );
  }, []);

  const handleRemoveEnvVar = useCallback((targetId: string, key: string) => {
    setDeploymentTargets(prev =>
      prev.map(t =>
        t.id === targetId ? { ...t, envVars: t.envVars.filter(ev => ev.key !== key) } : t
      )
    );
  }, []);

  // Template Selection
  const handleSelectTemplate = useCallback((template: ProjectTemplate) => {
    setCurrentTemplate(template);
    setFiles(template.files);
    const map: Record<string, string> = {};
    template.files.forEach(f => {
      map[f.path] = f.content;
    });
    setBaseFilesSnapshot(map);

    if (template.files.length > 0) {
      setOpenTabs([
        { fileId: template.files[0].id, fileName: template.files[0].name, filePath: template.files[0].path },
      ]);
      setActiveFileId(template.files[0].id);
    } else {
      setOpenTabs([]);
      setActiveFileId(null);
    }
  }, []);

  // Reset workspace
  const handleResetWorkspace = useCallback(() => {
    handleSelectTemplate(currentTemplate);
  }, [currentTemplate, handleSelectTemplate]);

  // Import JSON files
  const handleImportFiles = useCallback((imported: WorkspaceFile[]) => {
    setFiles(imported);
    const map: Record<string, string> = {};
    imported.forEach(f => {
      map[f.path] = f.content;
    });
    setBaseFilesSnapshot(map);
    if (imported.length > 0) {
      setOpenTabs([
        { fileId: imported[0].id, fileName: imported[0].name, filePath: imported[0].path },
      ]);
      setActiveFileId(imported[0].id);
    }
  }, []);

  // Global Keyboard Shortcuts
  useEffect(() => {
    const handleGlobalKeyDown = (e: KeyboardEvent) => {
      const isCmdOrCtrl = e.metaKey || e.ctrlKey;

      if (isCmdOrCtrl && e.shiftKey && (e.key === 'p' || e.key === 'P')) {
        e.preventDefault();
        setIsCommandPaletteOpen(true);
      } else if (isCmdOrCtrl && (e.key === 'p' || e.key === 'P')) {
        e.preventDefault();
        setIsQuickOpenOpen(true);
      } else if (isCmdOrCtrl && (e.key === '`' || e.key === '~')) {
        e.preventDefault();
        setIsTerminalOpen(prev => !prev);
      } else if (isCmdOrCtrl && (e.key === 'b' || e.key === 'B')) {
        e.preventDefault();
        setActiveSidebarTab(prev => (prev ? null : 'explorer'));
      }
    };

    window.addEventListener('keydown', handleGlobalKeyDown);
    return () => window.removeEventListener('keydown', handleGlobalKeyDown);
  }, []);

  // Command Palette Items
  const commandPaletteItems: CommandItem[] = useMemo(() => [
    {
      id: 'cmd-format',
      title: 'Format Document (Prettier)',
      category: 'Editor',
      shortcut: 'Shift+Alt+F',
      icon: <Wand2 className="w-4 h-4 text-cyan-400" />,
      action: handleFormatDocument,
    },
    {
      id: 'cmd-download-zip',
      title: 'Download Project as ZIP Archive',
      category: 'Workspace',
      shortcut: 'Ctrl+Shift+D',
      icon: <Download className="w-4 h-4 text-emerald-400" />,
      action: handleDownloadZip,
    },
    {
      id: 'cmd-clear-workspace',
      title: 'Clear All Files (Start Empty Workspace)',
      category: 'Workspace',
      icon: <Trash2 className="w-4 h-4 text-rose-400" />,
      action: handleClearAllFiles,
    },
    {
      id: 'cmd-preview',
      title: 'Toggle Live Web Sandbox Preview',
      category: 'View',
      shortcut: 'Ctrl+Shift+V',
      icon: <Eye className="w-4 h-4 text-cyan-400" />,
      action: () => setIsPreviewOpen(prev => !prev),
    },
    {
      id: 'cmd-terminal',
      title: 'Toggle Integrated Terminal Console',
      category: 'Terminal',
      shortcut: 'Ctrl+`',
      icon: <Terminal className="w-4 h-4 text-emerald-400" />,
      action: () => setIsTerminalOpen(prev => !prev),
    },
    {
      id: 'cmd-git-stage-all',
      title: 'Git: Stage All Modified Workspace Changes',
      category: 'Git',
      icon: <GitBranch className="w-4 h-4 text-cyan-400" />,
      action: handleStageAll,
    },
    {
      id: 'cmd-git-push',
      title: 'Git: Push Commits to Remote Repository',
      category: 'Git',
      icon: <ArrowUp className="w-4 h-4 text-emerald-400" />,
      action: handlePush,
    },
    {
      id: 'cmd-git-pull',
      title: 'Git: Pull Updates from Remote',
      category: 'Git',
      icon: <ArrowDown className="w-4 h-4 text-amber-400" />,
      action: handlePull,
    },
    {
      id: 'cmd-deploy-vercel',
      title: 'Deploy: Trigger Production Release to Vercel',
      category: 'Deploy',
      icon: <Rocket className="w-4 h-4 text-cyan-400" />,
      action: () => handleTriggerDeploy('vercel'),
    },
    {
      id: 'cmd-theme-tokyo',
      title: 'Preferences: Switch Theme to Tokyo Night Pro',
      category: 'Themes',
      icon: <Palette className="w-4 h-4 text-indigo-400" />,
      action: () => setSettings(s => ({ ...s, theme: 'tokyo-night' })),
    },
    {
      id: 'cmd-theme-monokai',
      title: 'Preferences: Switch Theme to Monokai Pro',
      category: 'Themes',
      icon: <Palette className="w-4 h-4 text-amber-400" />,
      action: () => setSettings(s => ({ ...s, theme: 'monokai' })),
    },
    {
      id: 'cmd-theme-vs-dark',
      title: 'Preferences: Switch Theme to VS Code Modern Dark',
      category: 'Themes',
      icon: <Palette className="w-4 h-4 text-cyan-400" />,
      action: () => setSettings(s => ({ ...s, theme: 'vs-dark' })),
    },
    {
      id: 'cmd-settings',
      title: 'Open Studio Preferences & Configuration',
      category: 'Settings',
      icon: <Settings className="w-4 h-4 text-slate-400" />,
      action: () => setIsSettingsOpen(true),
    },
  ], [handleFormatDocument, handleDownloadZip, handleClearAllFiles, handleStageAll, handlePush, handlePull, handleTriggerDeploy]);

  const themeClass = `theme-${settings.theme}`;

  return (
    <div className={`h-screen w-screen flex flex-col bg-slate-950 text-slate-100 overflow-hidden font-sans ${themeClass}`}>
      {/* Top Application Bar */}
      <TopBar
        projectName={currentTemplate.name}
        gitState={gitState}
        isTerminalOpen={isTerminalOpen}
        onToggleTerminal={() => setIsTerminalOpen(prev => !prev)}
        isPreviewOpen={isPreviewOpen}
        onTogglePreview={() => setIsPreviewOpen(prev => !prev)}
        isLiveServerRunning={isLiveServerRunning}
        onToggleLiveServer={handleToggleLiveServer}
        onRunCode={handleRunCode}
        onFormatCode={handleFormatDocument}
        onOpenDeploy={() => setActiveSidebarTab('deploy')}
        onOpenSettings={() => setIsSettingsOpen(true)}
        onOpenCommandPalette={() => setIsCommandPaletteOpen(true)}
        onOpenCloudSync={() => setIsCloudSyncOpen(true)}
        onDownloadZip={handleDownloadZip}
        onCreateNewFile={() => { setActiveSidebarTab('explorer'); }}
        onCreateNewFolder={() => { setActiveSidebarTab('explorer'); }}
        onClearWorkspace={handleClearAllFiles}
        isCloudSynced={true}
        lastSyncedText={lastCloudSyncText}
      />

      {/* Main Studio Workbench Area */}
      <div className="flex-1 flex overflow-hidden min-h-0 relative">
        {/* Leftmost Activity Bar */}
        <ActivityBar
          activeTab={activeSidebarTab}
          onSelectTab={tab => setActiveSidebarTab(prev => (prev === tab ? null : tab))}
          gitChangesCount={files.filter(f => f.isModified).length + gitState.stagedFiles.length}
          unresolvedProblemsCount={allDiagnostics.length}
          activeBreakpointsCount={breakpoints.filter(b => b.enabled).length}
          onToggleTerminal={() => setIsTerminalOpen(prev => !prev)}
          isTerminalOpen={isTerminalOpen}
          onOpenSettings={() => setIsSettingsOpen(true)}
          onOpenCloudSync={() => setIsCloudSyncOpen(true)}
        />

        {/* Dynamic Contextual Sidebar Drawer */}
        {activeSidebarTab && (
          <aside className="w-72 bg-slate-900 border-r border-slate-800/80 flex flex-col z-10 shrink-0 overflow-hidden">
            {activeSidebarTab === 'explorer' && (
              <FileExplorer
                files={files}
                activeFileId={activeFileId}
                onSelectFile={handleOpenFile}
                onCreateFile={handleCreateFile}
                onDeleteFile={handleDeleteFile}
                onRenameFile={handleRenameFile}
                onClearAllFiles={handleClearAllFiles}
                onDownloadZip={handleDownloadZip}
                stagedFiles={gitState.stagedFiles}
                projectName={currentTemplate.name}
              />
            )}

            {activeSidebarTab === 'git' && (
              <SourceControl
                gitState={gitState}
                files={files}
                onInitRepo={handleInitRepo}
                onStageFile={handleStageFile}
                onUnstageFile={handleUnstageFile}
                onStageAll={handleStageAll}
                onUnstageAll={handleUnstageAll}
                onCommit={handleCommit}
                onPush={handlePush}
                onPull={handlePull}
                onDiscardChanges={handleDiscardChanges}
                onViewDiff={handleViewDiff}
                onSwitchBranch={handleSwitchBranch}
                onCreateBranch={handleCreateBranch}
              />
            )}

            {activeSidebarTab === 'search' && (
              <GlobalSearch
                files={files}
                onSelectFileAndLine={handleSelectFileAndLine}
                onReplaceInFile={(fileId, oldText, newText) => {
                  const target = files.find(f => f.id === fileId);
                  if (target) {
                    const replaced = target.content.replaceAll(oldText, newText);
                    handleContentChange(fileId, replaced);
                  }
                }}
              />
            )}

            {activeSidebarTab === 'debugger' && (
              <DebuggerPanel
                breakpoints={breakpoints}
                onToggleBreakpoint={id => {
                  setBreakpoints(prev =>
                    prev.map(b => (b.id === id ? { ...b, enabled: !b.enabled } : b))
                  );
                }}
                onRemoveBreakpoint={handleRemoveBreakpoint}
                onSelectFileAndLine={(filePath, line) => {
                  const target = files.find(f => f.path === filePath);
                  if (target) handleSelectFileAndLine(target.id, line);
                }}
                onRunCode={handleRunCode}
                isLiveServerRunning={isLiveServerRunning}
                activeFileName={files.find(f => f.id === activeFileId)?.path || 'src/App.tsx'}
              />
            )}

            {activeSidebarTab === 'extensions' && (
              <ExtensionsMarketplace
                extensions={extensions}
                onToggleExtension={handleToggleExtension}
              />
            )}

            {activeSidebarTab === 'deploy' && (
              <DeploymentPipeline
                deploymentTargets={deploymentTargets}
                onTriggerDeploy={handleTriggerDeploy}
                onAddEnvVar={handleAddEnvVar}
                onRemoveEnvVar={handleRemoveEnvVar}
              />
            )}
          </aside>
        )}

        {/* Center & Right Split View: Editor + Live Preview */}
        <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
          <div className="flex-1 flex min-h-0 overflow-hidden">
            {/* Real-time Code Editor with Drag and Drop Tabs */}
            <CodeEditor
              openTabs={openTabs}
              activeFileId={activeFileId}
              files={files}
              onSelectTab={handleSelectTab}
              onCloseTab={handleCloseTab}
              onReorderTabs={setOpenTabs}
              onContentChange={handleContentChange}
              onFormatDocument={handleFormatDocument}
              onSaveFile={handleSaveFile}
              diagnostics={allDiagnostics}
              breakpoints={breakpoints}
              onToggleBreakpoint={handleToggleBreakpoint}
              settings={settings}
              onUpdateSettings={newS => setSettings(s => ({ ...s, ...newS }))}
              extensions={extensions}
              onRunCode={handleRunCode}
              onSelectLanguage={handleSelectLanguage}
            />

            {/* Live Web Sandbox Preview */}
            {isPreviewOpen && (
              <div className="w-[45%] h-full shrink-0 border-l border-slate-800">
                <LivePreview
                  files={files}
                  activeFileId={activeFileId}
                  viewport={previewViewport}
                  onChangeViewport={setPreviewViewport}
                  onClose={() => setIsPreviewOpen(false)}
                  onOpenTerminalWithCommand={(cmd) => {
                    setIsTerminalOpen(true);
                    setTerminalForcedTab('terminal');
                    setTerminalCommandToRun(cmd);
                  }}
                />
              </div>
            )}
          </div>

          {/* Bottom Integrated Terminal Console Drawer */}
          <InteractiveTerminal
            isOpen={isTerminalOpen}
            onClose={() => setIsTerminalOpen(false)}
            files={files}
            activeFileId={activeFileId}
            gitState={gitState}
            onStageFile={handleStageFile}
            onCommit={handleCommit}
            onPush={handlePush}
            onPull={handlePull}
            onCreateFile={handleCreateFile}
            onDeleteFile={handleDeleteFile}
            onSelectFileAndLine={handleSelectFileAndLine}
            diagnostics={allDiagnostics}
            onTriggerDeploy={handleTriggerDeploy}
            forcedTab={terminalForcedTab}
            commandToRun={terminalCommandToRun}
            onClearCommandToRun={() => setTerminalCommandToRun(null)}
          />
        </div>
      </div>

      {/* VS Code Bottom Status Bar */}
      <StatusBar
        gitState={gitState}
        onOpenGit={() => setActiveSidebarTab('git')}
        diagnostics={allDiagnostics}
        onOpenProblems={() => {
          setIsTerminalOpen(true);
          setTerminalForcedTab('problems');
        }}
        isLiveServerRunning={isLiveServerRunning}
        onToggleLiveServer={handleToggleLiveServer}
        isTerminalOpen={isTerminalOpen}
        onToggleTerminal={() => setIsTerminalOpen(prev => !prev)}
        isPrettierEnabled={extensions.find(e => e.id === 'ext-prettier')?.enabled ?? true}
        cursorPos={{ line: 1, col: 1 }}
        activeLanguage={files.find(f => f.id === activeFileId)?.language || 'typescript'}
        onSelectLanguage={handleSelectLanguage}
        onOpenSettings={() => setIsSettingsOpen(true)}
      />

      {/* Modals & Dialog Overlays */}
      <DiffViewerModal
        isOpen={isDiffModalOpen}
        onClose={() => setIsDiffModalOpen(false)}
        file={diffTargetFile}
        onStageFile={handleStageFile}
        onUnstageFile={handleUnstageFile}
        isStaged={diffTargetFile ? gitState.stagedFiles.includes(diffTargetFile.path) : false}
      />

      <CommandPalette
        isOpen={isCommandPaletteOpen}
        onClose={() => setIsCommandPaletteOpen(false)}
        commands={commandPaletteItems}
      />

      <QuickOpenModal
        isOpen={isQuickOpenOpen}
        onClose={() => setIsQuickOpenOpen(false)}
        files={files}
        onSelectFile={handleOpenFile}
      />

      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        settings={settings}
        onUpdateSettings={newS => setSettings(s => ({ ...s, ...newS }))}
      />

      <CloudSyncModal
        isOpen={isCloudSyncOpen}
        onClose={() => setIsCloudSyncOpen(false)}
        files={files}
        onImportFiles={handleImportFiles}
        onResetWorkspace={handleResetWorkspace}
        onDownloadZip={handleDownloadZip}
        lastSyncedText={lastCloudSyncText}
        projectName={currentTemplate.name}
      />

      {/* VS Code Floating Notification Toast */}
      {notificationToast && (
        <div className="fixed bottom-8 right-5 z-50 flex items-center gap-2.5 px-3.5 py-2.5 bg-slate-900 border border-slate-700/80 rounded-lg shadow-2xl text-xs text-slate-100 font-sans animate-in slide-in-from-bottom-2 fade-in duration-200">
          <div className={`w-2 h-2 rounded-full shrink-0 ${
            notificationToast.type === 'live' 
              ? 'bg-emerald-400 animate-ping' 
              : notificationToast.type === 'success' 
              ? 'bg-cyan-400' 
              : 'bg-indigo-400'
          }`} />
          <span className="font-medium">{notificationToast.message}</span>
          <button
            onClick={() => setNotificationToast(null)}
            className="ml-2 text-slate-500 hover:text-slate-200 cursor-pointer"
          >
            &times;
          </button>
        </div>
      )}
    </div>
  );
}
