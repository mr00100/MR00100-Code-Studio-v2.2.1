export interface WorkspaceFile {
  id: string;
  name: string;
  path: string;
  content: string;
  language: string;
  isModified?: boolean;
  isStaged?: boolean;
  isDeleted?: boolean;
}

export interface WorkspaceFolder {
  id: string;
  name: string;
  path: string;
  isOpen: boolean;
}

export interface GitCommit {
  hash: string;
  message: string;
  author: string;
  timestamp: string;
  filesChanged: string[];
}

export interface GitBranch {
  name: string;
  isCurrent: boolean;
  commitHash: string;
}

export interface GitState {
  isInitialized: boolean;
  currentBranch: string;
  branches: GitBranch[];
  stagedFiles: string[]; // file paths
  commits: GitCommit[];
  remoteUrl: string;
  isPushing: boolean;
  isPulling: boolean;
  aheadCount: number;
  behindCount: number;
  lastSyncedAt?: string;
}

export interface Diagnostic {
  id: string;
  file: string;
  line: number;
  col: number;
  message: string;
  severity: 'error' | 'warning' | 'info';
  rule: string;
}

export interface Breakpoint {
  id: string;
  file: string;
  line: number;
  enabled: boolean;
}

export interface ExtensionModule {
  id: string;
  name: string;
  displayName: string;
  category: 'theme' | 'language' | 'linter' | 'formatter' | 'utility';
  description: string;
  version: string;
  author: string;
  enabled: boolean;
  icon: string;
  downloads: string;
  rating: number;
  color?: string;
}

export interface DeploymentTarget {
  id: string;
  name: string;
  provider: 'vercel' | 'netlify' | 'cloudrun';
  status: 'idle' | 'building' | 'deploying' | 'live' | 'failed';
  liveUrl: string;
  buildTime?: string;
  lastDeployedAt?: string;
  logs: string[];
  envVars: { key: string; value: string }[];
}

export interface TerminalEntry {
  id: string;
  type: 'command' | 'output' | 'error' | 'success' | 'info' | 'system';
  text: string;
  timestamp: string;
}

export interface EditorTab {
  fileId: string;
  filePath: string;
  fileName: string;
  isDirty?: boolean;
}

export interface EditorSettings {
  fontSize: number;
  tabSize: number;
  theme: 'vs-dark' | 'tokyo-night' | 'monokai' | 'one-dark';
  wordWrap: boolean;
  minimap: boolean;
  lineNumbers: boolean;
  autoSave: boolean;
  fontFamily: string;
}

export interface ProjectTemplate {
  id: string;
  name: string;
  description: string;
  badge: string;
  icon: string;
  files: WorkspaceFile[];
}
