/**
 * MR00100 Code Studio - Multi-Language Robust Syntax Highlighting Engine
 * Uses single-pass tokenization to prevent ANY HTML tag mangling or regex recursion.
 * Supports: Python, JavaScript, TypeScript, TSX, JSX, HTML, CSS, C, C++, Java, Rust, Go, PHP, Ruby, Bash, SQL, JSON, Markdown, YAML
 */

export function highlightCode(code: string, language: string): string {
  if (!code) return '&nbsp;';

  const lang = (language || 'javascript').toLowerCase();

  switch (lang) {
    case 'python':
    case 'py':
      return tokenizeAndFormat(code, PYTHON_PATTERNS);
    case 'c':
    case 'cpp':
    case 'c++':
    case 'csharp':
    case 'cs':
      return tokenizeAndFormat(code, CPP_PATTERNS);
    case 'java':
    case 'kotlin':
      return tokenizeAndFormat(code, JAVA_PATTERNS);
    case 'rust':
    case 'rs':
      return tokenizeAndFormat(code, RUST_PATTERNS);
    case 'go':
    case 'golang':
      return tokenizeAndFormat(code, GO_PATTERNS);
    case 'php':
      return tokenizeAndFormat(code, PHP_PATTERNS);
    case 'ruby':
    case 'rb':
      return tokenizeAndFormat(code, RUBY_PATTERNS);
    case 'sql':
      return tokenizeAndFormat(code, SQL_PATTERNS);
    case 'bash':
    case 'sh':
    case 'shell':
    case 'zsh':
      return tokenizeAndFormat(code, BASH_PATTERNS);
    case 'html':
    case 'xml':
    case 'svg':
      return tokenizeHtml(code);
    case 'css':
    case 'scss':
    case 'less':
      return tokenizeCss(code);
    case 'json':
      return tokenizeJson(code);
    case 'markdown':
    case 'md':
      return tokenizeMarkdown(code);
    case 'typescript':
    case 'javascript':
    case 'tsx':
    case 'jsx':
    case 'ts':
    case 'js':
    default:
      return tokenizeAndFormat(code, JS_PATTERNS);
  }
}

export function escapeHtml(text: string): string {
  return text
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

interface TokenRule {
  type: 'comment' | 'string' | 'keyword' | 'type' | 'boolean' | 'function' | 'number' | 'attribute' | 'tag';
  regex: RegExp;
}

// Single-pass tokenizer that splits text into non-overlapping tokens
function tokenizeAndFormat(code: string, rules: TokenRule[]): string {
  const lines = code.split('\n');
  return lines.map(line => tokenizeLine(line, rules)).join('\n');
}

function tokenizeLine(line: string, rules: TokenRule[]): string {
  if (!line) return '';

  interface Match {
    start: number;
    end: number;
    type: string;
    text: string;
  }

  const matches: Match[] = [];

  for (const rule of rules) {
    const rx = new RegExp(rule.regex.source, rule.regex.flags);
    let m: RegExpExecArray | null;
    while ((m = rx.exec(line)) !== null) {
      if (m[0].length === 0) {
        rx.lastIndex++;
        continue;
      }
      matches.push({
        start: m.index,
        end: m.index + m[0].length,
        type: rule.type,
        text: m[0],
      });
    }
  }

  // Sort matches by start position, then by longer match
  matches.sort((a, b) => a.start - b.start || (b.end - b.start) - (a.end - a.start));

  // Filter overlapping matches (first non-overlapping takes precedence)
  const nonOverlapping: Match[] = [];
  let lastEnd = 0;
  for (const match of matches) {
    if (match.start >= lastEnd) {
      nonOverlapping.push(match);
      lastEnd = match.end;
    }
  }

  // Build pristine HTML without any nested tag injection
  let result = '';
  let cursor = 0;

  for (const match of nonOverlapping) {
    if (match.start > cursor) {
      result += escapeHtml(line.slice(cursor, match.start));
    }
    result += `<span class="token-${match.type}">${escapeHtml(match.text)}</span>`;
    cursor = match.end;
  }

  if (cursor < line.length) {
    result += escapeHtml(line.slice(cursor));
  }

  return result;
}

// -------------------------------------------------------------
// Language Patterns (Tested, non-colliding definitions)
// -------------------------------------------------------------

const JS_PATTERNS: TokenRule[] = [
  { type: 'comment', regex: /\/\/[^\n]*|\/\*[\s\S]*?\*\//g },
  { type: 'string', regex: /"(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*'|`(?:\\.|[^`\\])*`/g },
  {
    type: 'keyword',
    regex: /\b(import|export|from|default|const|let|var|function|return|if|else|switch|case|break|for|while|do|try|catch|finally|throw|new|typeof|instanceof|async|await|class|extends|interface|type|enum|as|in|of|void|yield)\b/g,
  },
  {
    type: 'type',
    regex: /\b(string|number|boolean|any|unknown|never|void|null|undefined|React|ReactNode|FC|Promise|Array|Record|Set|Map)\b/g,
  },
  { type: 'boolean', regex: /\b(true|false|null|undefined|NaN)\b/g },
  { type: 'number', regex: /\b\d+(\.\d+)?\b/g },
  { type: 'function', regex: /\b[a-zA-Z_$][a-zA-Z0-9_$]*(?=\s*\()/g },
];

const PYTHON_PATTERNS: TokenRule[] = [
  { type: 'comment', regex: /#[^\n]*/g },
  { type: 'string', regex: /f"(?:\\.|[^"\\])*"|f'(?:\\.|[^'\\])*'|"(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*'/g },
  {
    type: 'keyword',
    regex: /\b(def|class|import|from|as|return|if|elif|else|for|while|in|not|is|and|or|try|except|finally|raise|with|lambda|yield|pass|break|continue|global|assert|async|await)\b/g,
  },
  { type: 'boolean', regex: /\b(True|False|None)\b/g },
  { type: 'type', regex: /\b(self|cls|int|float|str|bool|list|dict|set|tuple)\b/g },
  {
    type: 'function',
    regex: /\b(print|len|range|enumerate|zip|map|filter|sum|min|max|abs|round|open|type|isinstance)\b|\b[a-zA-Z_][a-zA-Z0-9_]*(?=\s*\()/g,
  },
  { type: 'number', regex: /\b\d+(\.\d+)?\b/g },
  { type: 'attribute', regex: /@[a-zA-Z0-9_]+/g },
];

const CPP_PATTERNS: TokenRule[] = [
  { type: 'comment', regex: /\/\/[^\n]*|\/\*[\s\S]*?\*\//g },
  { type: 'string', regex: /"(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*'/g },
  { type: 'attribute', regex: /#(include|define|pragma|ifdef|ifndef|endif)\b[^\n]*/g },
  {
    type: 'keyword',
    regex: /\b(if|else|for|while|do|switch|case|default|break|continue|return|goto|sizeof|new|delete|try|catch|throw|using|namespace|template|typename|public|private|protected|virtual|override)\b/g,
  },
  {
    type: 'type',
    regex: /\b(int|float|double|char|void|bool|auto|long|short|unsigned|signed|const|static|struct|class|enum|union|typedef|std::string|std::vector)\b/g,
  },
  { type: 'boolean', regex: /\b(true|false|nullptr|NULL)\b/g },
  { type: 'function', regex: /\b(std::cout|std::cin|std::endl|printf|scanf|puts|malloc|free)\b|\b[a-zA-Z_][a-zA-Z0-9_]*(?=\s*\()/g },
  { type: 'number', regex: /\b\d+(\.\d+)?\b/g },
];

const JAVA_PATTERNS: TokenRule[] = [
  { type: 'comment', regex: /\/\/[^\n]*|\/\*[\s\S]*?\*\//g },
  { type: 'string', regex: /"(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*'/g },
  {
    type: 'keyword',
    regex: /\b(public|private|protected|static|final|abstract|synchronized|class|interface|extends|implements|package|import|new|return|if|else|for|while|do|switch|case|break|continue|try|catch|finally|throw|throws)\b/g,
  },
  {
    type: 'type',
    regex: /\b(int|boolean|byte|char|short|long|float|double|void|String|Integer|Boolean|List|ArrayList|Map|HashMap|Set)\b/g,
  },
  { type: 'boolean', regex: /\b(true|false|null)\b/g },
  { type: 'function', regex: /\b(System\.out\.println|System\.out\.print)\b|\b[a-zA-Z_][a-zA-Z0-9_]*(?=\s*\()/g },
  { type: 'number', regex: /\b\d+(\.\d+)?\b/g },
];

const RUST_PATTERNS: TokenRule[] = [
  { type: 'comment', regex: /\/\/[^\n]*|\/\*[\s\S]*?\*\//g },
  { type: 'string', regex: /"(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*'/g },
  {
    type: 'keyword',
    regex: /\b(fn|let|mut|pub|struct|enum|impl|trait|use|mod|match|if|else|for|while|loop|return|break|continue|as|where|const|static|type|unsafe|async|await)\b/g,
  },
  {
    type: 'type',
    regex: /\b(i8|i16|i32|i64|i128|u8|u16|u32|u64|u128|f32|f64|bool|char|str|String|Vec|Option|Result|Some|None|Ok|Err)\b/g,
  },
  { type: 'boolean', regex: /\b(true|false)\b/g },
  { type: 'function', regex: /\b(println!|print!|format!|vec!|panic!|assert!)\b|\b[a-zA-Z_][a-zA-Z0-9_]*(?=\s*\()/g },
  { type: 'number', regex: /\b\d+(\.\d+)?\b/g },
];

const GO_PATTERNS: TokenRule[] = [
  { type: 'comment', regex: /\/\/[^\n]*|\/\*[\s\S]*?\*\//g },
  { type: 'string', regex: /"(?:\\.|[^"\\])*"|`[^`]*`/g },
  {
    type: 'keyword',
    regex: /\b(package|import|func|return|var|const|type|struct|interface|map|chan|go|select|defer|if|else|for|range|switch|case|default|break|continue|fallthrough)\b/g,
  },
  { type: 'type', regex: /\b(int|int64|float64|string|bool|byte|rune|error|any)\b/g },
  { type: 'boolean', regex: /\b(true|false|nil|iota)\b/g },
  { type: 'function', regex: /\b(fmt\.Println|fmt\.Printf|fmt\.Print|make|new|append|len|cap)\b|\b[a-zA-Z_][a-zA-Z0-9_]*(?=\s*\()/g },
  { type: 'number', regex: /\b\d+(\.\d+)?\b/g },
];

const PHP_PATTERNS: TokenRule[] = [
  { type: 'comment', regex: /\/\/[^\n]*|#[^\n]*|\/\*[\s\S]*?\*\//g },
  { type: 'string', regex: /"(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*'/g },
  {
    type: 'keyword',
    regex: /\b(echo|print|function|class|public|private|protected|return|if|else|elseif|for|foreach|while|switch|case|break|try|catch|new|namespace|use)\b/g,
  },
  { type: 'type', regex: /\$[a-zA-Z0-9_]+/g },
  { type: 'boolean', regex: /\b(true|false|null)\b/g },
  { type: 'number', regex: /\b\d+(\.\d+)?\b/g },
];

const RUBY_PATTERNS: TokenRule[] = [
  { type: 'comment', regex: /#[^\n]*/g },
  { type: 'string', regex: /"(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*'/g },
  {
    type: 'keyword',
    regex: /\b(def|end|class|module|if|elsif|else|unless|while|until|for|in|do|return|yield|rescue|ensure|raise|puts|print|require|attr_accessor)\b/g,
  },
  { type: 'boolean', regex: /\b(true|false|nil|self)\b/g },
  { type: 'attribute', regex: /:[a-zA-Z0-9_]+/g },
  { type: 'number', regex: /\b\d+(\.\d+)?\b/g },
];

const SQL_PATTERNS: TokenRule[] = [
  { type: 'comment', regex: /--[^\n]*/g },
  { type: 'string', regex: /'(?:\\.|[^'\\])*'|"(?:\\.|[^"\\])*"/g },
  {
    type: 'keyword',
    regex: /\b(SELECT|FROM|WHERE|INSERT|INTO|VALUES|UPDATE|SET|DELETE|CREATE|TABLE|ALTER|DROP|JOIN|INNER|LEFT|RIGHT|ON|GROUP|BY|ORDER|ASC|DESC|LIMIT|PRIMARY|KEY|NOT|NULL|AND|OR|AS)\b/gi,
  },
  { type: 'type', regex: /\b(INTEGER|TEXT|REAL|BLOB|VARCHAR|INT|BOOLEAN|DATE|TIMESTAMP)\b/gi },
  { type: 'number', regex: /\b\d+(\.\d+)?\b/g },
];

const BASH_PATTERNS: TokenRule[] = [
  { type: 'comment', regex: /#[^\n]*/g },
  { type: 'string', regex: /"(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*'/g },
  {
    type: 'keyword',
    regex: /\b(if|then|else|elif|fi|case|esac|for|while|until|do|done|in|function|return|exit|export|source)\b/g,
  },
  {
    type: 'function',
    regex: /\b(echo|printf|cd|ls|cat|mkdir|rm|touch|chmod|chown|grep|sed|awk|curl|git|npm|python|python3|node|gcc|g\+\+)\b/g,
  },
  { type: 'type', regex: /\$[a-zA-Z0-9_]+|\$\{[^}]+\}/g },
  { type: 'number', regex: /\b\d+\b/g },
];

function tokenizeHtml(code: string): string {
  const lines = code.split('\n');
  return lines.map(line => {
    return line
      .replace(/<!--[\s\S]*?-->/g, m => `<span class="token-comment">${escapeHtml(m)}</span>`)
      .replace(/<\/?[a-zA-Z0-9\-]+(?=[\s>])/g, m => `<span class="token-tag">${escapeHtml(m)}</span>`)
      .replace(/([a-zA-Z0-9\-]+)=/g, (_, attr) => `<span class="token-attribute">${escapeHtml(attr)}</span>=`)
      .replace(/"[^"]*"/g, m => `<span class="token-string">${escapeHtml(m)}</span>`)
      .replace(/'[^']*'/g, m => `<span class="token-string">${escapeHtml(m)}</span>`);
  }).join('\n');
}

function tokenizeCss(code: string): string {
  const lines = code.split('\n');
  return lines.map(line => {
    return line
      .replace(/\/\*[\s\S]*?\*\//g, m => `<span class="token-comment">${escapeHtml(m)}</span>`)
      .replace(/([.#]?[a-zA-Z0-9_\-]+)\s*(?=\{)/g, (_, sel) => `<span class="token-tag">${escapeHtml(sel)}</span>`)
      .replace(/([a-zA-Z\-]+)\s*:/g, (_, prop) => `<span class="token-attribute">${escapeHtml(prop)}</span>:`)
      .replace(/(#[a-fA-F0-9]{3,8})/g, m => `<span class="token-string">${escapeHtml(m)}</span>`)
      .replace(/(\d+(px|rem|em|%|vh|vw|s|ms)?)\b/g, m => `<span class="token-number">${escapeHtml(m)}</span>`);
  }).join('\n');
}

function tokenizeJson(code: string): string {
  const lines = code.split('\n');
  return lines.map(line => {
    return line
      .replace(/"([^"]+)"\s*:/g, (_, key) => `<span class="token-attribute">&quot;${escapeHtml(key)}&quot;</span>:`)
      .replace(/:\s*"([^"]*)"/g, (_, val) => `: <span class="token-string">&quot;${escapeHtml(val)}&quot;</span>`)
      .replace(/:\s*(-?\d+(\.\d+)?)/g, (_, num) => `: <span class="token-number">${num}</span>`)
      .replace(/:\s*(true|false|null)/g, (_, bool) => `: <span class="token-boolean">${bool}</span>`);
  }).join('\n');
}

function tokenizeMarkdown(code: string): string {
  const lines = code.split('\n');
  return lines.map(line => {
    if (line.startsWith('#')) {
      return `<span class="token-keyword font-semibold">${escapeHtml(line)}</span>`;
    }
    return line
      .replace(/`([^`]+)`/g, (_, c) => `<span class="token-string bg-slate-800/80 px-1 rounded text-cyan-300">\`${escapeHtml(c)}\`</span>`)
      .replace(/\*\*([^*]+)\*\*/g, (_, b) => `<span class="font-bold text-cyan-200">**${escapeHtml(b)}**</span>`);
  }).join('\n');
}
