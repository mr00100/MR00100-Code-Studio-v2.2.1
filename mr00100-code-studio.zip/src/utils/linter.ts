import { Diagnostic, WorkspaceFile } from '../types';

/**
 * MR00100 Code Studio - Real-time Diagnostic & Linting Engine
 */
export function lintWorkspaceFile(file: WorkspaceFile): Diagnostic[] {
  const diagnostics: Diagnostic[] = [];
  const lines = file.content.split('\n');

  if (file.language === 'json') {
    try {
      JSON.parse(file.content);
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : 'Invalid JSON';
      diagnostics.push({
        id: `diag-json-${Date.now()}`,
        file: file.path,
        line: 1,
        col: 1,
        message: `JSON syntax error: ${message}`,
        severity: 'error',
        rule: 'json/syntax-valid',
      });
    }
    return diagnostics;
  }

  // Check balanced parentheses, brackets, and braces across lines
  let parenCount = 0;
  let bracketCount = 0;
  let braceCount = 0;

  lines.forEach((line, idx) => {
    const lineNum = idx + 1;
    const trimmed = line.trim();

    // Check for leftover console.log in production files
    if (trimmed.includes('console.log(')) {
      diagnostics.push({
        id: `diag-console-${lineNum}`,
        file: file.path,
        line: lineNum,
        col: line.indexOf('console.log') + 1,
        message: 'Unexpected console.log statement in production file.',
        severity: 'warning',
        rule: 'no-console',
      });
    }

    // Check for debugger statement
    if (trimmed.includes('debugger;') || trimmed === 'debugger') {
      diagnostics.push({
        id: `diag-debugger-${lineNum}`,
        file: file.path,
        line: lineNum,
        col: 1,
        message: 'Disallowed debugger statement found.',
        severity: 'error',
        rule: 'no-debugger',
      });
    }

    // Check for var declarations
    if (/\bvar\s+[a-zA-Z_$]/.test(line)) {
      diagnostics.push({
        id: `diag-var-${lineNum}`,
        file: file.path,
        line: lineNum,
        col: line.indexOf('var') + 1,
        message: 'Unexpected var keyword. Prefer const or let for block scoping.',
        severity: 'warning',
        rule: 'no-var',
      });
    }

    // Check for any type
    if (/:\s*any\b/.test(line)) {
      diagnostics.push({
        id: `diag-any-${lineNum}`,
        file: file.path,
        line: lineNum,
        col: line.indexOf(': any') + 1,
        message: 'Usage of explicit any type undermines TypeScript type safety.',
        severity: 'info',
        rule: '@typescript-eslint/no-explicit-any',
      });
    }

    // Track brackets if not commented
    if (!trimmed.startsWith('//') && !trimmed.startsWith('/*')) {
      for (const char of line) {
        if (char === '(') parenCount++;
        if (char === ')') parenCount--;
        if (char === '[') bracketCount++;
        if (char === ']') bracketCount--;
        if (char === '{') braceCount++;
        if (char === '}') braceCount--;
      }
    }
  });

  if (parenCount !== 0) {
    diagnostics.push({
      id: `diag-paren-${Date.now()}`,
      file: file.path,
      line: lines.length,
      col: 1,
      message: `Unbalanced parentheses: ${Math.abs(parenCount)} ${parenCount > 0 ? 'unclosed (' : 'extra )'}.`,
      severity: 'error',
      rule: 'syntax/balanced-brackets',
    });
  }

  if (bracketCount !== 0) {
    diagnostics.push({
      id: `diag-bracket-${Date.now()}`,
      file: file.path,
      line: lines.length,
      col: 1,
      message: `Unbalanced square brackets: ${Math.abs(bracketCount)} ${bracketCount > 0 ? 'unclosed [' : 'extra ]'}.`,
      severity: 'error',
      rule: 'syntax/balanced-brackets',
    });
  }

  if (braceCount !== 0) {
    diagnostics.push({
      id: `diag-brace-${Date.now()}`,
      file: file.path,
      line: lines.length,
      col: 1,
      message: `Unbalanced curly braces: ${Math.abs(braceCount)} ${braceCount > 0 ? 'unclosed {' : 'extra }'}.`,
      severity: 'error',
      rule: 'syntax/balanced-brackets',
    });
  }

  return diagnostics;
}
