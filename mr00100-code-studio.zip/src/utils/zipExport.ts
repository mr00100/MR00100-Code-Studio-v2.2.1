import JSZip from 'jszip';
import { WorkspaceFile } from '../types';

/**
 * MR00100 Code Studio - Project Zip Download Engine
 */
export async function downloadProjectAsZip(files: WorkspaceFile[], projectName: string = 'mr00100-project'): Promise<void> {
  const zip = new JSZip();

  // Add each file to the zip tree
  files.forEach(file => {
    // Clean leading slash if any
    const normalizedPath = file.path.startsWith('/') ? file.path.slice(1) : file.path;
    zip.file(normalizedPath, file.content);
  });

  // Generate zip file
  const content = await zip.generateAsync({ type: 'blob' });
  
  // Trigger browser download
  const blobUrl = URL.createObjectURL(content);
  const link = document.createElement('a');
  link.href = blobUrl;
  const safeName = projectName.toLowerCase().replace(/[^a-z0-9_-]/g, '-');
  link.download = `${safeName || 'mr00100-project'}.zip`;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(blobUrl);
}

export function downloadSingleFile(file: WorkspaceFile): void {
  const blob = new Blob([file.content], { type: 'text/plain;charset=utf-8' });
  const blobUrl = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = blobUrl;
  link.download = file.name;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(blobUrl);
}
