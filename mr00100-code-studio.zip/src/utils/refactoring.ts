/**
 * MR00100 Code Studio - Advanced Refactoring & Formatting Engine
 */

export function formatCode(content: string, language: string): string {
  if (!content) return '';

  if (language === 'json') {
    try {
      const parsed = JSON.parse(content);
      return JSON.stringify(parsed, null, 2);
    } catch {
      return content;
    }
  }

  // Prettier-style indentation normalization
  const lines = content.split('\n');
  let indentLevel = 0;
  const formattedLines: string[] = [];

  for (let i = 0; i < lines.length; i++) {
    const rawLine = lines[i];
    const trimmed = rawLine.trim();

    if (!trimmed) {
      formattedLines.push('');
      continue;
    }

    // Decrement indent for closing brackets before printing line
    if (trimmed.startsWith('}') || trimmed.startsWith(']') || trimmed.startsWith(')')) {
      indentLevel = Math.max(0, indentLevel - 1);
    } else if (trimmed.startsWith('</')) {
      indentLevel = Math.max(0, indentLevel - 1);
    }

    const indent = '  '.repeat(indentLevel);
    formattedLines.push(indent + trimmed);

    // Increment indent for opening brackets at end of line
    if (trimmed.endsWith('{') || trimmed.endsWith('[') || trimmed.endsWith('(')) {
      indentLevel++;
    } else if (
      trimmed.startsWith('<') &&
      !trimmed.startsWith('<!') &&
      !trimmed.startsWith('<?') &&
      !trimmed.startsWith('<!--') &&
      !trimmed.endsWith('/>') &&
      !trimmed.includes('</') &&
      trimmed.endsWith('>')
    ) {
      indentLevel++;
    }
  }

  return formattedLines.join('\n');
}

export function renameSymbolInContent(
  content: string,
  oldSymbol: string,
  newSymbol: string
): { updatedContent: string; occurrences: number } {
  if (!oldSymbol || !newSymbol || oldSymbol === newSymbol) {
    return { updatedContent: content, occurrences: 0 };
  }

  // Safe boundary replacement
  const regex = new RegExp(`\\b${escapeRegExp(oldSymbol)}\\b`, 'g');
  const matches = content.match(regex);
  const occurrences = matches ? matches.length : 0;
  const updatedContent = content.replace(regex, newSymbol);

  return { updatedContent, occurrences };
}

export function extractVariableHelper(
  selectedText: string,
  variableName: string
): { declaration: string; usage: string } {
  const cleanVar = variableName.trim() || 'extractedValue';
  const cleanText = selectedText.trim();
  const declaration = `const ${cleanVar} = ${cleanText};`;
  return { declaration, usage: cleanVar };
}

export function wrapWithTagHelper(selectedText: string, tagName: string): string {
  const tag = tagName.trim() || 'div';
  return `<${tag}>\n  ${selectedText}\n</${tag}>`;
}

function escapeRegExp(string: string): string {
  return string.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}
