import React, { useState, useEffect, useRef } from 'react';
import { 
  RefreshCw, 
  ExternalLink, 
  Laptop, 
  Tablet, 
  Smartphone, 
  Terminal, 
  Minimize2, 
  Play, 
  CheckCircle2, 
  AlertCircle, 
  Clock, 
  Globe, 
  FileCode,
  ArrowRight
} from 'lucide-react';
import { WorkspaceFile } from '../../types';
import { executeCode, RunResult } from '../../utils/codeRunner';

interface LivePreviewProps {
  files: WorkspaceFile[];
  activeFileId: string | null;
  viewport: 'desktop' | 'tablet' | 'mobile';
  onChangeViewport: (vp: 'desktop' | 'tablet' | 'mobile') => void;
  onClose: () => void;
  onOpenTerminalWithCommand?: (cmd: string) => void;
}

export const LivePreview: React.FC<LivePreviewProps> = ({
  files,
  activeFileId,
  viewport,
  onChangeViewport,
  onClose,
  onOpenTerminalWithCommand,
}) => {
  const iframeRef = useRef<HTMLIFrameElement>(null);
  const [iframeSrcDoc, setIframeSrcDoc] = useState('');
  const [consoleLogs, setConsoleLogs] = useState<{ type: string; message: string; time: string }[]>([]);
  const [showConsole, setShowConsole] = useState(false);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [liveReload, setLiveReload] = useState(true);

  // Non-web code execution state (Python, C, C++, Java, etc.)
  const [activeTabMode, setActiveTabMode] = useState<'active-file' | 'web-html'>('active-file');
  const [runResult, setRunResult] = useState<RunResult | null>(null);
  const [isRunningScript, setIsRunningScript] = useState(false);

  const activeFile = files.find(f => f.id === activeFileId) || (files.length > 0 ? files[0] : null);
  const htmlFile = files.find(f => f.name.endsWith('.html') || f.name.endsWith('.htm'));

  const isWebFile = (f: WorkspaceFile | null) => {
    if (!f) return false;
    const n = f.name.toLowerCase();
    return n.endsWith('.html') || n.endsWith('.htm') || n.endsWith('.tsx') || n.endsWith('.jsx') || n.endsWith('.css');
  };

  // Generate sandboxed document or run script
  const handleRefresh = async () => {
    setIsRefreshing(true);

    if (!activeFile) {
      setIframeSrcDoc(`
        <!DOCTYPE html><html><body style="background:#090d16;color:#94a3b8;font-family:sans-serif;display:flex;align-items:center;justify-content:center;height:100vh;margin:0;">
          <div style="text-align:center;"><h3>No active file selected</h3><p>Create or select a file to run.</p></div>
        </body></html>
      `);
      setIsRefreshing(false);
      return;
    }

    const currentIsWeb = isWebFile(activeFile) || activeTabMode === 'web-html';

    if (!currentIsWeb) {
      // Execute Python, JS, C, C++, Java, Rust, Go, Bash, SQL, etc.
      setIsRunningScript(true);
      try {
        const res = await executeCode(activeFile.name, activeFile.content, activeFile.language);
        setRunResult(res);
      } catch (err: unknown) {
        const msg = err instanceof Error ? err.message : String(err);
        setRunResult({
          language: activeFile.language,
          languageDisplayName: activeFile.language.toUpperCase(),
          command: `run ${activeFile.name}`,
          stdout: [],
          stderr: [`Execution failed: ${msg}`],
          exitCode: 1,
          executionTimeMs: 0,
          formattedOutput: `Error: ${msg}`,
        });
      } finally {
        setIsRunningScript(false);
        setIsRefreshing(false);
      }
      return;
    }

    // Web execution
    const cssFile = files.find(f => f.name.endsWith('.css'));
    const jsFile = files.find(f => f.name.endsWith('.js') && !f.name.endsWith('.json'));

    const consoleInterceptor = `
      <script>
        (function() {
          const oldLog = console.log;
          const oldWarn = console.warn;
          const oldErr = console.error;
          window.addEventListener('error', function(e) {
            window.parent.postMessage({ type: 'CONSOLE', level: 'error', msg: e.message + ' at ' + (e.filename || '') + ':' + (e.lineno || '') }, '*');
          });
          console.log = function(...args) {
            oldLog.apply(console, args);
            window.parent.postMessage({ type: 'CONSOLE', level: 'log', msg: args.map(a => typeof a === 'object' ? JSON.stringify(a) : String(a)).join(' ') }, '*');
          };
          console.warn = function(...args) {
            oldWarn.apply(console, args);
            window.parent.postMessage({ type: 'CONSOLE', level: 'warn', msg: args.map(a => typeof a === 'object' ? JSON.stringify(a) : String(a)).join(' ') }, '*');
          };
          console.error = function(...args) {
            oldErr.apply(console, args);
            window.parent.postMessage({ type: 'CONSOLE', level: 'error', msg: args.map(a => typeof a === 'object' ? JSON.stringify(a) : String(a)).join(' ') }, '*');
          };
        })();
      </script>
    `;

    // 1. Check if rendering an HTML file
    const targetHtml = (activeTabMode === 'web-html' && htmlFile) 
      ? htmlFile 
      : (activeFile?.name.endsWith('.html') || activeFile?.name.endsWith('.htm'))
      ? activeFile
      : htmlFile;

    if (targetHtml) {
      let content = targetHtml.content;
      if (cssFile && !content.includes(cssFile.name) && !content.includes('<style>')) {
        content = content.replace('</head>', `<style>${cssFile.content}</style></head>`);
      }
      if (jsFile && !content.includes(jsFile.name) && !content.includes('<script>')) {
        content = content.replace('</body>', `<script>${jsFile.content}</script></body>`);
      }
      if (content.includes('<head>')) {
        content = content.replace('<head>', `<head>${consoleInterceptor}`);
      } else {
        content = `${consoleInterceptor}${content}`;
      }
      setIframeSrcDoc(content);
      setIsRefreshing(false);
      return;
    }

    // 2. React Component (.tsx / .jsx)
    if (activeFile && (activeFile.name.endsWith('.tsx') || activeFile.name.endsWith('.jsx'))) {
      const reactAppDoc = `
        <!DOCTYPE html>
        <html>
          <head>
            <meta charset="utf-8" />
            <meta name="viewport" content="width=device-width, initial-scale=1.0" />
            <title>React Live Preview</title>
            <script src="https://cdn.tailwindcss.com"></script>
            <script src="https://unpkg.com/react@18/umd/react.development.js" crossorigin></script>
            <script src="https://unpkg.com/react-dom@18/umd/react-dom.development.js" crossorigin></script>
            <script src="https://unpkg.com/@babel/standalone/babel.min.js"></script>
            ${consoleInterceptor}
            <style>
              ${cssFile ? cssFile.content : ''}
              body { margin: 0; background-color: #0b0f19; color: #f8fafc; font-family: system-ui, sans-serif; }
            </style>
          </head>
          <body>
            <div id="root"></div>
            <script type="text/babel">
              const { useState, useEffect, useRef, useMemo, useCallback } = React;
              
              ${sanitizeReactCode(activeFile.content)}

              try {
                const root = ReactDOM.createRoot(document.getElementById('root'));
                const ComponentToRender = typeof App !== 'undefined' ? App : (typeof ${activeFile.name.replace(/\.[^/.]+$/, '')} !== 'undefined' ? ${activeFile.name.replace(/\.[^/.]+$/, '')} : null);
                if (ComponentToRender) {
                  root.render(<ComponentToRender />);
                } else {
                  root.render(
                    <div style={{ padding: 24, textAlign: 'center', color: '#94a3b8' }}>
                      <p>Export a default component or named function to render.</p>
                    </div>
                  );
                }
              } catch(err) {
                console.error("Render Error:", err);
                document.getElementById('root').innerHTML = '<div style="padding:20px;color:#f87171;background:#450a0a;border-radius:8px;">' + err.message + '</div>';
              }
            </script>
          </body>
        </html>
      `;
      setIframeSrcDoc(reactAppDoc);
      setIsRefreshing(false);
      return;
    }

    setIsRefreshing(false);
  };

  const sanitizeReactCode = (raw: string): string => {
    return raw
      .replace(/import\s+.*?from\s+['"].*?['"];?/g, '')
      .replace(/export\s+default\s+function\s+([A-Za-z0-9_]+)/g, 'function $1')
      .replace(/export\s+default\s+const\s+([A-Za-z0-9_]+)/g, 'const $1')
      .replace(/export\s+function\s+([A-Za-z0-9_]+)/g, 'function $1')
      .replace(/export\s+const\s+([A-Za-z0-9_]+)/g, 'const $1')
      .replace(/interface\s+[A-Za-z0-9_]+[\s\S]*?\}/g, '')
      .replace(/type\s+[A-Za-z0-9_]+\s*=[\s\S]*?;/g, '')
      .replace(/: React\.[A-Za-z0-9_<>]+/g, '')
      .replace(/: [A-Za-z0-9_<>\[\]]+/g, '');
  };

  useEffect(() => {
    // Only auto-reload for Web files (HTML/CSS/React preview).
    // NEVER auto-execute script languages (Python, C, C++, Java, Node) while user is typing in editor!
    const currentIsWeb = isWebFile(activeFile) || activeTabMode === 'web-html';
    if (liveReload && currentIsWeb) {
      const timer = setTimeout(() => {
        handleRefresh();
      }, 400);
      return () => clearTimeout(timer);
    }
  }, [files, activeFileId, liveReload, activeTabMode]);

  useEffect(() => {
    const handleMessage = (e: MessageEvent) => {
      if (e.data && e.data.type === 'CONSOLE') {
        setConsoleLogs(prev => [
          ...prev.slice(-40),
          {
            type: e.data.level || 'log',
            message: e.data.msg || '',
            time: new Date().toLocaleTimeString(),
          }
        ]);
      }
    };
    window.addEventListener('message', handleMessage);
    return () => window.removeEventListener('message', handleMessage);
  }, []);

  const getViewportWidthClass = () => {
    switch (viewport) {
      case 'mobile': return 'w-[375px] h-[667px] shadow-2xl rounded-2xl border-4 border-slate-700';
      case 'tablet': return 'w-[768px] h-[90%] shadow-2xl rounded-xl border-4 border-slate-700';
      default: return 'w-full h-full';
    }
  };

  const handleOpenTerminalRun = () => {
    if (!activeFile) return;
    const cmd = 
      activeFile.name.endsWith('.py') ? `python3 ${activeFile.path}`
      : activeFile.name.endsWith('.c') ? `gcc ${activeFile.path} -o main && ./main`
      : activeFile.name.endsWith('.cpp') ? `g++ ${activeFile.path} -o main && ./main`
      : activeFile.name.endsWith('.java') ? `javac ${activeFile.path} && java Main`
      : activeFile.name.endsWith('.rs') ? `rustc ${activeFile.path} -o main && ./main`
      : activeFile.name.endsWith('.go') ? `go run ${activeFile.path}`
      : activeFile.name.endsWith('.php') ? `php ${activeFile.path}`
      : activeFile.name.endsWith('.rb') ? `ruby ${activeFile.path}`
      : activeFile.name.endsWith('.sh') ? `bash ${activeFile.path}`
      : activeFile.name.endsWith('.sql') ? `sqlite3 :memory: < ${activeFile.path}`
      : `node ${activeFile.path}`;

    if (onOpenTerminalWithCommand) {
      onOpenTerminalWithCommand(cmd);
    }
  };

  const isCurrentFileWeb = isWebFile(activeFile);
  const showWebCanvas = isCurrentFileWeb || activeTabMode === 'web-html';

  return (
    <div className="h-full flex flex-col bg-slate-950 border-l border-slate-800 text-slate-300 text-xs select-none min-w-[320px] max-w-full">
      {/* Live Server Header */}
      <div className="h-10 px-3 border-b border-slate-800 bg-slate-900/60 flex items-center justify-between font-medium text-xs text-slate-300 shrink-0">
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1.5 px-2 py-0.5 rounded bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 font-mono text-[11px]">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <span>Port 5500</span>
          </div>

          {/* Mode Switcher if both HTML and script exist */}
          {htmlFile && !isCurrentFileWeb && (
            <div className="flex items-center bg-slate-900 border border-slate-800 rounded p-0.5 text-[11px]">
              <button
                onClick={() => setActiveTabMode('active-file')}
                className={`px-2 py-0.5 rounded transition-colors ${
                  activeTabMode === 'active-file' ? 'bg-cyan-500/20 text-cyan-300 font-medium' : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {activeFile?.name || 'Active File'}
              </button>
              <button
                onClick={() => setActiveTabMode('web-html')}
                className={`px-2 py-0.5 rounded transition-colors ${
                  activeTabMode === 'web-html' ? 'bg-cyan-500/20 text-cyan-300 font-medium' : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Web Preview
              </button>
            </div>
          )}
        </div>

        {/* Viewport switchers & controls */}
        <div className="flex items-center gap-1.5">
          {showWebCanvas && (
            <div className="flex items-center bg-slate-900 border border-slate-800 rounded p-0.5">
              <button
                onClick={() => onChangeViewport('desktop')}
                className={`p-1 rounded ${viewport === 'desktop' ? 'bg-cyan-500/20 text-cyan-300' : 'text-slate-400 hover:text-slate-200'}`}
                title="Desktop"
              >
                <Laptop className="w-3.5 h-3.5" />
              </button>
              <button
                onClick={() => onChangeViewport('tablet')}
                className={`p-1 rounded ${viewport === 'tablet' ? 'bg-cyan-500/20 text-cyan-300' : 'text-slate-400 hover:text-slate-200'}`}
                title="Tablet"
              >
                <Tablet className="w-3.5 h-3.5" />
              </button>
              <button
                onClick={() => onChangeViewport('mobile')}
                className={`p-1 rounded ${viewport === 'mobile' ? 'bg-cyan-500/20 text-cyan-300' : 'text-slate-400 hover:text-slate-200'}`}
                title="Mobile"
              >
                <Smartphone className="w-3.5 h-3.5" />
              </button>
            </div>
          )}

          <button
            onClick={() => setLiveReload(!liveReload)}
            className={`px-2 py-0.5 rounded text-[10px] font-mono border transition-colors ${
              liveReload
                ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30'
                : 'bg-slate-900 text-slate-500 border-slate-800'
            }`}
            title="Auto refresh on code changes"
          >
            Auto: {liveReload ? 'ON' : 'OFF'}
          </button>

          <button
            onClick={handleRefresh}
            className="p-1 hover:bg-slate-800 rounded text-slate-400 hover:text-slate-200 transition-colors"
            title="Reload Execution"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isRefreshing || isRunningScript ? 'animate-spin text-cyan-400' : ''}`} />
          </button>

          {showWebCanvas && (
            <button
              onClick={() => setShowConsole(!showConsole)}
              className={`p-1 rounded transition-colors ${
                showConsole ? 'bg-slate-800 text-cyan-300' : 'text-slate-400 hover:text-slate-200'
              }`}
              title="Toggle Console Output"
            >
              <Terminal className="w-3.5 h-3.5" />
            </button>
          )}

          <button
            onClick={onClose}
            className="p-1 hover:bg-slate-800 rounded text-slate-400 hover:text-rose-400"
            title="Close Preview Pane"
          >
            <Minimize2 className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Main Content Area */}
      {showWebCanvas ? (
        /* Web Preview Canvas (HTML / React / CSS) */
        <div className="flex-1 bg-slate-950 flex items-center justify-center p-2 overflow-auto relative">
          <div className={`transition-all duration-200 overflow-hidden bg-white ${getViewportWidthClass()}`}>
            <iframe
              ref={iframeRef}
              srcDoc={iframeSrcDoc}
              title="Live Code Sandbox"
              sandbox="allow-scripts allow-modals allow-forms allow-same-origin"
              className="w-full h-full border-0 bg-white"
            />
          </div>
        </div>
      ) : (
        /* Multi-Language Code Output Runner (Python, C, C++, Java, JS, etc.) */
        <div className="flex-1 bg-slate-950 flex flex-col overflow-hidden p-3 space-y-3 font-mono">
          {/* File & Status Banner */}
          <div className="bg-slate-900 border border-slate-800 rounded-lg p-3 flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400">
                <FileCode className="w-4 h-4" />
              </div>
              <div>
                <div className="text-white font-semibold text-xs flex items-center gap-1.5">
                  <span>{activeFile?.name || 'No file selected'}</span>
                  <span className="text-[10px] px-1.5 py-0.5 rounded bg-slate-800 text-cyan-300 font-mono font-normal">
                    {runResult?.languageDisplayName || activeFile?.language || 'Code'}
                  </span>
                </div>
                <div className="text-[11px] text-slate-400 mt-0.5">
                  Execution Command: <code className="text-slate-300 font-mono">{runResult?.command || 'auto'}</code>
                </div>
              </div>
            </div>

            {/* Run Actions */}
            <div className="flex items-center gap-2">
              <button
                onClick={handleRefresh}
                className="flex items-center gap-1.5 px-3 py-1 bg-emerald-600 hover:bg-emerald-500 text-white rounded text-xs font-semibold transition-all cursor-pointer shadow-xs"
              >
                <Play className="w-3 h-3 fill-current" />
                <span>Re-Run</span>
              </button>

              <button
                onClick={handleOpenTerminalRun}
                className="flex items-center gap-1.5 px-3 py-1 bg-slate-800 hover:bg-slate-700 text-cyan-300 border border-cyan-500/30 rounded text-xs font-semibold transition-all cursor-pointer"
                title="Execute this command inside the integrated terminal"
              >
                <Terminal className="w-3 h-3" />
                <span>Run in Terminal</span>
                <ArrowRight className="w-3 h-3" />
              </button>
            </div>
          </div>

          {/* Console / Terminal Stdout Output Window */}
          <div className="flex-1 bg-slate-900/90 border border-slate-800 rounded-lg flex flex-col overflow-hidden">
            {/* Window bar */}
            <div className="h-8 px-3 bg-slate-900 border-b border-slate-800 flex items-center justify-between text-[11px] text-slate-400">
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-rose-500/80" />
                <span className="w-2.5 h-2.5 rounded-full bg-amber-500/80" />
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-500/80" />
                <span className="ml-2 font-semibold text-slate-300">Program Output (stdout / stderr)</span>
              </div>
              <div className="flex items-center gap-2 text-[10px]">
                {runResult && (
                  <span className="text-slate-400 flex items-center gap-1">
                    <Clock className="w-3 h-3" />
                    {runResult.executionTimeMs}ms
                  </span>
                )}
                {runResult && runResult.exitCode === 0 ? (
                  <span className="text-emerald-400 flex items-center gap-1 font-semibold">
                    <CheckCircle2 className="w-3 h-3" /> Exited: 0
                  </span>
                ) : runResult && runResult.exitCode !== 0 ? (
                  <span className="text-rose-400 flex items-center gap-1 font-semibold">
                    <AlertCircle className="w-3 h-3" /> Exit Code: {runResult.exitCode}
                  </span>
                ) : null}
              </div>
            </div>

            {/* Scrollable output container */}
            <div className="flex-1 p-3 overflow-y-auto space-y-1 text-xs select-text">
              {isRunningScript ? (
                <div className="text-cyan-400 flex items-center gap-2 italic">
                  <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                  <span>Compiling and executing {activeFile?.name}...</span>
                </div>
              ) : !runResult ? (
                <div className="text-slate-500 italic">
                  Click [Re-Run] to compile and execute active file.
                </div>
              ) : (
                <pre className="text-slate-200 whitespace-pre-wrap leading-relaxed font-mono">
                  {runResult.formattedOutput}
                </pre>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Web Console Drawer (only for Web mode) */}
      {showWebCanvas && showConsole && (
        <div className="h-40 border-t border-slate-800 bg-slate-950 font-mono text-[11px] flex flex-col shrink-0">
          <div className="h-6 px-3 bg-slate-900/90 border-b border-slate-800 flex items-center justify-between text-slate-400">
            <span>Browser Console ({consoleLogs.length} events)</span>
            <button
              onClick={() => setConsoleLogs([])}
              className="text-[10px] text-slate-500 hover:text-slate-300"
            >
              Clear
            </button>
          </div>
          <div className="flex-1 overflow-y-auto p-2 space-y-1">
            {consoleLogs.length === 0 ? (
              <div className="text-slate-600 italic">No console logs recorded.</div>
            ) : (
              consoleLogs.map((log, idx) => (
                <div
                  key={idx}
                  className={`flex items-start gap-2 ${
                    log.type === 'error'
                      ? 'text-rose-400 bg-rose-950/20 p-1 rounded'
                      : log.type === 'warn'
                      ? 'text-amber-400'
                      : 'text-slate-300'
                  }`}
                >
                  <span className="text-slate-600 text-[10px] shrink-0">{log.time}</span>
                  <span className="break-all">{log.message}</span>
                </div>
              ))
            )}
          </div>
        </div>
      )}
    </div>
  );
};
