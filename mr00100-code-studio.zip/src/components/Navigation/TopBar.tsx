import React, { useState } from 'react';
import { 
  Code2, 
  Play, 
  Terminal, 
  Download, 
  Settings, 
  Radio, 
  Cloud, 
  RotateCcw,
  Search, 
  Check,
  ChevronDown
} from 'lucide-react';
import { GitState } from '../../types';

interface TopBarProps {
  projectName: string;
  gitState: GitState;
  isTerminalOpen: boolean;
  onToggleTerminal: () => void;
  isPreviewOpen: boolean;
  onTogglePreview: () => void;
  isLiveServerRunning: boolean;
  onToggleLiveServer: () => void;
  onRunCode: (mode: 'live-server' | 'terminal') => void;
  onFormatCode: () => void;
  onOpenDeploy: () => void;
  onOpenSettings: () => void;
  onOpenCommandPalette: () => void;
  onOpenCloudSync: () => void;
  onDownloadZip: () => void;
  onCreateNewFile: () => void;
  onCreateNewFolder: () => void;
  onClearWorkspace: () => void;
  isCloudSynced: boolean;
  lastSyncedText: string;
}

export const TopBar: React.FC<TopBarProps> = ({
  projectName,
  gitState,
  isTerminalOpen,
  onToggleTerminal,
  isPreviewOpen,
  onTogglePreview,
  isLiveServerRunning,
  onToggleLiveServer,
  onRunCode,
  onFormatCode,
  onOpenDeploy,
  onOpenSettings,
  onOpenCommandPalette,
  onOpenCloudSync,
  onDownloadZip,
  onCreateNewFile,
  onCreateNewFolder,
  onClearWorkspace,
  isCloudSynced,
  lastSyncedText,
}) => {
  const [activeMenu, setActiveMenu] = useState<string | null>(null);

  return (
    <header className="h-10 bg-slate-950 border-b border-slate-800 px-3 flex items-center justify-between text-slate-300 text-xs select-none z-40 shrink-0 font-sans theme-topbar">
      {/* Left: Brand + Classic VS Code Menu */}
      <div className="flex items-center gap-1.5 shrink-0">
        {/* Brand Logo & Title */}
        <div className="flex items-center gap-2 mr-3">
          <div className="w-5 h-5 rounded bg-gradient-to-tr from-cyan-500 to-indigo-600 flex items-center justify-center text-white shadow-xs">
            <Code2 className="w-3.5 h-3.5" />
          </div>
          <span className="font-bold tracking-tight text-slate-100 text-xs flex items-center gap-1">
            MR00100 <span className="font-normal text-cyan-400">Code Studio</span>
          </span>
        </div>

        {/* VS Code Dropdown Menus */}
        <div className="hidden lg:flex items-center text-[11px] text-slate-400">
          {/* File Menu */}
          <div className="relative">
            <button
              onClick={() => setActiveMenu(activeMenu === 'file' ? null : 'file')}
              className={`px-2 py-1 rounded hover:bg-slate-800 hover:text-slate-100 transition-colors cursor-pointer ${
                activeMenu === 'file' ? 'bg-slate-800 text-white' : ''
              }`}
            >
              File
            </button>
            {activeMenu === 'file' && (
              <div 
                className="absolute top-full left-0 mt-0.5 w-52 bg-slate-900 border border-slate-700/80 rounded-lg shadow-2xl py-1 z-50 text-xs"
                onMouseLeave={() => setActiveMenu(null)}
              >
                <button
                  onClick={() => { onCreateNewFile(); setActiveMenu(null); }}
                  className="w-full text-left px-3 py-1.5 hover:bg-slate-800 text-slate-200 flex items-center justify-between cursor-pointer"
                >
                  <span>New File</span>
                  <span className="text-[10px] text-slate-500 font-mono">Ctrl+N</span>
                </button>
                <button
                  onClick={() => { onCreateNewFolder(); setActiveMenu(null); }}
                  className="w-full text-left px-3 py-1.5 hover:bg-slate-800 text-slate-200 flex items-center justify-between cursor-pointer"
                >
                  <span>New Folder</span>
                </button>
                <div className="h-px bg-slate-800 my-1" />
                <button
                  onClick={() => { onDownloadZip(); setActiveMenu(null); }}
                  className="w-full text-left px-3 py-1.5 hover:bg-slate-800 text-cyan-300 font-medium flex items-center gap-2 cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Download Project (ZIP)</span>
                </button>
                <button
                  onClick={() => { onOpenCloudSync(); setActiveMenu(null); }}
                  className="w-full text-left px-3 py-1.5 hover:bg-slate-800 text-slate-300 flex items-center gap-2 cursor-pointer"
                >
                  <Cloud className="w-3.5 h-3.5 text-cyan-400" />
                  <span>Cloud Sync / Backup</span>
                </button>
                <div className="h-px bg-slate-800 my-1" />
                <button
                  onClick={() => { onClearWorkspace(); setActiveMenu(null); }}
                  className="w-full text-left px-3 py-1.5 hover:bg-rose-950/40 text-rose-400 flex items-center gap-2 cursor-pointer"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>Clear All Files</span>
                </button>
              </div>
            )}
          </div>

          {/* Edit Menu */}
          <div className="relative">
            <button
              onClick={() => setActiveMenu(activeMenu === 'edit' ? null : 'edit')}
              className={`px-2 py-1 rounded hover:bg-slate-800 hover:text-slate-100 transition-colors cursor-pointer ${
                activeMenu === 'edit' ? 'bg-slate-800 text-white' : ''
              }`}
            >
              Edit
            </button>
            {activeMenu === 'edit' && (
              <div 
                className="absolute top-full left-0 mt-0.5 w-52 bg-slate-900 border border-slate-700/80 rounded-lg shadow-2xl py-1 z-50 text-xs"
                onMouseLeave={() => setActiveMenu(null)}
              >
                <button
                  onClick={() => { onFormatCode(); setActiveMenu(null); }}
                  className="w-full text-left px-3 py-1.5 hover:bg-slate-800 text-slate-200 flex items-center justify-between cursor-pointer"
                >
                  <span>Format Document</span>
                  <span className="text-[10px] text-slate-500 font-mono">Shift+Alt+F</span>
                </button>
                <button
                  onClick={() => { onOpenCommandPalette(); setActiveMenu(null); }}
                  className="w-full text-left px-3 py-1.5 hover:bg-slate-800 text-slate-200 flex items-center justify-between cursor-pointer"
                >
                  <span>Command Palette...</span>
                  <span className="text-[10px] text-slate-500 font-mono">Ctrl+Shift+P</span>
                </button>
              </div>
            )}
          </div>

          {/* Run Menu */}
          <div className="relative">
            <button
              onClick={() => setActiveMenu(activeMenu === 'run' ? null : 'run')}
              className={`px-2 py-1 rounded hover:bg-slate-800 hover:text-slate-100 transition-colors cursor-pointer ${
                activeMenu === 'run' ? 'bg-slate-800 text-white' : ''
              }`}
            >
              Run
            </button>
            {activeMenu === 'run' && (
              <div 
                className="absolute top-full left-0 mt-0.5 w-56 bg-slate-900 border border-slate-700/80 rounded-lg shadow-2xl py-1 z-50 text-xs"
                onMouseLeave={() => setActiveMenu(null)}
              >
                <button
                  onClick={() => { onRunCode('live-server'); setActiveMenu(null); }}
                  className="w-full text-left px-3 py-2 hover:bg-slate-800 text-emerald-300 font-medium flex items-center gap-2 cursor-pointer"
                >
                  <Play className="w-3.5 h-3.5 text-emerald-400 fill-current" />
                  <span>Run with Live Server (Port 5500)</span>
                </button>
                <button
                  onClick={() => { onRunCode('terminal'); setActiveMenu(null); }}
                  className="w-full text-left px-3 py-2 hover:bg-slate-800 text-cyan-300 flex items-center gap-2 cursor-pointer"
                >
                  <Terminal className="w-3.5 h-3.5 text-cyan-400" />
                  <span>Run Active File in Terminal</span>
                </button>
                <div className="h-px bg-slate-800 my-1" />
                <button
                  onClick={() => { onToggleLiveServer(); setActiveMenu(null); }}
                  className="w-full text-left px-3 py-1.5 hover:bg-slate-800 text-slate-200 flex items-center gap-2 cursor-pointer"
                >
                  <Radio className="w-3.5 h-3.5 text-amber-400" />
                  <span>Toggle Live Preview Pane</span>
                </button>
              </div>
            )}
          </div>

          {/* Terminal Menu */}
          <div className="relative">
            <button
              onClick={() => setActiveMenu(activeMenu === 'terminal' ? null : 'terminal')}
              className={`px-2 py-1 rounded hover:bg-slate-800 hover:text-slate-100 transition-colors cursor-pointer ${
                activeMenu === 'terminal' ? 'bg-slate-800 text-white' : ''
              }`}
            >
              Terminal
            </button>
            {activeMenu === 'terminal' && (
              <div 
                className="absolute top-full left-0 mt-0.5 w-52 bg-slate-900 border border-slate-700/80 rounded-lg shadow-2xl py-1 z-50 text-xs"
                onMouseLeave={() => setActiveMenu(null)}
              >
                <button
                  onClick={() => { onToggleTerminal(); setActiveMenu(null); }}
                  className="w-full text-left px-3 py-1.5 hover:bg-slate-800 text-slate-200 flex items-center justify-between cursor-pointer"
                >
                  <span>Toggle Terminal</span>
                  <span className="text-[10px] text-slate-500 font-mono">Ctrl+`</span>
                </button>
                <button
                  onClick={() => { onRunCode('terminal'); setActiveMenu(null); }}
                  className="w-full text-left px-3 py-1.5 hover:bg-slate-800 text-cyan-300 flex items-center gap-2 cursor-pointer"
                >
                  <Terminal className="w-3.5 h-3.5" />
                  <span>Run in Node Terminal</span>
                </button>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Middle: Clean VS Code Command Palette Pill */}
      <div className="flex-1 max-w-sm mx-4">
        <button
          onClick={onOpenCommandPalette}
          className="w-full flex items-center justify-between px-3 py-1 bg-slate-900/90 hover:bg-slate-900 border border-slate-800 hover:border-slate-700 rounded-md text-slate-400 hover:text-slate-200 transition-all cursor-pointer group"
        >
          <div className="flex items-center gap-2 truncate">
            <Search className="w-3.5 h-3.5 text-slate-500 group-hover:text-cyan-400 transition-colors shrink-0" />
            <span className="truncate text-xs">mr00100-studio — Search files, commands</span>
          </div>
          <kbd className="px-1.5 py-0.5 text-[10px] bg-slate-950 border border-slate-800 rounded text-slate-400 font-mono shrink-0 ml-2">
            Ctrl+P
          </kbd>
        </button>
      </div>

      {/* Right: Unmistakable, Prominent Run Buttons + Essential Controls */}
      <div className="flex items-center gap-2 shrink-0">
        {/* 1. Dedicated "Run in Live Server" Button */}
        <button
          onClick={() => onRunCode('live-server')}
          className={`flex items-center gap-1.5 px-3 py-1 rounded text-xs font-semibold shadow-xs transition-all cursor-pointer ${
            isLiveServerRunning
              ? 'bg-emerald-600 hover:bg-emerald-500 text-white ring-2 ring-emerald-400/40'
              : 'bg-emerald-600 hover:bg-emerald-500 text-white'
          }`}
          title="Run Code with Live Server (Opens interactive hot-reloading browser preview)"
        >
          <Play className="w-3.5 h-3.5 fill-current" />
          <span>Run in Live Server</span>
          {isLiveServerRunning && (
            <span className="w-2 h-2 rounded-full bg-emerald-300 animate-ping ml-0.5" />
          )}
        </button>

        {/* 2. Dedicated "Run in Terminal" Button */}
        <button
          onClick={() => onRunCode('terminal')}
          className="flex items-center gap-1.5 px-3 py-1 bg-cyan-700 hover:bg-cyan-600 text-white rounded text-xs font-semibold transition-all shadow-xs cursor-pointer"
          title="Run Code in Integrated Terminal (Executes script with Node runtime)"
        >
          <Terminal className="w-3.5 h-3.5" />
          <span className="hidden sm:inline">Run in Terminal</span>
        </button>

        <div className="h-4 w-px bg-slate-800 mx-0.5" />

        {/* Download Project ZIP */}
        <button
          onClick={onDownloadZip}
          className="flex items-center gap-1.5 px-2.5 py-1 bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-200 hover:text-white rounded transition-colors cursor-pointer"
          title="Download entire project workspace as a ZIP file"
        >
          <Download className="w-3.5 h-3.5 text-cyan-400" />
          <span className="hidden md:inline font-medium">Download ZIP</span>
        </button>

        {/* Toggle Terminal Drawer */}
        <button
          onClick={onToggleTerminal}
          className={`p-1.5 rounded transition-colors cursor-pointer ${
            isTerminalOpen ? 'bg-slate-800 text-cyan-400' : 'hover:bg-slate-800 text-slate-400 hover:text-slate-200'
          }`}
          title="Toggle Terminal Console (Ctrl+`)"
        >
          <Terminal className="w-4 h-4" />
        </button>

        {/* Settings Button */}
        <button
          onClick={onOpenSettings}
          className="p-1.5 rounded hover:bg-slate-800 text-slate-400 hover:text-slate-100 transition-colors cursor-pointer"
          title="Open Settings & Preferences"
        >
          <Settings className="w-4 h-4" />
        </button>
      </div>
    </header>
  );
};
