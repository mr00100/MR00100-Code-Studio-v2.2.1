import React from 'react';
import { 
  Files, 
  Search, 
  GitBranch, 
  Bug, 
  Puzzle, 
  Rocket, 
  Settings, 
  Cloud, 
  TerminalSquare 
} from 'lucide-react';

export type SidebarTab = 'explorer' | 'search' | 'git' | 'debugger' | 'extensions' | 'deploy';

interface ActivityBarProps {
  activeTab: SidebarTab | null;
  onSelectTab: (tab: SidebarTab) => void;
  gitChangesCount: number;
  unresolvedProblemsCount: number;
  activeBreakpointsCount: number;
  onToggleTerminal: () => void;
  isTerminalOpen: boolean;
  onOpenSettings: () => void;
  onOpenCloudSync: () => void;
}

export const ActivityBar: React.FC<ActivityBarProps> = ({
  activeTab,
  onSelectTab,
  gitChangesCount,
  unresolvedProblemsCount,
  activeBreakpointsCount,
  onToggleTerminal,
  isTerminalOpen,
  onOpenSettings,
  onOpenCloudSync,
}) => {
  const topItems: { id: SidebarTab; label: string; icon: React.ReactNode; badge?: number; badgeColor?: string }[] = [
    { id: 'explorer', label: 'Explorer (Ctrl+Shift+E)', icon: <Files className="w-5 h-5" /> },
    { id: 'search', label: 'Search across files (Ctrl+Shift+F)', icon: <Search className="w-5 h-5" /> },
    { 
      id: 'git', 
      label: 'Source Control (Git)', 
      icon: <GitBranch className="w-5 h-5" />, 
      badge: gitChangesCount, 
      badgeColor: 'bg-cyan-500' 
    },
    { 
      id: 'debugger', 
      label: 'Run and Debug', 
      icon: <Bug className="w-5 h-5" />, 
      badge: activeBreakpointsCount > 0 ? activeBreakpointsCount : undefined,
      badgeColor: 'bg-rose-500'
    },
    { id: 'extensions', label: 'Extensions Marketplace', icon: <Puzzle className="w-5 h-5" /> },
    { id: 'deploy', label: 'Automated Deployment Pipeline', icon: <Rocket className="w-5 h-5" /> },
  ];

  return (
    <aside className="w-12 bg-slate-950/90 border-r border-slate-800/80 flex flex-col justify-between items-center py-2 select-none z-20 shrink-0 theme-activitybar">
      {/* Top Tab Icons */}
      <div className="flex flex-col items-center gap-1.5 w-full">
        {topItems.map(item => {
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => onSelectTab(item.id)}
              className={`relative w-10 h-10 rounded flex items-center justify-center transition-colors group cursor-pointer ${
                isActive 
                  ? 'text-cyan-400 bg-slate-900 border-l-2 border-cyan-400' 
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/50'
              }`}
              title={item.label}
            >
              {item.icon}
              {typeof item.badge === 'number' && item.badge > 0 && (
                <span className={`absolute top-1 right-1 min-w-[14px] h-[14px] px-1 rounded-full text-[9px] font-bold text-slate-950 flex items-center justify-center font-mono ${item.badgeColor || 'bg-cyan-500'}`}>
                  {item.badge}
                </span>
              )}
            </button>
          );
        })}
      </div>

      {/* Bottom Utilities */}
      <div className="flex flex-col items-center gap-1.5 w-full">
        <button
          onClick={onToggleTerminal}
          className={`w-10 h-10 rounded flex items-center justify-center transition-colors cursor-pointer ${
            isTerminalOpen ? 'text-cyan-400 bg-slate-900' : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/50'
          }`}
          title="Terminal (Ctrl+`)"
        >
          <TerminalSquare className="w-5 h-5" />
        </button>

        <button
          onClick={onOpenCloudSync}
          className="w-10 h-10 rounded flex items-center justify-center transition-colors cursor-pointer text-slate-400 hover:text-slate-200 hover:bg-slate-900/50"
          title="Cloud Synchronization & Workspace Storage"
        >
          <Cloud className="w-5 h-5" />
        </button>

        <button
          onClick={onOpenSettings}
          className="w-10 h-10 rounded flex items-center justify-center transition-colors cursor-pointer text-slate-400 hover:text-slate-200 hover:bg-slate-900/50"
          title="Studio Settings & Preferences"
        >
          <Settings className="w-5 h-5" />
        </button>
      </div>
    </aside>
  );
};
