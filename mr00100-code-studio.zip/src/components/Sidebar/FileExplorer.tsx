import React, { useState } from 'react';
import { 
  FileCode, 
  Folder, 
  FolderOpen, 
  FilePlus, 
  FolderPlus, 
  Trash2, 
  Edit2, 
  ChevronRight, 
  ChevronDown, 
  FileText, 
  FileJson, 
  Code, 
  Hash, 
  Download,
  RotateCcw,
  Sparkles,
  X
} from 'lucide-react';
import { WorkspaceFile } from '../../types';

interface FileExplorerProps {
  files: WorkspaceFile[];
  activeFileId: string | null;
  onSelectFile: (fileId: string) => void;
  onCreateFile: (path: string) => void;
  onDeleteFile: (fileId: string) => void;
  onRenameFile: (fileId: string, newPath: string) => void;
  onClearAllFiles: () => void;
  onDownloadZip: () => void;
  stagedFiles: string[];
  projectName: string;
}

export const FileExplorer: React.FC<FileExplorerProps> = ({
  files,
  activeFileId,
  onSelectFile,
  onCreateFile,
  onDeleteFile,
  onRenameFile,
  onClearAllFiles,
  onDownloadZip,
  stagedFiles,
  projectName,
}) => {
  const [isCreatingFile, setIsCreatingFile] = useState(false);
  const [isCreatingFolder, setIsCreatingFolder] = useState(false);
  const [newFileName, setNewFileName] = useState('');
  const [newFolderName, setNewFolderName] = useState('');
  const [editingFileId, setEditingFileId] = useState<string | null>(null);
  const [renameValue, setRenameValue] = useState('');
  const [collapsedFolders, setCollapsedFolders] = useState<Record<string, boolean>>({});

  const getFileIcon = (fileName: string) => {
    if (fileName.endsWith('.tsx') || fileName.endsWith('.jsx')) {
      return <FileCode className="w-4 h-4 text-cyan-400 shrink-0" />;
    }
    if (fileName.endsWith('.ts') || fileName.endsWith('.js')) {
      return <Code className="w-4 h-4 text-blue-400 shrink-0" />;
    }
    if (fileName.endsWith('.json')) {
      return <FileJson className="w-4 h-4 text-amber-400 shrink-0" />;
    }
    if (fileName.endsWith('.css') || fileName.endsWith('.scss')) {
      return <Hash className="w-4 h-4 text-sky-400 shrink-0" />;
    }
    if (fileName.endsWith('.md')) {
      return <FileText className="w-4 h-4 text-emerald-400 shrink-0" />;
    }
    return <FileCode className="w-4 h-4 text-slate-400 shrink-0" />;
  };

  const handleCreateFileSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newFileName.trim()) {
      setIsCreatingFile(false);
      return;
    }
    onCreateFile(newFileName.trim());
    setNewFileName('');
    setIsCreatingFile(false);
  };

  const handleCreateFolderSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newFolderName.trim()) {
      setIsCreatingFolder(false);
      return;
    }
    // Create folder by placing a .gitkeep placeholder inside it
    const folderPath = newFolderName.trim().replace(/\/$/, '');
    onCreateFile(`${folderPath}/.gitkeep`);
    setNewFolderName('');
    setIsCreatingFolder(false);
  };

  const handleRenameSubmit = (e: React.FormEvent, fileId: string) => {
    e.preventDefault();
    if (!renameValue.trim()) {
      setEditingFileId(null);
      return;
    }
    onRenameFile(fileId, renameValue.trim());
    setEditingFileId(null);
  };

  return (
    <div className="h-full flex flex-col bg-slate-900/90 text-slate-300 text-xs select-none theme-sidebar">
      {/* Header toolbar */}
      <div className="h-9 px-3 border-b border-slate-800/80 flex items-center justify-between font-semibold tracking-wider text-[11px] text-slate-400 uppercase shrink-0">
        <span className="truncate">Files & Workspace</span>
        <div className="flex items-center gap-1">
          {/* New File */}
          <button
            onClick={() => {
              setIsCreatingFile(true);
              setIsCreatingFolder(false);
            }}
            className="p-1 hover:bg-slate-800 rounded text-slate-400 hover:text-cyan-300 transition-colors cursor-pointer"
            title="Create New File"
          >
            <FilePlus className="w-3.5 h-3.5" />
          </button>

          {/* New Folder */}
          <button
            onClick={() => {
              setIsCreatingFolder(true);
              setIsCreatingFile(false);
            }}
            className="p-1 hover:bg-slate-800 rounded text-slate-400 hover:text-cyan-300 transition-colors cursor-pointer"
            title="Create New Folder"
          >
            <FolderPlus className="w-3.5 h-3.5" />
          </button>

          {/* Download ZIP */}
          <button
            onClick={onDownloadZip}
            className="p-1 hover:bg-slate-800 rounded text-slate-400 hover:text-emerald-400 transition-colors cursor-pointer"
            title="Download Workspace (ZIP)"
          >
            <Download className="w-3.5 h-3.5" />
          </button>

          {/* Clear / Empty Workspace */}
          {files.length > 0 && (
            <button
              onClick={() => {
                if (confirm('Clear all files and start with an empty workspace?')) {
                  onClearAllFiles();
                }
              }}
              className="p-1 hover:bg-slate-800 rounded text-slate-400 hover:text-rose-400 transition-colors cursor-pointer"
              title="Clear All Files (Empty Workspace)"
            >
              <RotateCcw className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      </div>

      {/* New file input form */}
      {isCreatingFile && (
        <form onSubmit={handleCreateFileSubmit} className="p-2 border-b border-slate-800 bg-slate-950 flex flex-col gap-1">
          <div className="flex items-center justify-between text-[10px] text-cyan-400 font-medium">
            <span>New File Name</span>
            <button type="button" onClick={() => setIsCreatingFile(false)} className="text-slate-500 hover:text-slate-300">
              <X className="w-3 h-3" />
            </button>
          </div>
          <div className="flex items-center gap-1.5">
            <FilePlus className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
            <input
              type="text"
              value={newFileName}
              onChange={e => setNewFileName(e.target.value)}
              placeholder="e.g. src/App.tsx, styles.css"
              autoFocus
              className="w-full bg-slate-900 border border-cyan-500/60 rounded px-2 py-1 text-xs text-white focus:outline-none font-mono"
            />
          </div>
        </form>
      )}

      {/* New folder input form */}
      {isCreatingFolder && (
        <form onSubmit={handleCreateFolderSubmit} className="p-2 border-b border-slate-800 bg-slate-950 flex flex-col gap-1">
          <div className="flex items-center justify-between text-[10px] text-cyan-400 font-medium">
            <span>New Folder Name</span>
            <button type="button" onClick={() => setIsCreatingFolder(false)} className="text-slate-500 hover:text-slate-300">
              <X className="w-3 h-3" />
            </button>
          </div>
          <div className="flex items-center gap-1.5">
            <FolderPlus className="w-3.5 h-3.5 text-amber-400 shrink-0" />
            <input
              type="text"
              value={newFolderName}
              onChange={e => setNewFolderName(e.target.value)}
              placeholder="e.g. src/components, utils"
              autoFocus
              className="w-full bg-slate-900 border border-amber-500/60 rounded px-2 py-1 text-xs text-white focus:outline-none font-mono"
            />
          </div>
        </form>
      )}

      {/* Files list */}
      <div className="flex-1 overflow-y-auto p-1 space-y-0.5">
        {files.length === 0 ? (
          <div className="p-6 text-center space-y-3 text-slate-500">
            <p className="text-xs">Workspace is empty.</p>
            <div className="flex flex-col gap-2">
              <button
                onClick={() => onCreateFile('src/App.tsx')}
                className="px-3 py-1.5 bg-cyan-600/30 hover:bg-cyan-600/50 text-cyan-300 border border-cyan-500/40 rounded-lg text-xs font-medium transition-colors cursor-pointer"
              >
                + Create src/App.tsx
              </button>
              <button
                onClick={() => onCreateFile('index.html')}
                className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-xs font-medium transition-colors cursor-pointer"
              >
                + Create index.html
              </button>
            </div>
          </div>
        ) : (
          files.map(file => {
            const isActive = activeFileId === file.id;
            const isStaged = stagedFiles.includes(file.path);
            const isEditing = editingFileId === file.id;

            if (isEditing) {
              return (
                <form
                  key={file.id}
                  onSubmit={e => handleRenameSubmit(e, file.id)}
                  className="px-2 py-1 bg-slate-950 rounded flex items-center gap-2"
                >
                  {getFileIcon(file.name)}
                  <input
                    type="text"
                    value={renameValue}
                    onChange={e => setRenameValue(e.target.value)}
                    autoFocus
                    onBlur={() => setEditingFileId(null)}
                    className="w-full bg-slate-900 border border-cyan-500 rounded px-1.5 py-0.5 text-xs text-white focus:outline-none font-mono"
                  />
                </form>
              );
            }

            return (
              <div
                key={file.id}
                onClick={() => onSelectFile(file.id)}
                className={`group flex items-center justify-between px-2.5 py-1.5 rounded cursor-pointer transition-colors ${
                  isActive
                    ? 'bg-cyan-500/15 text-cyan-300 font-medium'
                    : 'hover:bg-slate-800/60 text-slate-300'
                }`}
              >
                <div className="flex items-center gap-2 min-w-0">
                  {getFileIcon(file.name)}
                  <span className="truncate text-xs">{file.path}</span>
                </div>

                <div className="flex items-center gap-1 shrink-0">
                  {/* Git Status Badge */}
                  {file.isModified && !isStaged && (
                    <span className="text-[10px] font-mono font-bold text-amber-400" title="Modified in working copy">
                      M
                    </span>
                  )}
                  {isStaged && (
                    <span className="text-[10px] font-mono font-bold text-cyan-400" title="Staged for commit">
                      S
                    </span>
                  )}

                  {/* Context actions */}
                  <div className="hidden group-hover:flex items-center gap-0.5 ml-1">
                    <button
                      onClick={e => {
                        e.stopPropagation();
                        setEditingFileId(file.id);
                        setRenameValue(file.path);
                      }}
                      className="p-0.5 hover:text-cyan-300 text-slate-400"
                      title="Rename"
                    >
                      <Edit2 className="w-3 h-3" />
                    </button>
                    <button
                      onClick={e => {
                        e.stopPropagation();
                        if (confirm(`Delete ${file.path}?`)) {
                          onDeleteFile(file.id);
                        }
                      }}
                      className="p-0.5 hover:text-rose-400 text-slate-400"
                      title="Delete"
                    >
                      <Trash2 className="w-3 h-3" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Explorer Footer Quick Action */}
      <div className="p-2 border-t border-slate-800/80 bg-slate-950/60 flex items-center justify-between text-[11px] text-slate-400">
        <span>{files.length} file{files.length === 1 ? '' : 's'}</span>
        <button
          onClick={onDownloadZip}
          className="flex items-center gap-1 text-emerald-400 hover:text-emerald-300 cursor-pointer font-medium"
        >
          <Download className="w-3 h-3" />
          <span>Export ZIP</span>
        </button>
      </div>
    </div>
  );
};
