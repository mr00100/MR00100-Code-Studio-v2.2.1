import React, { useState } from 'react';
import { 
  Play, 
  Pause, 
  RotateCcw, 
  StepForward, 
  CornerDownRight, 
  Bug, 
  Trash2, 
  Plus, 
  CheckCircle2, 
  CircleDot,
  Radio,
  Terminal,
  ExternalLink
} from 'lucide-react';
import { Breakpoint } from '../../types';

interface DebuggerPanelProps {
  breakpoints: Breakpoint[];
  onToggleBreakpoint: (bpId: string) => void;
  onRemoveBreakpoint: (bpId: string) => void;
  onSelectFileAndLine: (filePath: string, line: number) => void;
  onRunCode?: (mode: 'live-server' | 'terminal') => void;
  isLiveServerRunning?: boolean;
  activeFileName?: string;
}

export const DebuggerPanel: React.FC<DebuggerPanelProps> = ({
  breakpoints,
  onToggleBreakpoint,
  onRemoveBreakpoint,
  onSelectFileAndLine,
  onRunCode,
  isLiveServerRunning = false,
  activeFileName = 'src/App.tsx',
}) => {
  const [isRunning, setIsRunning] = useState(false);
  const [watchExpressions, setWatchExpressions] = useState<string[]>([
    'activeTab',
    'metricCount',
    'isLive',
  ]);
  const [newWatch, setNewWatch] = useState('');
  const [isAddingWatch, setIsAddingWatch] = useState(false);

  const [simulatedVariables] = useState<Record<string, string>>({
    'activeTab': '"overview"',
    'metricCount': '1420',
    'isLive': 'true',
    'PORT': '5500',
    'NODE_ENV': '"development"',
  });

  const handleAddWatchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newWatch.trim()) return;
    setWatchExpressions(prev => [...prev, newWatch.trim()]);
    setNewWatch('');
    setIsAddingWatch(false);
  };

  return (
    <div className="h-full flex flex-col bg-slate-900/90 text-slate-300 text-xs select-none font-sans">
      {/* Header */}
      <div className="h-9 px-3 border-b border-slate-800/80 flex items-center justify-between font-semibold tracking-wider text-[11px] text-slate-400 uppercase shrink-0">
        <span>Run & Debug</span>
        <div className="flex items-center gap-1">
          <button
            onClick={() => setIsRunning(!isRunning)}
            className={`p-1 rounded cursor-pointer ${isRunning ? 'text-amber-400 hover:bg-slate-800' : 'text-emerald-400 hover:bg-slate-800'}`}
            title={isRunning ? 'Pause execution' : 'Start debugging (F5)'}
          >
            {isRunning ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
          </button>
          <button
            onClick={() => {
              setIsRunning(false);
              setTimeout(() => setIsRunning(true), 200);
            }}
            className="p-1 hover:bg-slate-800 rounded text-slate-400 hover:text-slate-100 cursor-pointer"
            title="Restart debugger"
          >
            <RotateCcw className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-3 space-y-4">
        {/* Prominent Run Options (VS Code Launch Configurations) */}
        <div className="space-y-2">
          <div className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
            Launch Targets
          </div>

          {/* Run in Live Server Card */}
          <div className="p-3 bg-slate-950 border border-slate-800 hover:border-emerald-500/50 rounded-lg space-y-2 transition-colors shadow-sm">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Radio className={`w-4 h-4 ${isLiveServerRunning ? 'text-emerald-400 animate-pulse' : 'text-slate-400'}`} />
                <span className="font-semibold text-slate-200 text-xs">Live Server (Port 5500)</span>
              </div>
              <span className={`text-[10px] font-mono px-1.5 py-0.5 rounded border ${
                isLiveServerRunning 
                  ? 'bg-emerald-950/80 text-emerald-300 border-emerald-800'
                  : 'bg-slate-900 text-slate-400 border-slate-800'
              }`}>
                {isLiveServerRunning ? '● Live' : '○ Stopped'}
              </span>
            </div>
            <p className="text-[11px] text-slate-400 leading-relaxed">
              Launch instant hot-reloading browser preview on localhost:5500.
            </p>
            {onRunCode && (
              <button
                onClick={() => onRunCode('live-server')}
                className="w-full py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-semibold rounded text-xs flex items-center justify-center gap-2 shadow-xs cursor-pointer transition-colors"
              >
                <Play className="w-3.5 h-3.5 fill-current" />
                <span>Run in Live Server</span>
              </button>
            )}
          </div>

          {/* Run in Terminal Card */}
          <div className="p-3 bg-slate-950 border border-slate-800 hover:border-cyan-500/50 rounded-lg space-y-2 transition-colors shadow-sm">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Terminal className="w-4 h-4 text-cyan-400" />
                <span className="font-semibold text-slate-200 text-xs">Interactive Terminal</span>
              </div>
              <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-cyan-950/80 text-cyan-300 border border-cyan-800">
                CLI Ready
              </span>
            </div>
            <p className="text-[11px] text-slate-400 leading-relaxed">
              Execute <span className="font-mono text-cyan-300">{activeFileName}</span> directly in Node.js virtual shell.
            </p>
            {onRunCode && (
              <button
                onClick={() => onRunCode('terminal')}
                className="w-full py-1.5 bg-cyan-700 hover:bg-cyan-600 text-white font-semibold rounded text-xs flex items-center justify-center gap-2 shadow-xs cursor-pointer transition-colors"
              >
                <Terminal className="w-3.5 h-3.5" />
                <span>Run Code in Terminal</span>
              </button>
            )}
          </div>
        </div>

        {/* Execution Status Card */}
        <div className="p-2.5 bg-slate-950/80 border border-slate-800 rounded-lg space-y-2">
          <div className="flex items-center justify-between">
            <span className="font-medium text-slate-200">Debug Controller</span>
            <span className={`text-[10px] font-mono px-2 py-0.5 rounded ${
              isRunning ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30' : 'bg-slate-800 text-slate-400'
            }`}>
              {isRunning ? 'Attached :5500' : 'Idle'}
            </span>
          </div>

          <div className="flex items-center justify-center gap-2 pt-1 border-t border-slate-800/80">
            <button
              onClick={() => setIsRunning(!isRunning)}
              className="p-1.5 rounded hover:bg-slate-800 text-emerald-400 cursor-pointer"
              title="Continue (F5)"
            >
              <Play className="w-3.5 h-3.5 fill-current" />
            </button>
            <button
              className="p-1.5 rounded hover:bg-slate-800 text-cyan-400 cursor-pointer"
              title="Step Over (F10)"
            >
              <StepForward className="w-3.5 h-3.5" />
            </button>
            <button
              className="p-1.5 rounded hover:bg-slate-800 text-indigo-400 cursor-pointer"
              title="Step Into (F11)"
            >
              <CornerDownRight className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={() => setIsRunning(false)}
              className="p-1.5 rounded hover:bg-slate-800 text-rose-400 cursor-pointer"
              title="Stop Debugger (Shift+F5)"
            >
              <RotateCcw className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Watch Expressions */}
        <div className="space-y-1.5">
          <div className="flex items-center justify-between text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
            <span>Watch Expressions</span>
            <button
              onClick={() => setIsAddingWatch(!isAddingWatch)}
              className="text-cyan-400 hover:text-cyan-300 text-xs cursor-pointer"
              title="Add expression"
            >
              <Plus className="w-3.5 h-3.5" />
            </button>
          </div>

          {isAddingWatch && (
            <form onSubmit={handleAddWatchSubmit} className="pt-1">
              <input
                type="text"
                value={newWatch}
                onChange={e => setNewWatch(e.target.value)}
                placeholder="Expression (e.g. activeTab)..."
                autoFocus
                className="w-full bg-slate-950 border border-cyan-500 rounded px-2 py-1 text-xs text-slate-100 focus:outline-none font-mono"
              />
            </form>
          )}

          <div className="p-2 bg-slate-950/60 border border-slate-800/80 rounded-lg space-y-1 font-mono text-[11px]">
            {watchExpressions.map(expr => (
              <div key={expr} className="flex items-center justify-between group">
                <span className="text-slate-400 truncate">{expr}:</span>
                <span className="text-emerald-400 font-bold truncate">
                  {simulatedVariables[expr] || 'undefined'}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Breakpoints list */}
        <div className="space-y-1.5">
          <div className="flex items-center justify-between text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
            <span>Breakpoints ({breakpoints.length})</span>
          </div>

          <div className="p-2 bg-slate-950/60 border border-slate-800/80 rounded-lg space-y-1">
            {breakpoints.length === 0 ? (
              <div className="text-[11px] text-slate-500 italic py-1">
                No breakpoints set. Click editor line margin to set.
              </div>
            ) : (
              breakpoints.map(bp => (
                <div
                  key={bp.id}
                  className="flex items-center justify-between p-1 hover:bg-slate-800/50 rounded transition-colors group cursor-pointer"
                  onClick={() => onSelectFileAndLine(bp.file, bp.line)}
                >
                  <div className="flex items-center gap-2 truncate">
                    <input
                      type="checkbox"
                      checked={bp.enabled}
                      onChange={e => {
                        e.stopPropagation();
                        onToggleBreakpoint(bp.id);
                      }}
                      className="rounded border-slate-700 text-rose-500 focus:ring-0 w-3.5 h-3.5 bg-slate-900 cursor-pointer"
                    />
                    <CircleDot className="w-3.5 h-3.5 text-rose-500 shrink-0" />
                    <span className="text-slate-300 font-mono text-[11px] truncate">
                      {bp.file}:{bp.line}
                    </span>
                  </div>

                  <button
                    onClick={e => {
                      e.stopPropagation();
                      onRemoveBreakpoint(bp.id);
                    }}
                    className="opacity-0 group-hover:opacity-100 text-slate-500 hover:text-rose-400 p-0.5 cursor-pointer"
                    title="Remove breakpoint"
                  >
                    <Trash2 className="w-3 h-3" />
                  </button>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
