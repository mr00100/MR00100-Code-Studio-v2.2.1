import React, { useState } from 'react';
import { Search, Replace, CaseSensitive, FileCode, Check } from 'lucide-react';
import { WorkspaceFile } from '../../types';

interface GlobalSearchProps {
  files: WorkspaceFile[];
  onSelectFileAndLine: (fileId: string, line: number) => void;
  onReplaceInFile: (fileId: string, oldText: string, newText: string) => void;
}

export const GlobalSearch: React.FC<GlobalSearchProps> = ({
  files,
  onSelectFileAndLine,
  onReplaceInFile,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [replaceTerm, setReplaceTerm] = useState('');
  const [matchCase, setMatchCase] = useState(false);
  const [showReplace, setShowReplace] = useState(false);

  // Search results
  const results = React.useMemo(() => {
    if (!searchTerm.trim()) return [];

    const matches: {
      file: WorkspaceFile;
      matches: { line: number; text: string; index: number }[];
    }[] = [];

    files.forEach(file => {
      const lines = file.content.split('\n');
      const fileMatches: { line: number; text: string; index: number }[] = [];

      lines.forEach((lineText, idx) => {
        const textToSearch = matchCase ? lineText : lineText.toLowerCase();
        const query = matchCase ? searchTerm : searchTerm.toLowerCase();

        if (textToSearch.includes(query)) {
          fileMatches.push({
            line: idx + 1,
            text: lineText.trim(),
            index: textToSearch.indexOf(query),
          });
        }
      });

      if (fileMatches.length > 0) {
        matches.push({ file, matches: fileMatches });
      }
    });

    return matches;
  }, [files, searchTerm, matchCase]);

  const totalMatches = results.reduce((acc, curr) => acc + curr.matches.length, 0);

  const handleReplaceAllInFile = (fileId: string) => {
    if (!searchTerm) return;
    onReplaceInFile(fileId, searchTerm, replaceTerm);
  };

  return (
    <div className="h-full flex flex-col bg-slate-900/90 text-slate-300 text-xs select-none">
      <div className="h-9 px-3 border-b border-slate-800/80 flex items-center justify-between font-semibold tracking-wider text-[11px] text-slate-400 uppercase shrink-0">
        <span>Search Workspace</span>
        <button
          onClick={() => setShowReplace(!showReplace)}
          className={`p-1 rounded transition-colors ${showReplace ? 'text-cyan-400 bg-slate-800' : 'text-slate-400 hover:text-slate-200'}`}
          title="Toggle Replace"
        >
          <Replace className="w-3.5 h-3.5" />
        </button>
      </div>

      <div className="p-3 border-b border-slate-800/80 space-y-2">
        {/* Search input */}
        <div className="relative flex items-center">
          <input
            type="text"
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
            placeholder="Search across files..."
            className="w-full bg-slate-950 border border-slate-800 rounded px-2.5 py-1 text-xs text-slate-200 focus:outline-none focus:border-cyan-500 pr-8"
          />
          <button
            onClick={() => setMatchCase(!matchCase)}
            className={`absolute right-1.5 p-0.5 rounded text-[11px] font-bold ${
              matchCase ? 'text-cyan-400 bg-cyan-950/60' : 'text-slate-500 hover:text-slate-300'
            }`}
            title="Match Case"
          >
            <CaseSensitive className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Replace input */}
        {showReplace && (
          <div className="flex items-center gap-1.5">
            <input
              type="text"
              value={replaceTerm}
              onChange={e => setReplaceTerm(e.target.value)}
              placeholder="Replace with..."
              className="flex-1 bg-slate-950 border border-slate-800 rounded px-2.5 py-1 text-xs text-slate-200 focus:outline-none focus:border-cyan-500"
            />
            <button
              onClick={() => {
                results.forEach(r => handleReplaceAllInFile(r.file.id));
              }}
              disabled={results.length === 0}
              className="px-2 py-1 bg-cyan-600/30 hover:bg-cyan-600/50 text-cyan-300 border border-cyan-500/40 rounded text-[11px] font-medium transition-colors disabled:opacity-40 cursor-pointer"
              title="Replace All across workspace"
            >
              All
            </button>
          </div>
        )}

        {searchTerm && (
          <div className="text-[11px] text-slate-400 flex items-center justify-between">
            <span>
              {totalMatches} result{totalMatches === 1 ? '' : 's'} in {results.length} file{results.length === 1 ? '' : 's'}
            </span>
          </div>
        )}
      </div>

      {/* Results list */}
      <div className="flex-1 overflow-y-auto p-2 space-y-3">
        {results.map(({ file, matches }) => (
          <div key={file.id} className="space-y-1">
            <div className="flex items-center justify-between px-1.5 py-1 bg-slate-950/60 rounded border border-slate-800/80">
              <div className="flex items-center gap-1.5 font-medium text-slate-200 truncate">
                <FileCode className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                <span className="truncate">{file.path}</span>
              </div>
              <span className="text-[10px] font-mono text-slate-400 bg-slate-900 px-1.5 rounded">
                {matches.length}
              </span>
            </div>

            <div className="space-y-0.5 pl-2">
              {matches.map((m, idx) => (
                <button
                  key={idx}
                  onClick={() => onSelectFileAndLine(file.id, m.line)}
                  className="w-full text-left p-1 rounded hover:bg-slate-800/80 flex items-center gap-2 group transition-colors text-[11px]"
                >
                  <span className="font-mono text-slate-500 group-hover:text-cyan-400 shrink-0 w-6">
                    {m.line}
                  </span>
                  <span className="truncate text-slate-300 font-mono">{m.text}</span>
                </button>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
