import React, { useState } from 'react';
import { 
  Rocket, 
  CheckCircle2, 
  Loader2, 
  ExternalLink, 
  Copy, 
  Server, 
  Globe, 
  ShieldCheck, 
  Plus, 
  Trash2, 
  Terminal, 
  Check 
} from 'lucide-react';
import { DeploymentTarget } from '../../types';

interface DeploymentPipelineProps {
  deploymentTargets: DeploymentTarget[];
  onTriggerDeploy: (targetId: string) => void;
  onAddEnvVar: (targetId: string, key: string, value: string) => void;
  onRemoveEnvVar: (targetId: string, key: string) => void;
}

export const DeploymentPipeline: React.FC<DeploymentPipelineProps> = ({
  deploymentTargets,
  onTriggerDeploy,
  onAddEnvVar,
  onRemoveEnvVar,
}) => {
  const [selectedTargetId, setSelectedTargetId] = useState<string>(deploymentTargets[0]?.id || 'vercel');
  const [newEnvKey, setNewEnvKey] = useState('');
  const [newEnvVal, setNewEnvVal] = useState('');
  const [copiedUrl, setCopiedUrl] = useState(false);

  const currentTarget = deploymentTargets.find(t => t.id === selectedTargetId) || deploymentTargets[0];

  const handleAddEnv = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newEnvKey.trim()) return;
    onAddEnvVar(currentTarget.id, newEnvKey.trim().toUpperCase(), newEnvVal.trim());
    setNewEnvKey('');
    setNewEnvVal('');
  };

  const handleCopy = (url: string) => {
    navigator.clipboard.writeText(url);
    setCopiedUrl(true);
    setTimeout(() => setCopiedUrl(false), 2000);
  };

  return (
    <div className="h-full flex flex-col bg-slate-900/90 text-slate-300 text-xs select-none">
      {/* Header */}
      <div className="h-9 px-3 border-b border-slate-800/80 flex items-center justify-between font-semibold tracking-wider text-[11px] text-slate-400 uppercase shrink-0">
        <span>Automated Deployment</span>
        <span className={`text-[10px] font-mono px-2 py-0.5 rounded capitalize ${
          currentTarget.status === 'live'
            ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
            : currentTarget.status === 'building' || currentTarget.status === 'deploying'
            ? 'bg-cyan-500/20 text-cyan-400 border border-cyan-500/30'
            : 'bg-slate-800 text-slate-400'
        }`}>
          {currentTarget.status}
        </span>
      </div>

      <div className="flex-1 overflow-y-auto p-3 space-y-4">
        {/* Target Provider Selector */}
        <div className="space-y-1.5">
          <label className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
            Target Cloud Provider
          </label>
          <div className="grid grid-cols-3 gap-1.5">
            {deploymentTargets.map(target => (
              <button
                key={target.id}
                onClick={() => setSelectedTargetId(target.id)}
                className={`p-2 rounded-lg border text-left transition-colors cursor-pointer ${
                  selectedTargetId === target.id
                    ? 'bg-cyan-500/15 border-cyan-500/50 text-cyan-200'
                    : 'bg-slate-950/60 border-slate-800 text-slate-400 hover:text-slate-200 hover:bg-slate-900'
                }`}
              >
                <div className="font-semibold text-xs truncate">{target.name}</div>
                <div className="text-[10px] text-slate-500 capitalize">{target.provider}</div>
              </button>
            ))}
          </div>
        </div>

        {/* Deploy Action Card */}
        <div className="p-3 bg-slate-950/80 border border-slate-800 rounded-xl space-y-3">
          <div className="flex items-center justify-between">
            <div>
              <h4 className="font-semibold text-slate-100 text-xs">{currentTarget.name} Production</h4>
              <p className="text-[11px] text-slate-400">
                {currentTarget.lastDeployedAt ? `Last deployed: ${currentTarget.lastDeployedAt}` : 'Never deployed'}
              </p>
            </div>
            <button
              onClick={() => onTriggerDeploy(currentTarget.id)}
              disabled={currentTarget.status === 'building' || currentTarget.status === 'deploying'}
              className="px-3.5 py-1.5 bg-gradient-to-r from-cyan-600 to-indigo-600 hover:from-cyan-500 hover:to-indigo-500 disabled:opacity-50 text-white font-medium text-xs rounded-lg transition-all shadow-sm shadow-cyan-500/20 flex items-center gap-1.5 cursor-pointer disabled:cursor-not-allowed"
            >
              {currentTarget.status === 'building' || currentTarget.status === 'deploying' ? (
                <>
                  <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  <span>Deploying...</span>
                </>
              ) : (
                <>
                  <Rocket className="w-3.5 h-3.5" />
                  <span>Deploy Now</span>
                </>
              )}
            </button>
          </div>

          {/* Deployment Live URL Card */}
          {currentTarget.status === 'live' && (
            <div className="p-2 bg-emerald-950/30 border border-emerald-500/30 rounded-lg flex items-center justify-between text-xs">
              <div className="flex items-center gap-2 truncate">
                <Globe className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                <a
                  href={currentTarget.liveUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="font-mono text-emerald-300 hover:underline truncate"
                >
                  {currentTarget.liveUrl}
                </a>
              </div>
              <div className="flex items-center gap-1 shrink-0">
                <button
                  onClick={() => handleCopy(currentTarget.liveUrl)}
                  className="p-1 hover:bg-emerald-900/50 rounded text-emerald-300"
                  title="Copy URL"
                >
                  {copiedUrl ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Deployment Stages */}
        <div className="space-y-2">
          <div className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
            Pipeline Stages
          </div>
          <div className="space-y-1.5 font-mono text-[11px]">
            <div className="flex items-center justify-between p-2 rounded bg-slate-950/60 border border-slate-800">
              <span className="flex items-center gap-2 text-slate-300">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                1. Typecheck & Lint Scanner
              </span>
              <span className="text-slate-500 text-[10px]">PASS</span>
            </div>
            <div className="flex items-center justify-between p-2 rounded bg-slate-950/60 border border-slate-800">
              <span className="flex items-center gap-2 text-slate-300">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                2. Tree-Shaking & Bundle Optimization
              </span>
              <span className="text-slate-500 text-[10px]">142 kB</span>
            </div>
            <div className="flex items-center justify-between p-2 rounded bg-slate-950/60 border border-slate-800">
              <span className="flex items-center gap-2 text-slate-300">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                3. Edge Route & Container Provisioning
              </span>
              <span className="text-slate-500 text-[10px]">READY</span>
            </div>
          </div>
        </div>

        {/* Environment Variables */}
        <div className="space-y-2">
          <div className="flex items-center justify-between text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
            <span>Environment Variables</span>
            <span className="text-slate-500 font-mono text-[10px]">{currentTarget.envVars.length} set</span>
          </div>

          <form onSubmit={handleAddEnv} className="flex gap-1.5">
            <input
              type="text"
              value={newEnvKey}
              onChange={e => setNewEnvKey(e.target.value)}
              placeholder="KEY (e.g. API_KEY)"
              className="w-1/2 bg-slate-950 border border-slate-800 rounded px-2 py-1 text-xs text-slate-200 uppercase font-mono focus:outline-none focus:border-cyan-500"
            />
            <input
              type="text"
              value={newEnvVal}
              onChange={e => setNewEnvVal(e.target.value)}
              placeholder="VALUE"
              className="flex-1 bg-slate-950 border border-slate-800 rounded px-2 py-1 text-xs text-slate-200 font-mono focus:outline-none focus:border-cyan-500"
            />
            <button
              type="submit"
              className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded text-xs transition-colors cursor-pointer"
            >
              Add
            </button>
          </form>

          <div className="space-y-1">
            {currentTarget.envVars.map(ev => (
              <div
                key={ev.key}
                className="flex items-center justify-between p-1.5 rounded bg-slate-950/40 border border-slate-800/80 font-mono text-[11px]"
              >
                <div className="flex items-center gap-2 truncate">
                  <span className="text-cyan-400 font-medium">{ev.key}</span>
                  <span className="text-slate-600">=</span>
                  <span className="text-slate-400 truncate">{ev.value}</span>
                </div>
                <button
                  onClick={() => onRemoveEnvVar(currentTarget.id, ev.key)}
                  className="text-slate-500 hover:text-rose-400 p-0.5"
                  title="Remove variable"
                >
                  <Trash2 className="w-3 h-3" />
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* Build Logs Stream */}
        <div className="space-y-1.5">
          <div className="flex items-center justify-between text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
            <span className="flex items-center gap-1.5">
              <Terminal className="w-3 h-3" />
              <span>Deployment Logs</span>
            </span>
          </div>

          <div className="p-2.5 bg-slate-950 rounded-lg border border-slate-800 font-mono text-[10px] text-slate-400 space-y-1 max-h-48 overflow-y-auto">
            {currentTarget.logs.map((log, i) => (
              <div key={i} className="leading-relaxed">
                {log}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
