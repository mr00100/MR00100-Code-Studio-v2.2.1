import React, { useState } from 'react';
import { 
  GitBranch, 
  GitCommit, 
  GitPullRequest, 
  Plus, 
  Minus, 
  RotateCcw, 
  ArrowUp, 
  ArrowDown, 
  Check, 
  FileCode, 
  Clock, 
  Share2, 
  ExternalLink,
  ChevronDown,
  ChevronRight,
  SplitSquareVertical
} from 'lucide-react';
import { GitState, WorkspaceFile } from '../../types';

interface SourceControlProps {
  gitState: GitState;
  files: WorkspaceFile[];
  onInitRepo: () => void;
  onStageFile: (filePath: string) => void;
  onUnstageFile: (filePath: string) => void;
  onStageAll: () => void;
  onUnstageAll: () => void;
  onCommit: (message: string) => void;
  onPush: () => void;
  onPull: () => void;
  onDiscardChanges: (filePath: string) => void;
  onViewDiff: (file: WorkspaceFile) => void;
  onSwitchBranch: (branchName: string) => void;
  onCreateBranch: (branchName: string) => void;
}

export const SourceControl: React.FC<SourceControlProps> = ({
  gitState,
  files,
  onInitRepo,
  onStageFile,
  onUnstageFile,
  onStageAll,
  onUnstageAll,
  onCommit,
  onPush,
  onPull,
  onDiscardChanges,
  onViewDiff,
  onSwitchBranch,
  onCreateBranch,
}) => {
  const [commitMessage, setCommitMessage] = useState('');
  const [showHistory, setShowHistory] = useState(false);
  const [newBranchInput, setNewBranchInput] = useState('');
  const [isAddingBranch, setIsAddingBranch] = useState(false);

  // Derive staged and unstaged files
  const stagedFileList = files.filter(f => gitState.stagedFiles.includes(f.path));
  const modifiedFileList = files.filter(f => f.isModified && !gitState.stagedFiles.includes(f.path));

  const handleCommitSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!commitMessage.trim()) return;
    if (gitState.stagedFiles.length === 0) {
      alert('Please stage at least one file before committing.');
      return;
    }
    onCommit(commitMessage.trim());
    setCommitMessage('');
  };

  const handleAddBranch = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newBranchInput.trim()) return;
    onCreateBranch(newBranchInput.trim());
    setNewBranchInput('');
    setIsAddingBranch(false);
  };

  if (!gitState.isInitialized) {
    return (
      <div className="h-full flex flex-col items-center justify-center p-6 text-center bg-slate-900/90 text-slate-300 select-none">
        <div className="w-12 h-12 rounded-xl bg-slate-800 flex items-center justify-center text-cyan-400 mb-4 border border-slate-700">
          <GitBranch className="w-6 h-6" />
        </div>
        <h3 className="font-semibold text-slate-100 text-sm mb-1">Source Control</h3>
        <p className="text-xs text-slate-400 mb-5 max-w-[200px]">
          No source control provider registered yet for this workspace.
        </p>
        <button
          onClick={onInitRepo}
          className="px-4 py-2 bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-medium rounded-lg transition-colors shadow-sm cursor-pointer"
        >
          Initialize Git Repository
        </button>
      </div>
    );
  }

  return (
    <div className="h-full flex flex-col bg-slate-900/90 text-slate-300 text-xs select-none overflow-hidden">
      {/* Header bar */}
      <div className="h-9 px-3 border-b border-slate-800/80 flex items-center justify-between font-semibold tracking-wider text-[11px] text-slate-400 uppercase shrink-0">
        <span>Source Control: Git</span>
        <div className="flex items-center gap-1">
          <button
            onClick={onPull}
            disabled={gitState.isPulling}
            className="p-1 hover:bg-slate-800 rounded text-slate-400 hover:text-slate-100 transition-colors disabled:opacity-50"
            title={`Pull updates from remote (${gitState.behindCount} behind)`}
          >
            <ArrowDown className={`w-3.5 h-3.5 ${gitState.isPulling ? 'animate-bounce text-cyan-400' : ''}`} />
          </button>
          <button
            onClick={onPush}
            disabled={gitState.isPushing}
            className="p-1 hover:bg-slate-800 rounded text-slate-400 hover:text-slate-100 transition-colors disabled:opacity-50"
            title={`Push commits to remote (${gitState.aheadCount} ahead)`}
          >
            <ArrowUp className={`w-3.5 h-3.5 ${gitState.isPushing ? 'animate-bounce text-emerald-400' : ''}`} />
          </button>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-3 space-y-4">
        {/* Branch switcher & sync banner */}
        <div className="bg-slate-950/80 border border-slate-800/90 rounded-lg p-2.5 space-y-2">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-1.5 text-xs">
              <GitBranch className="w-3.5 h-3.5 text-cyan-400" />
              <span className="font-mono text-cyan-300 font-medium">{gitState.currentBranch}</span>
            </div>
            <button
              onClick={() => setIsAddingBranch(!isAddingBranch)}
              className="text-[11px] text-cyan-400 hover:text-cyan-300 cursor-pointer"
            >
              {isAddingBranch ? 'Cancel' : '+ Branch'}
            </button>
          </div>

          {isAddingBranch && (
            <form onSubmit={handleAddBranch} className="pt-1">
              <input
                type="text"
                value={newBranchInput}
                onChange={e => setNewBranchInput(e.target.value)}
                placeholder="branch-name..."
                autoFocus
                className="w-full bg-slate-900 border border-cyan-500/50 rounded px-2 py-1 text-xs text-white focus:outline-none"
              />
            </form>
          )}

          <div className="flex items-center justify-between text-[11px] text-slate-400 pt-1 border-t border-slate-800/80">
            <span>Remote: origin/{gitState.currentBranch}</span>
            <div className="flex items-center gap-2 font-mono">
              <span className={gitState.aheadCount > 0 ? 'text-emerald-400' : 'text-slate-500'}>
                ↑{gitState.aheadCount}
              </span>
              <span className={gitState.behindCount > 0 ? 'text-amber-400' : 'text-slate-500'}>
                ↓{gitState.behindCount}
              </span>
            </div>
          </div>
        </div>

        {/* Commit message box */}
        <form onSubmit={handleCommitSubmit} className="space-y-2">
          <div className="relative">
            <textarea
              value={commitMessage}
              onChange={e => setCommitMessage(e.target.value)}
              placeholder="Commit message (Ctrl+Enter to commit)..."
              rows={2}
              className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-cyan-500/60 resize-none font-sans"
              onKeyDown={e => {
                if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
                  handleCommitSubmit(e);
                }
              }}
            />
          </div>

          <div className="flex gap-2">
            <button
              type="submit"
              disabled={gitState.stagedFiles.length === 0 || !commitMessage.trim()}
              className="flex-1 py-1.5 px-3 bg-cyan-600 hover:bg-cyan-500 disabled:bg-slate-800 disabled:text-slate-500 text-white font-medium text-xs rounded-lg transition-colors flex items-center justify-center gap-1.5 cursor-pointer disabled:cursor-not-allowed"
            >
              <GitCommit className="w-3.5 h-3.5" />
              <span>Commit ({gitState.stagedFiles.length})</span>
            </button>

            {gitState.aheadCount > 0 && (
              <button
                type="button"
                onClick={onPush}
                disabled={gitState.isPushing}
                className="py-1.5 px-2.5 bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-400 border border-emerald-500/30 font-medium text-xs rounded-lg transition-colors flex items-center gap-1 cursor-pointer"
                title="Push committed changes to remote repository"
              >
                <ArrowUp className="w-3 h-3" />
                <span>Push</span>
              </button>
            )}
          </div>
        </form>

        {/* Staged Changes Section */}
        <div className="space-y-1">
          <div className="flex items-center justify-between text-[11px] font-semibold text-slate-400 uppercase tracking-wider py-1">
            <span className="flex items-center gap-1">
              <span>Staged Changes</span>
              <span className="font-mono text-cyan-400">({stagedFileList.length})</span>
            </span>
            {stagedFileList.length > 0 && (
              <button
                onClick={onUnstageAll}
                className="text-slate-400 hover:text-slate-200 text-[11px] capitalize cursor-pointer flex items-center gap-0.5"
                title="Unstage all files"
              >
                <Minus className="w-3 h-3" /> Unstage All
              </button>
            )}
          </div>

          {stagedFileList.length === 0 ? (
            <div className="text-[11px] text-slate-500 italic px-2 py-1">
              No changes staged yet.
            </div>
          ) : (
            stagedFileList.map(file => (
              <div
                key={file.id}
                className="flex items-center justify-between p-1.5 rounded hover:bg-slate-800/70 group"
              >
                <div 
                  onClick={() => onViewDiff(file)}
                  className="flex items-center gap-1.5 min-w-0 cursor-pointer flex-1"
                >
                  <span className="font-mono text-[10px] text-cyan-400 font-bold">S</span>
                  <span className="truncate text-xs text-slate-200">{file.path}</span>
                </div>
                <div className="flex items-center gap-1 shrink-0">
                  <button
                    onClick={() => onViewDiff(file)}
                    className="p-1 hover:text-cyan-400 text-slate-400"
                    title="View Diff"
                  >
                    <SplitSquareVertical className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => onUnstageFile(file.path)}
                    className="p-1 hover:text-rose-400 text-slate-400"
                    title="Unstage file"
                  >
                    <Minus className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Working Directory Changes Section */}
        <div className="space-y-1">
          <div className="flex items-center justify-between text-[11px] font-semibold text-slate-400 uppercase tracking-wider py-1">
            <span className="flex items-center gap-1">
              <span>Changes</span>
              <span className="font-mono text-amber-400">({modifiedFileList.length})</span>
            </span>
            {modifiedFileList.length > 0 && (
              <button
                onClick={onStageAll}
                className="text-slate-400 hover:text-slate-200 text-[11px] capitalize cursor-pointer flex items-center gap-0.5"
                title="Stage all files"
              >
                <Plus className="w-3 h-3" /> Stage All
              </button>
            )}
          </div>

          {modifiedFileList.length === 0 ? (
            <div className="text-[11px] text-slate-500 italic px-2 py-1">
              Working directory clean.
            </div>
          ) : (
            modifiedFileList.map(file => (
              <div
                key={file.id}
                className="flex items-center justify-between p-1.5 rounded hover:bg-slate-800/70 group"
              >
                <div 
                  onClick={() => onViewDiff(file)}
                  className="flex items-center gap-1.5 min-w-0 cursor-pointer flex-1"
                >
                  <span className="font-mono text-[10px] text-amber-400 font-bold">M</span>
                  <span className="truncate text-xs text-slate-300">{file.path}</span>
                </div>
                <div className="flex items-center gap-1 shrink-0">
                  <button
                    onClick={() => onViewDiff(file)}
                    className="p-1 hover:text-cyan-400 text-slate-400"
                    title="View Diff"
                  >
                    <SplitSquareVertical className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => onDiscardChanges(file.path)}
                    className="p-1 hover:text-rose-400 text-slate-400"
                    title="Discard changes"
                  >
                    <RotateCcw className="w-3 h-3" />
                  </button>
                  <button
                    onClick={() => onStageFile(file.path)}
                    className="p-1 hover:text-emerald-400 text-slate-400"
                    title="Stage file"
                  >
                    <Plus className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Commit History Timeline */}
        <div className="pt-2 border-t border-slate-800/80">
          <button
            onClick={() => setShowHistory(!showHistory)}
            className="w-full flex items-center justify-between py-1 text-[11px] font-semibold text-slate-400 uppercase tracking-wider hover:text-slate-200 transition-colors"
          >
            <span className="flex items-center gap-1">
              <Clock className="w-3 h-3" />
              <span>Commit Log ({gitState.commits.length})</span>
            </span>
            {showHistory ? <ChevronDown className="w-3 h-3" /> : <ChevronRight className="w-3 h-3" />}
          </button>

          {showHistory && (
            <div className="mt-2 space-y-2">
              {gitState.commits.map(commit => (
                <div key={commit.hash} className="p-2 bg-slate-950/70 border border-slate-800/80 rounded-lg text-xs space-y-1">
                  <div className="flex items-center justify-between text-[10px] text-slate-400">
                    <span className="font-mono text-cyan-400">{commit.hash}</span>
                    <span>{commit.timestamp}</span>
                  </div>
                  <div className="font-medium text-slate-200 line-clamp-1">{commit.message}</div>
                  <div className="text-[10px] text-slate-500 font-mono flex items-center gap-1">
                    <span>by {commit.author}</span>
                    <span>&bull;</span>
                    <span>{commit.filesChanged.length} file(s)</span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
