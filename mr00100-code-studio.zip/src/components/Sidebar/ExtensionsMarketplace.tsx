import React, { useState } from 'react';
import { 
  Search, 
  Star, 
  Download, 
  Check, 
  Sparkles, 
  Moon, 
  Palette, 
  ShieldCheck, 
  Wand2, 
  GitBranch, 
  Terminal, 
  Settings, 
  CheckCircle2, 
  X,
  Radio,
  ExternalLink,
  Layers
} from 'lucide-react';
import { ExtensionModule } from '../../types';

interface ExtensionsMarketplaceProps {
  extensions: ExtensionModule[];
  onToggleExtension: (extId: string) => void;
}

export const ExtensionsMarketplace: React.FC<ExtensionsMarketplaceProps> = ({
  extensions,
  onToggleExtension,
}) => {
  const [search, setSearch] = useState('');
  const [activeCategory, setActiveCategory] = useState<'all' | 'installed' | 'theme' | 'linter' | 'formatter' | 'utility'>('all');
  const [selectedExtension, setSelectedExtension] = useState<ExtensionModule | null>(null);

  const getExtensionIcon = (iconName: string) => {
    switch (iconName) {
      case 'Radio': return <Radio className="w-5 h-5 text-emerald-400" />;
      case 'Moon': return <Moon className="w-5 h-5 text-indigo-400" />;
      case 'Palette': return <Palette className="w-5 h-5 text-amber-400" />;
      case 'Sparkles': return <Sparkles className="w-5 h-5 text-cyan-400" />;
      case 'ShieldCheck': return <ShieldCheck className="w-5 h-5 text-purple-400" />;
      case 'Wand2': return <Wand2 className="w-5 h-5 text-rose-400" />;
      case 'GitBranch': return <GitBranch className="w-5 h-5 text-emerald-400" />;
      default: return <Terminal className="w-5 h-5 text-blue-400" />;
    }
  };

  const installedExtensions = extensions.filter(e => e.enabled);

  const filteredExtensions = extensions.filter(ext => {
    if (activeCategory === 'installed' && !ext.enabled) return false;
    if (activeCategory !== 'all' && activeCategory !== 'installed' && ext.category !== activeCategory) return false;
    
    if (!search.trim()) return true;
    const q = search.toLowerCase();
    return (
      ext.displayName.toLowerCase().includes(q) ||
      ext.description.toLowerCase().includes(q) ||
      ext.author.toLowerCase().includes(q)
    );
  });

  return (
    <div className="h-full flex flex-col bg-slate-900/95 text-slate-300 text-xs select-none font-sans relative">
      {/* VS Code Extensions Title Bar */}
      <div className="h-9 px-3 border-b border-slate-800 flex items-center justify-between font-semibold tracking-wider text-[11px] text-slate-400 uppercase shrink-0">
        <span className="flex items-center gap-1.5">
          <span>Extensions</span>
          <span className="text-[10px] text-slate-500 font-mono font-normal">({filteredExtensions.length})</span>
        </span>
        <span className="font-mono text-emerald-400 text-[10px] bg-emerald-950/60 px-2 py-0.5 rounded border border-emerald-800/50">
          {installedExtensions.length} Installed
        </span>
      </div>

      {/* Search Bar & Category Filters */}
      <div className="p-2.5 border-b border-slate-800 space-y-2 bg-slate-950/40">
        <div className="relative">
          <Search className="w-3.5 h-3.5 text-slate-500 absolute left-2.5 top-2.5" />
          <input
            type="text"
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="Search Extensions in Marketplace..."
            className="w-full bg-slate-950 border border-slate-800 rounded-md pl-8 pr-7 py-1.5 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-cyan-500 font-sans transition-colors"
          />
          {search && (
            <button
              onClick={() => setSearch('')}
              className="absolute right-2 top-2 text-slate-500 hover:text-slate-300"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </div>

        {/* Clean Filter Pills */}
        <div className="flex items-center gap-1 overflow-x-auto no-scrollbar text-[11px] pt-0.5">
          {[
            { id: 'all', label: 'All' },
            { id: 'installed', label: `Installed (${installedExtensions.length})` },
            { id: 'utility', label: 'Tools' },
            { id: 'theme', label: 'Themes' },
            { id: 'linter', label: 'Linters' },
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveCategory(tab.id as typeof activeCategory)}
              className={`px-2 py-0.5 rounded whitespace-nowrap font-medium transition-colors cursor-pointer ${
                activeCategory === tab.id
                  ? 'bg-cyan-600 text-white font-semibold shadow-xs'
                  : 'bg-slate-950/80 text-slate-400 hover:text-slate-200 hover:bg-slate-800 border border-slate-800/80'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* Clean Extensions List */}
      <div className="flex-1 overflow-y-auto divide-y divide-slate-800/60">
        {filteredExtensions.length === 0 ? (
          <div className="p-6 text-center space-y-2 text-slate-500">
            <p className="text-xs">No extensions match your query.</p>
            <button
              onClick={() => { setSearch(''); setActiveCategory('all'); }}
              className="text-cyan-400 text-xs hover:underline cursor-pointer"
            >
              Reset filters
            </button>
          </div>
        ) : (
          filteredExtensions.map(ext => {
            const isInstalled = ext.enabled;

            return (
              <div
                key={ext.id}
                onClick={() => setSelectedExtension(ext)}
                className={`p-3 hover:bg-slate-800/60 transition-colors flex items-start gap-3 cursor-pointer group ${
                  selectedExtension?.id === ext.id ? 'bg-slate-800/80' : ''
                }`}
              >
                {/* Clean VS Code Icon Square */}
                <div 
                  className="w-10 h-10 rounded-lg bg-slate-950 border border-slate-800 flex items-center justify-center shrink-0 shadow-sm transition-transform group-hover:scale-105"
                  style={{ borderLeft: `3px solid ${ext.color || '#007acc'}` }}
                >
                  {getExtensionIcon(ext.icon)}
                </div>

                {/* Content Column */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between gap-1">
                    <div className="flex items-center gap-1.5 truncate">
                      <span className="font-semibold text-slate-200 text-xs truncate group-hover:text-cyan-300 transition-colors">
                        {ext.displayName}
                      </span>
                    </div>

                    {/* Blue Install / Muted Disable Button */}
                    <button
                      onClick={e => {
                        e.stopPropagation();
                        onToggleExtension(ext.id);
                      }}
                      className={`px-2.5 py-0.5 rounded text-[11px] font-semibold transition-all cursor-pointer shrink-0 ${
                        isInstalled
                          ? 'bg-slate-800 hover:bg-rose-950/80 text-slate-300 hover:text-rose-300 border border-slate-700 hover:border-rose-800'
                          : 'bg-[#007acc] hover:bg-[#0062a3] text-white shadow-xs'
                      }`}
                      title={isInstalled ? 'Click to Disable extension' : 'Click to Install extension'}
                    >
                      {isInstalled ? 'Disable' : 'Install'}
                    </button>
                  </div>

                  {/* Clean Description */}
                  <p className="text-[11px] text-slate-400 mt-1 line-clamp-2 leading-relaxed">
                    {ext.description}
                  </p>

                  {/* Author & Stats */}
                  <div className="flex items-center gap-3 mt-2 text-[10px] text-slate-500 font-mono">
                    <span className="text-slate-400 truncate">{ext.author}</span>
                    <span>&bull;</span>
                    <span className="flex items-center gap-0.5 text-amber-400 shrink-0">
                      <Star className="w-2.5 h-2.5 fill-current" />
                      {ext.rating}
                    </span>
                    <span>&bull;</span>
                    <span className="flex items-center gap-0.5 text-slate-400 shrink-0">
                      <Download className="w-2.5 h-2.5" />
                      {ext.downloads}
                    </span>
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* VS Code Extension Details Modal / Drawer */}
      {selectedExtension && (
        <div className="absolute inset-0 bg-slate-950/95 z-30 flex flex-col animate-in fade-in duration-150">
          {/* Header */}
          <div className="h-10 px-3 border-b border-slate-800 flex items-center justify-between bg-slate-900">
            <span className="font-semibold text-slate-200 text-xs">Extension Details</span>
            <button
              onClick={() => setSelectedExtension(null)}
              className="p-1 hover:bg-slate-800 rounded text-slate-400 hover:text-white cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Details Content */}
          <div className="flex-1 overflow-y-auto p-4 space-y-4">
            <div className="flex items-start gap-3.5">
              <div 
                className="w-14 h-14 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-center shrink-0 shadow-md"
                style={{ borderTop: `3px solid ${selectedExtension.color || '#007acc'}` }}
              >
                {getExtensionIcon(selectedExtension.icon)}
              </div>
              <div className="flex-1 min-w-0">
                <h3 className="text-sm font-bold text-slate-100">{selectedExtension.displayName}</h3>
                <div className="flex items-center gap-2 text-[11px] text-slate-400 mt-0.5">
                  <span className="text-cyan-400 font-medium">{selectedExtension.author}</span>
                  <span>&bull;</span>
                  <span>v{selectedExtension.version}</span>
                </div>
                <div className="flex items-center gap-3 text-[10px] text-slate-500 font-mono mt-1">
                  <span className="flex items-center gap-1 text-amber-400">
                    <Star className="w-3 h-3 fill-current" />
                    {selectedExtension.rating} / 5.0
                  </span>
                  <span>{selectedExtension.downloads} downloads</span>
                </div>
              </div>
            </div>

            {/* Action buttons */}
            <div className="flex items-center gap-2 pt-2">
              <button
                onClick={() => onToggleExtension(selectedExtension.id)}
                className={`px-4 py-1.5 rounded text-xs font-semibold cursor-pointer transition-colors ${
                  selectedExtension.enabled
                    ? 'bg-rose-900/60 hover:bg-rose-900 text-rose-200 border border-rose-700'
                    : 'bg-[#007acc] hover:bg-[#0062a3] text-white'
                }`}
              >
                {selectedExtension.enabled ? 'Disable' : 'Install'}
              </button>
              <span className={`text-[11px] font-mono px-2 py-1 rounded border ${
                selectedExtension.enabled
                  ? 'bg-emerald-950/60 text-emerald-400 border-emerald-800/60'
                  : 'bg-slate-900 text-slate-400 border-slate-800'
              }`}>
                {selectedExtension.enabled ? '● Active' : '○ Disabled'}
              </span>
            </div>

            {/* Description Card */}
            <div className="p-3 bg-slate-900/70 border border-slate-800 rounded-lg space-y-1.5">
              <div className="font-semibold text-slate-200 text-xs">Overview</div>
              <p className="text-xs text-slate-300 leading-relaxed">{selectedExtension.description}</p>
            </div>

            {/* Features */}
            <div className="p-3 bg-slate-900/70 border border-slate-800 rounded-lg space-y-2">
              <div className="font-semibold text-slate-200 text-xs">Features & Integration</div>
              <ul className="text-xs text-slate-400 space-y-1 list-disc list-inside">
                <li>Real-time integration with MR00100 workspace engine</li>
                <li>Zero-latency execution directly inside web sandbox</li>
                <li>Custom keybindings and context actions configured</li>
              </ul>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
