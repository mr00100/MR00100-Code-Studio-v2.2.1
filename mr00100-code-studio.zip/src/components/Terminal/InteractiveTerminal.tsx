import React, { useState, useRef, useEffect } from 'react';
import { 
  Terminal as TerminalIcon, 
  Trash2, 
  Play, 
  CornerDownLeft, 
  CheckCircle2, 
  AlertTriangle, 
  Info,
  Maximize2,
  Minimize2,
  X,
  Code2,
  Cpu,
  Layers,
  Sparkles
} from 'lucide-react';
import { TerminalEntry, Diagnostic, WorkspaceFile, GitState } from '../../types';
import { executeCode } from '../../utils/codeRunner';

interface InteractiveTerminalProps {
  isOpen: boolean;
  onClose: () => void;
  files: WorkspaceFile[];
  activeFileId: string | null;
  gitState: GitState;
  onStageFile: (path: string) => void;
  onCommit: (message: string) => void;
  onPush: () => void;
  onPull: () => void;
  onCreateFile: (path: string) => void;
  onDeleteFile: (fileId: string) => void;
  diagnostics: Diagnostic[];
  onTriggerDeploy: (provider: string) => void;
  onSelectFileAndLine?: (filePath: string, line: number) => void;
  forcedTab?: 'terminal' | 'problems' | 'output' | 'debug';
  commandToRun?: string | null;
  onClearCommandToRun?: () => void;
}

export const InteractiveTerminal: React.FC<InteractiveTerminalProps> = ({
  isOpen,
  onClose,
  files,
  activeFileId,
  gitState,
  onStageFile,
  onCommit,
  onPush,
  onPull,
  onCreateFile,
  onDeleteFile,
  onSelectFileAndLine,
  diagnostics,
  onTriggerDeploy,
  forcedTab,
  commandToRun,
  onClearCommandToRun,
}) => {
  const [activeTab, setActiveTab] = useState<'terminal' | 'problems' | 'output' | 'debug'>('terminal');
  const [isExpanded, setIsExpanded] = useState(false);
  const [inputVal, setInputVal] = useState('');
  const [historyIndex, setHistoryIndex] = useState(-1);
  const [commandHistory, setCommandHistory] = useState<string[]>([]);
  const [isExecuting, setIsExecuting] = useState(false);

  const activeFile = files.find(f => f.id === activeFileId) || (files.length > 0 ? files[0] : null);

  useEffect(() => {
    if (forcedTab) {
      setActiveTab(forcedTab);
    }
  }, [forcedTab]);

  const [terminalEntries, setTerminalEntries] = useState<TerminalEntry[]>([
    {
      id: 'init-1',
      type: 'system',
      text: '⚡ MR00100 Code Studio Terminal [Universal Multi-Language Runtime v3.0]',
      timestamp: new Date().toLocaleTimeString(),
    },
    {
      id: 'init-2',
      type: 'info',
      text: 'Support for Python 3, Node.js, C/C++, Java, Rust, Go, Bash, SQL. Type "run" or click [▶ Run Code] to execute.',
      timestamp: new Date().toLocaleTimeString(),
    },
  ]);

  const [outputLogs, setOutputLogs] = useState<string[]>([
    '[system] Workspace initialized successfully.',
    '[vite] Dev server ready at http://localhost:3000',
    '[live-server] Live Preview available on port 5500',
    '[git] Git active on branch ' + gitState.currentBranch,
  ]);

  const [debugEvaluations, setDebugEvaluations] = useState<{ expr: string; result: string }[]>([]);
  const [debugInput, setDebugInput] = useState('');

  const terminalEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isOpen && activeTab === 'terminal') {
      terminalEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [terminalEntries, isOpen, activeTab]);

  const executeRawCommand = async (rawCmd: string) => {
    if (!rawCmd.trim()) return;

    setCommandHistory(prev => [...prev, rawCmd]);
    setHistoryIndex(-1);

    const userEntry: TerminalEntry = {
      id: `cmd-${Date.now()}`,
      type: 'command',
      text: `➜ workspace git:(${gitState.currentBranch}) $ ${rawCmd}`,
      timestamp: new Date().toLocaleTimeString(),
    };

    setTerminalEntries(prev => [...prev, userEntry]);
    setIsExecuting(true);

    const trimmed = rawCmd.trim();
    const parts = trimmed.split(/\s+/);
    const cmd = parts[0].toLowerCase();
    const args = parts.slice(1);

    const addResponse = (text: string, type: TerminalEntry['type'] = 'output') => {
      setTerminalEntries(prev => [
        ...prev,
        {
          id: `res-${Date.now()}-${Math.random()}`,
          type,
          text,
          timestamp: new Date().toLocaleTimeString(),
        },
      ]);
    };

    // Universal Code Runner
    const handleRunTarget = async (filename?: string, forceLang?: string) => {
      const targetFile = filename 
        ? files.find(f => f.path === filename || f.name === filename) 
        : activeFile;

      if (!targetFile) {
        addResponse(
          filename 
            ? `Error: File '${filename}' not found in workspace.` 
            : 'Error: No active file to run. Please open or select a file.',
          'error'
        );
        setIsExecuting(false);
        return;
      }

      try {
        const result = await executeCode(targetFile.name, targetFile.content, forceLang || targetFile.language);
        addResponse(result.formattedOutput, result.exitCode === 0 ? 'success' : 'error');
      } catch (err: unknown) {
        const msg = err instanceof Error ? err.message : String(err);
        addResponse(`Execution Error: ${msg}`, 'error');
      }
      setIsExecuting(false);
    };

    switch (cmd) {
      case 'run':
      case 'start':
      case 'exec':
        await handleRunTarget(args[0]);
        break;

      case 'python':
      case 'python3':
      case 'py':
        await handleRunTarget(args[0], 'python');
        break;

      case 'node':
      case 'js':
      case 'javascript':
        await handleRunTarget(args[0], 'javascript');
        break;

      case 'ts-node':
      case 'ts':
      case 'typescript':
        await handleRunTarget(args[0], 'typescript');
        break;

      case 'gcc':
      case 'c':
      case 'clang':
        await handleRunTarget(args[0] === '-o' ? args[2] : args[0], 'c');
        break;

      case 'g++':
      case 'cpp':
      case 'c++':
        await handleRunTarget(args[0] === '-o' ? args[2] : args[0], 'cpp');
        break;

      case 'javac':
      case 'java':
        await handleRunTarget(args[0], 'java');
        break;

      case 'rustc':
      case 'cargo':
      case 'rust':
        await handleRunTarget(args[0] === 'run' ? args[1] : args[0], 'rust');
        break;

      case 'go':
        await handleRunTarget(args[0] === 'run' ? args[1] : args[0], 'go');
        break;

      case 'php':
        await handleRunTarget(args[0], 'php');
        break;

      case 'ruby':
      case 'rb':
        await handleRunTarget(args[0], 'ruby');
        break;

      case 'bash':
      case 'sh':
        await handleRunTarget(args[0], 'bash');
        break;

      case 'sqlite3':
      case 'sql':
        await handleRunTarget(args[0], 'sql');
        break;

      case 'clear':
      case 'cls':
        setTerminalEntries([]);
        setIsExecuting(false);
        return;

      case 'help':
        addResponse(
          'MR00100 Universal Terminal Commands:\n' +
          '  run [file]              Execute file in any language (auto-detects Python, JS, C, C++, Java, etc.)\n' +
          '  python3 <file>          Run Python 3 script\n' +
          '  node <file>             Execute JavaScript / TypeScript\n' +
          '  gcc <file>              Compile and execute C program\n' +
          '  g++ <file>              Compile and execute C++ program\n' +
          '  javac / java <file>     Compile and run Java code\n' +
          '  rustc / cargo <file>    Compile and run Rust code\n' +
          '  go run <file>           Execute Go code\n' +
          '  bash <file>             Run shell script\n' +
          '  sql <file>              Execute SQL script with SQLite\n' +
          '  ls / dir                List workspace files\n' +
          '  cat <file>              Print file contents\n' +
          '  touch <file>            Create a new file\n' +
          '  rm <file>               Delete a file\n' +
          '  git status              Git source control status\n' +
          '  git commit -m "..."     Commit staged changes\n' +
          '  clear                   Clear terminal screen\n',
          'info'
        );
        setIsExecuting(false);
        break;

      case 'ls':
      case 'dir':
        if (files.length === 0) {
          addResponse('Workspace directory is empty.', 'info');
        } else {
          const fileList = files.map(f => {
            const size = `${(f.content.length / 1024).toFixed(1)} KB`;
            return `  ${f.path.padEnd(24)} [${f.language}]  ${size}`;
          }).join('\n');
          addResponse(`Directory: ~/workspace\n${fileList}`, 'output');
        }
        setIsExecuting(false);
        break;

      case 'cat':
        if (!args[0]) {
          addResponse('Usage: cat <filename>', 'error');
        } else {
          const target = files.find(f => f.path === args[0] || f.name === args[0]);
          if (target) {
            addResponse(target.content, 'output');
          } else {
            addResponse(`cat: ${args[0]}: No such file or directory`, 'error');
          }
        }
        setIsExecuting(false);
        break;

      case 'touch':
        if (!args[0]) {
          addResponse('Usage: touch <filename>', 'error');
        } else {
          onCreateFile(args[0]);
          addResponse(`Created file '${args[0]}'`, 'success');
        }
        setIsExecuting(false);
        break;

      case 'rm':
        if (!args[0]) {
          addResponse('Usage: rm <filename>', 'error');
        } else {
          const target = files.find(f => f.path === args[0] || f.name === args[0]);
          if (target) {
            onDeleteFile(target.id);
            addResponse(`Removed file '${args[0]}'`, 'success');
          } else {
            addResponse(`rm: cannot remove '${args[0]}': No such file`, 'error');
          }
        }
        setIsExecuting(false);
        break;

      case 'git':
        const sub = args[0];
        if (sub === 'status') {
          const staged = gitState.stagedFiles.map(p => `    staged:   ${p}`).join('\n');
          const modified = files.filter(f => f.isModified && !gitState.stagedFiles.includes(f.path)).map(f => `    modified: ${f.path}`).join('\n');
          addResponse(
            `On branch ${gitState.currentBranch}\n` +
            (staged ? `Changes to be committed:\n${staged}\n\n` : 'No changes staged for commit.\n') +
            (modified ? `Changes not staged for commit:\n${modified}\n` : 'Working tree clean.'),
            'output'
          );
        } else if (sub === 'add') {
          if (args[1] === '.' || args[1] === '-A') {
            files.filter(f => f.isModified).forEach(f => onStageFile(f.path));
            addResponse('Staged all workspace changes.', 'success');
          } else if (args[1]) {
            onStageFile(args[1]);
            addResponse(`Staged '${args[1]}'`, 'success');
          } else {
            addResponse('Usage: git add <file> or git add .', 'error');
          }
        } else if (sub === 'commit') {
          const msgIdx = rawCmd.indexOf('-m');
          if (msgIdx !== -1) {
            const rawMsg = rawCmd.substring(msgIdx + 2).trim().replace(/^["']|["']$/g, '');
            if (rawMsg) {
              onCommit(rawMsg);
              addResponse(`[${gitState.currentBranch} ${Math.random().toString(36).substring(2, 9)}] ${rawMsg}`, 'success');
            } else {
              addResponse('error: switch -m requires a commit message', 'error');
            }
          } else {
            addResponse('Usage: git commit -m "Your commit message"', 'error');
          }
        } else if (sub === 'push') {
          onPush();
          addResponse(`Writing objects: 100% (4/4), done.\nTo ${gitState.remoteUrl}\n   main -> main`, 'success');
        } else {
          addResponse(`git: '${sub}' is not recognized. Try: git status, git add, git commit, git push`, 'error');
        }
        setIsExecuting(false);
        break;

      case 'whoami':
        addResponse('developer@mr00100-code-studio', 'info');
        setIsExecuting(false);
        break;

      case 'date':
        addResponse(new Date().toString(), 'info');
        setIsExecuting(false);
        break;

      default:
        // Try running as a file or command
        const found = files.find(f => f.name === cmd || f.path === cmd);
        if (found) {
          await handleRunTarget(found.name);
        } else {
          addResponse(`bash: command not found: ${cmd}. Type "help" to see available commands.`, 'error');
          setIsExecuting(false);
        }
        break;
    }
  };

  const handleCommandSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const cmd = inputVal;
    setInputVal('');
    executeRawCommand(cmd);
  };

  useEffect(() => {
    if (commandToRun) {
      setActiveTab('terminal');
      executeRawCommand(commandToRun);
      if (onClearCommandToRun) onClearCommandToRun();
    }
  }, [commandToRun]);

  const handleRunActiveFileClick = () => {
    if (!activeFile) return;
    executeRawCommand(`run ${activeFile.name}`);
  };

  const handleDebugEval = (e: React.FormEvent) => {
    e.preventDefault();
    if (!debugInput.trim()) return;
    try {
      // eslint-disable-next-line no-eval
      const res = String(eval(debugInput));
      setDebugEvaluations(prev => [...prev, { expr: debugInput, result: res }]);
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : String(err);
      setDebugEvaluations(prev => [...prev, { expr: debugInput, result: `Error: ${msg}` }]);
    }
    setDebugInput('');
  };

  if (!isOpen) return null;

  return (
    <section 
      className={`border-t border-slate-800 bg-slate-950 flex flex-col font-mono text-xs select-none transition-all duration-150 theme-terminal-panel ${
        isExpanded ? 'h-[75vh]' : 'h-64 sm:h-72'
      }`}
      aria-label="Integrated Terminal"
    >
      {/* Terminal Title & Tabs Header */}
      <div className="h-9 px-3 bg-slate-900 border-b border-slate-800 flex items-center justify-between shrink-0">
        {/* Left Tabs */}
        <div className="flex items-center gap-1 font-sans">
          <button
            onClick={() => setActiveTab('terminal')}
            className={`px-3 py-1.5 rounded-t text-xs font-semibold flex items-center gap-2 transition-colors cursor-pointer ${
              activeTab === 'terminal' 
                ? 'bg-slate-950 text-cyan-400 border-t-2 border-t-cyan-400' 
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
            }`}
          >
            <TerminalIcon className="w-3.5 h-3.5" />
            <span>TERMINAL</span>
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
          </button>

          <button
            onClick={() => setActiveTab('output')}
            className={`px-3 py-1.5 rounded-t text-xs font-semibold flex items-center gap-2 transition-colors cursor-pointer ${
              activeTab === 'output' 
                ? 'bg-slate-950 text-cyan-400 border-t-2 border-t-cyan-400' 
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
            }`}
          >
            <span>OUTPUT</span>
          </button>

          <button
            onClick={() => setActiveTab('problems')}
            className={`px-3 py-1.5 rounded-t text-xs font-semibold flex items-center gap-2 transition-colors cursor-pointer ${
              activeTab === 'problems' 
                ? 'bg-slate-950 text-cyan-400 border-t-2 border-t-cyan-400' 
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
            }`}
          >
            <span>PROBLEMS</span>
            {diagnostics.length > 0 && (
              <span className="px-1.5 py-0.2 rounded-full bg-rose-500 text-slate-950 text-[10px] font-bold">
                {diagnostics.length}
              </span>
            )}
          </button>

          <button
            onClick={() => setActiveTab('debug')}
            className={`px-3 py-1.5 rounded-t text-xs font-semibold flex items-center gap-2 transition-colors cursor-pointer ${
              activeTab === 'debug' 
                ? 'bg-slate-950 text-cyan-400 border-t-2 border-t-cyan-400' 
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
            }`}
          >
            <span>DEBUG CONSOLE</span>
          </button>
        </div>

        {/* Right Action Icons */}
        <div className="flex items-center gap-1.5 font-sans">
          {/* Quick Run Active File Button */}
          <button
            onClick={handleRunActiveFileClick}
            className="flex items-center gap-1.5 px-2.5 py-1 bg-emerald-600 hover:bg-emerald-500 text-white rounded text-[11px] font-semibold transition-all cursor-pointer shadow-xs"
            title="Execute current file in terminal"
          >
            <Play className="w-3 h-3 fill-current" />
            <span>Run {activeFile?.name || 'Code'}</span>
          </button>

          {/* Clear screen */}
          <button
            onClick={() => setTerminalEntries([])}
            className="p-1 rounded hover:bg-slate-800 text-slate-400 hover:text-slate-200 transition-colors"
            title="Clear Terminal (clear)"
          >
            <Trash2 className="w-3.5 h-3.5" />
          </button>

          {/* Maximize / Minimize toggle */}
          <button
            onClick={() => setIsExpanded(!isExpanded)}
            className="p-1 rounded hover:bg-slate-800 text-slate-400 hover:text-slate-200 transition-colors"
            title={isExpanded ? 'Restore Size' : 'Maximize Panel'}
          >
            {isExpanded ? <Minimize2 className="w-3.5 h-3.5" /> : <Maximize2 className="w-3.5 h-3.5" />}
          </button>

          {/* Close */}
          <button
            onClick={onClose}
            className="p-1 rounded hover:bg-slate-800 text-slate-400 hover:text-rose-400 transition-colors"
            title="Close Panel (`)"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Quick Helper Chips Bar */}
      {activeTab === 'terminal' && (
        <div className="px-3 py-1 bg-slate-900/60 border-b border-slate-800 flex items-center gap-2 overflow-x-auto text-[11px]">
          <span className="text-slate-500 font-semibold shrink-0">Quick Actions:</span>
          {activeFile && (
            <button
              onClick={() => executeRawCommand(`run ${activeFile.name}`)}
              className="px-2 py-0.5 rounded bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex items-center gap-1 shrink-0 cursor-pointer"
            >
              <Play className="w-2.5 h-2.5 fill-current" />
              <span>run {activeFile.name}</span>
            </button>
          )}
          <button
            onClick={() => executeRawCommand('ls')}
            className="px-2 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 shrink-0 cursor-pointer"
          >
            ls
          </button>
          <button
            onClick={() => executeRawCommand('git status')}
            className="px-2 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-cyan-300 border border-slate-700 shrink-0 cursor-pointer"
          >
            git status
          </button>
          <button
            onClick={() => executeRawCommand('help')}
            className="px-2 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-amber-300 border border-slate-700 shrink-0 cursor-pointer"
          >
            help
          </button>
          <button
            onClick={() => setTerminalEntries([])}
            className="px-2 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-400 border border-slate-700 shrink-0 cursor-pointer"
          >
            clear
          </button>
        </div>
      )}

      {/* Main Tab Views */}
      <div className="flex-1 overflow-y-auto p-3 space-y-1 bg-slate-950 font-mono text-[12px] leading-relaxed">
        {/* Terminal Tab */}
        {activeTab === 'terminal' && (
          <div className="space-y-1">
            {terminalEntries.map(entry => (
              <div key={entry.id} className="whitespace-pre-wrap break-all">
                {entry.type === 'command' ? (
                  <div className="text-cyan-400 font-bold flex items-start gap-1">
                    <span>{entry.text}</span>
                  </div>
                ) : entry.type === 'error' ? (
                  <div className="text-rose-400 bg-rose-950/20 p-1.5 rounded border border-rose-900/40">
                    {entry.text}
                  </div>
                ) : entry.type === 'success' ? (
                  <div className="text-emerald-300">
                    {entry.text}
                  </div>
                ) : entry.type === 'system' ? (
                  <div className="text-cyan-300 font-semibold">
                    {entry.text}
                  </div>
                ) : entry.type === 'info' ? (
                  <div className="text-slate-400">
                    {entry.text}
                  </div>
                ) : (
                  <div className="text-slate-200">
                    {entry.text}
                  </div>
                )}
              </div>
            ))}

            {isExecuting && (
              <div className="text-cyan-400 flex items-center gap-2 italic">
                <span className="w-2 h-2 rounded-full bg-cyan-400 animate-ping" />
                <span>Executing command...</span>
              </div>
            )}

            {/* Input Prompt Form */}
            <form onSubmit={handleCommandSubmit} className="flex items-center gap-2 pt-1 font-mono">
              <span className="text-cyan-400 font-bold shrink-0">
                ➜ <span className="text-indigo-400">workspace</span> <span className="text-slate-400">git:({gitState.currentBranch})</span> <span className="text-emerald-400">$</span>
              </span>
              <input
                ref={inputRef}
                type="text"
                value={inputVal}
                onChange={e => setInputVal(e.target.value)}
                onKeyDown={e => {
                  if (e.key === 'ArrowUp') {
                    if (commandHistory.length > 0) {
                      const next = historyIndex === -1 ? commandHistory.length - 1 : Math.max(0, historyIndex - 1);
                      setHistoryIndex(next);
                      setInputVal(commandHistory[next]);
                    }
                  } else if (e.key === 'ArrowDown') {
                    if (historyIndex !== -1) {
                      const next = historyIndex + 1;
                      if (next >= commandHistory.length) {
                        setHistoryIndex(-1);
                        setInputVal('');
                      } else {
                        setHistoryIndex(next);
                        setInputVal(commandHistory[next]);
                      }
                    }
                  }
                }}
                placeholder="Type command (e.g. run, python3 main.py, node index.js, help)..."
                className="flex-1 bg-transparent text-slate-100 focus:outline-hidden font-mono text-[12px] caret-cyan-400"
              />
            </form>
            <div ref={terminalEndRef} />
          </div>
        )}

        {/* Problems Tab */}
        {activeTab === 'problems' && (
          <div className="space-y-2 font-sans">
            {diagnostics.length === 0 ? (
              <div className="flex flex-col items-center justify-center p-8 text-center text-slate-500">
                <CheckCircle2 className="w-8 h-8 text-emerald-500 mb-2" />
                <p className="font-semibold text-slate-300">No problems detected in workspace</p>
                <p className="text-xs text-slate-500 mt-1">Linter scanner checked all active files.</p>
              </div>
            ) : (
              diagnostics.map(diag => (
                <div
                  key={diag.id}
                  onClick={() => onSelectFileAndLine && onSelectFileAndLine(diag.file, diag.line)}
                  className="p-2 rounded bg-slate-900 border border-slate-800 hover:border-slate-700 flex items-start gap-2.5 cursor-pointer transition-colors"
                >
                  {diag.severity === 'error' ? (
                    <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                  ) : (
                    <Info className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                  )}
                  <div className="flex-1 min-w-0">
                    <div className="text-slate-200 font-medium text-xs">{diag.message}</div>
                    <div className="text-[11px] text-slate-400 font-mono mt-0.5 flex items-center gap-2">
                      <span className="text-cyan-400">{diag.file}:{diag.line}:{diag.col}</span>
                      <span>&bull;</span>
                      <span className="text-slate-500">{diag.rule}</span>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        )}

        {/* Output Logs Tab */}
        {activeTab === 'output' && (
          <div className="space-y-1 font-mono text-slate-300">
            {outputLogs.map((log, i) => (
              <div key={i} className="text-slate-300">
                {log}
              </div>
            ))}
          </div>
        )}

        {/* Debug Console Tab */}
        {activeTab === 'debug' && (
          <div className="space-y-2">
            <div className="text-slate-500 italic text-[11px]">
              Evaluate JavaScript expressions in the active studio runtime:
            </div>
            {debugEvaluations.map((item, i) => (
              <div key={i} className="bg-slate-900 p-2 rounded border border-slate-800 space-y-1">
                <div className="text-cyan-400 font-semibold">&gt; {item.expr}</div>
                <div className="text-slate-200">{item.result}</div>
              </div>
            ))}

            <form onSubmit={handleDebugEval} className="flex items-center gap-2 pt-2">
              <span className="text-emerald-400 font-bold">&gt;</span>
              <input
                type="text"
                value={debugInput}
                onChange={e => setDebugInput(e.target.value)}
                placeholder="Type expression to evaluate (e.g. 2 + 2, Math.PI, files.length)..."
                className="flex-1 bg-transparent text-slate-100 focus:outline-hidden font-mono text-[12px] caret-cyan-400"
              />
            </form>
          </div>
        )}
      </div>
    </section>
  );
};
