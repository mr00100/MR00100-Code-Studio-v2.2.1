import React, { useState } from 'react';
import { 
  GitBranch, 
  AlertTriangle, 
  XCircle, 
  Radio, 
  Terminal, 
  Check, 
  Bell, 
  Layers,
  ChevronDown,
  Search,
  CheckCircle2
} from 'lucide-react';
import { GitState, Diagnostic } from '../../types';
import { SUPPORTED_LANGUAGES } from '../../utils/codeRunner';

interface StatusBarProps {
  gitState: GitState;
  onOpenGit: () => void;
  diagnostics: Diagnostic[];
  onOpenProblems: () => void;
  isLiveServerRunning: boolean;
  onToggleLiveServer: () => void;
  isTerminalOpen: boolean;
  onToggleTerminal: () => void;
  isPrettierEnabled: boolean;
  cursorPos?: { line: number; col: number };
  activeLanguage?: string;
  onSelectLanguage?: (lang: string) => void;
  onOpenSettings: () => void;
}

export const StatusBar: React.FC<StatusBarProps> = ({
  gitState,
  onOpenGit,
  diagnostics,
  onOpenProblems,
  isLiveServerRunning,
  onToggleLiveServer,
  isTerminalOpen,
  onToggleTerminal,
  isPrettierEnabled,
  cursorPos = { line: 1, col: 1 },
  activeLanguage = 'typescript',
  onSelectLanguage,
  onOpenSettings,
}) => {
  const [showLanguagePicker, setShowLanguagePicker] = useState(false);
  const [languageSearch, setLanguageSearch] = useState('');

  const errorCount = diagnostics.filter(d => d.severity === 'error').length;
  const warningCount = diagnostics.filter(d => d.severity === 'warning').length;

  const filteredLanguages = SUPPORTED_LANGUAGES.filter(l => 
    l.name.toLowerCase().includes(languageSearch.toLowerCase()) ||
    l.id.toLowerCase().includes(languageSearch.toLowerCase())
  );

  return (
    <footer className="h-6 bg-slate-900 border-t border-slate-800 text-slate-400 text-[11px] px-2 flex items-center justify-between select-none z-30 shrink-0 font-sans relative theme-statusbar">
      {/* Left side items */}
      <div className="flex items-center gap-2 h-full">
        {/* Remote Host / Studio indicator */}
        <div className="h-full px-2 bg-cyan-600 text-white font-bold flex items-center gap-1 cursor-default text-[10px]">
          <Layers className="w-3 h-3" />
          <span>MR00100</span>
        </div>

        {/* Git Branch */}
        <button
          onClick={onOpenGit}
          className="h-full px-1.5 hover:bg-slate-800 hover:text-slate-100 flex items-center gap-1 transition-colors cursor-pointer"
          title={`Git Branch: ${gitState.currentBranch}`}
        >
          <GitBranch className="w-3 h-3 text-cyan-400" />
          <span className="font-mono text-cyan-300 font-medium">{gitState.currentBranch}</span>
          {gitState.aheadCount > 0 && (
            <span className="text-[10px] text-emerald-400 font-mono font-bold">↑{gitState.aheadCount}</span>
          )}
        </button>

        {/* Diagnostics & Problems Counter */}
        <button
          onClick={onOpenProblems}
          className="h-full px-1.5 hover:bg-slate-800 hover:text-slate-100 flex items-center gap-2 transition-colors cursor-pointer"
          title="Problems & Diagnostics"
        >
          <span className="flex items-center gap-0.5 text-rose-400">
            <XCircle className="w-3 h-3" />
            <span className="font-mono">{errorCount}</span>
          </span>
          <span className="flex items-center gap-0.5 text-amber-400">
            <AlertTriangle className="w-3 h-3" />
            <span className="font-mono">{warningCount}</span>
          </span>
        </button>

        {/* Terminal toggle */}
        <button
          onClick={onToggleTerminal}
          className={`h-full px-1.5 hover:bg-slate-800 flex items-center gap-1 transition-colors cursor-pointer ${
            isTerminalOpen ? 'text-cyan-300 bg-slate-800/80' : 'text-slate-400 hover:text-slate-200'
          }`}
          title="Toggle Terminal Panel (`)"
        >
          <Terminal className="w-3 h-3" />
          <span>Terminal</span>
        </button>
      </div>

      {/* Right side items */}
      <div className="flex items-center gap-1 h-full">
        {/* VS Code Famous Go Live / Live Server Button */}
        <button
          onClick={onToggleLiveServer}
          className={`h-full px-2 flex items-center gap-1.5 font-medium transition-all cursor-pointer ${
            isLiveServerRunning 
              ? 'bg-emerald-600/30 text-emerald-300 hover:bg-emerald-600/40 border-x border-emerald-500/30' 
              : 'hover:bg-slate-800 text-slate-300 hover:text-white'
          }`}
          title={isLiveServerRunning ? 'Live Server running on Port 5500 (Click to Stop)' : 'Click to Go Live with Live Server'}
        >
          <Radio className={`w-3 h-3 ${isLiveServerRunning ? 'text-emerald-400 animate-pulse' : 'text-slate-400'}`} />
          <span>{isLiveServerRunning ? 'Port: 5500 (Live)' : 'Go Live'}</span>
        </button>

        {/* Prettier Formatter status */}
        <button
          onClick={onOpenSettings}
          className="h-full px-2 hover:bg-slate-800 hover:text-slate-200 flex items-center gap-1 transition-colors cursor-pointer"
          title={isPrettierEnabled ? 'Prettier: Active' : 'Prettier: Disabled'}
        >
          <Check className={`w-3 h-3 ${isPrettierEnabled ? 'text-emerald-400' : 'text-slate-500'}`} />
          <span>Prettier</span>
        </button>

        {/* Cursor Position */}
        <div className="h-full px-2 flex items-center font-mono text-slate-400">
          Ln {cursorPos.line}, Col {cursorPos.col}
        </div>

        {/* Indentation */}
        <div className="h-full px-1.5 flex items-center text-slate-400">
          Spaces: 2
        </div>

        {/* Encoding */}
        <div className="h-full px-1.5 flex items-center text-slate-400">
          UTF-8
        </div>

        {/* Interactive Language Selector (Click to change language mode!) */}
        <div className="relative h-full">
          <button
            onClick={() => setShowLanguagePicker(!showLanguagePicker)}
            className="h-full px-2 hover:bg-slate-800 flex items-center gap-1 text-cyan-400 hover:text-cyan-300 font-medium capitalize cursor-pointer transition-colors"
            title="Select Language Mode"
          >
            <span>
              {SUPPORTED_LANGUAGES.find(l => l.id === activeLanguage)?.name || 
               (activeLanguage === 'tsx' ? 'TypeScript JSX' : activeLanguage === 'ts' ? 'TypeScript' : activeLanguage)}
            </span>
            <ChevronDown className="w-2.5 h-2.5 opacity-70" />
          </button>

          {/* Language Selector Dropdown */}
          {showLanguagePicker && (
            <div 
              className="absolute bottom-full right-0 mb-1 w-64 bg-slate-900 border border-slate-700 rounded-lg shadow-2xl overflow-hidden z-50 text-xs"
              onMouseLeave={() => setShowLanguagePicker(false)}
            >
              <div className="p-2 border-b border-slate-800 bg-slate-950">
                <div className="text-[10px] text-slate-400 uppercase font-semibold mb-1">Select Language Mode</div>
                <div className="flex items-center gap-1.5 px-2 py-1 bg-slate-900 border border-slate-800 rounded">
                  <Search className="w-3 h-3 text-slate-500" />
                  <input
                    type="text"
                    value={languageSearch}
                    onChange={e => setLanguageSearch(e.target.value)}
                    placeholder="Search languages..."
                    autoFocus
                    className="flex-1 bg-transparent text-slate-100 text-xs focus:outline-hidden"
                  />
                </div>
              </div>

              <div className="max-h-56 overflow-y-auto p-1 space-y-0.5">
                {filteredLanguages.map(lang => (
                  <button
                    key={lang.id}
                    onClick={() => {
                      if (onSelectLanguage) onSelectLanguage(lang.id);
                      setShowLanguagePicker(false);
                      setLanguageSearch('');
                    }}
                    className={`w-full text-left px-2.5 py-1.5 rounded flex items-center justify-between text-xs cursor-pointer transition-colors ${
                      activeLanguage === lang.id ? 'bg-cyan-500/20 text-cyan-300 font-semibold' : 'text-slate-300 hover:bg-slate-800'
                    }`}
                  >
                    <span className="flex items-center gap-2">
                      <span>{lang.icon}</span>
                      <span>{lang.name}</span>
                    </span>
                    <span className="text-[10px] text-slate-500 font-mono">{lang.ext}</span>
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Notifications */}
        <div className="h-full px-1.5 hover:bg-slate-800 text-slate-400 hover:text-slate-200 flex items-center cursor-pointer">
          <Bell className="w-3 h-3" />
        </div>
      </div>
    </footer>
  );
};
