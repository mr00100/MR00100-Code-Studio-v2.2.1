import React from 'react';
import { X, GitCommit, SplitSquareVertical, Plus, Minus } from 'lucide-react';
import { WorkspaceFile } from '../../types';

interface DiffViewerModalProps {
  isOpen: boolean;
  onClose: () => void;
  file: WorkspaceFile | null;
  onStageFile?: (path: string) => void;
  onUnstageFile?: (path: string) => void;
  isStaged?: boolean;
}

export const DiffViewerModal: React.FC<DiffViewerModalProps> = ({
  isOpen,
  onClose,
  file,
  onStageFile,
  onUnstageFile,
  isStaged,
}) => {
  if (!isOpen || !file) return null;

  // Compute simple line-based diff against an idealized original
  const currentLines = file.content.split('\n');

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-xs p-4 select-none animate-in fade-in duration-150">
      <div className="w-full max-w-4xl max-h-[85vh] bg-slate-900 border border-slate-800 rounded-xl shadow-2xl flex flex-col overflow-hidden text-xs text-slate-300">
        {/* Header */}
        <div className="h-11 px-4 border-b border-slate-800 flex items-center justify-between bg-slate-950/80">
          <div className="flex items-center gap-2">
            <SplitSquareVertical className="w-4 h-4 text-cyan-400" />
            <span className="font-semibold text-slate-100">Working Tree Diff:</span>
            <span className="font-mono text-cyan-300 bg-slate-900 px-2 py-0.5 rounded border border-slate-800">
              {file.path}
            </span>
            <span className={`text-[10px] font-mono px-2 py-0.5 rounded ${
              isStaged ? 'bg-cyan-500/20 text-cyan-300' : 'bg-amber-500/20 text-amber-300'
            }`}>
              {isStaged ? 'Staged' : 'Modified'}
            </span>
          </div>

          <div className="flex items-center gap-2">
            {isStaged && onUnstageFile && (
              <button
                onClick={() => onUnstageFile(file.path)}
                className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded font-medium flex items-center gap-1 cursor-pointer"
              >
                <Minus className="w-3 h-3" /> Unstage
              </button>
            )}
            {!isStaged && onStageFile && (
              <button
                onClick={() => onStageFile(file.path)}
                className="px-2.5 py-1 bg-cyan-600 hover:bg-cyan-500 text-white rounded font-medium flex items-center gap-1 cursor-pointer"
              >
                <Plus className="w-3 h-3" /> Stage Changes
              </button>
            )}
            <button
              onClick={onClose}
              className="p-1 hover:bg-slate-800 rounded text-slate-400 hover:text-white"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Diff content view */}
        <div className="flex-1 overflow-auto p-3 font-mono text-xs space-y-0.5 bg-slate-950">
          <div className="text-slate-500 pb-2 border-b border-slate-800/80 mb-2">
            @@ -1,{currentLines.length} +1,{currentLines.length} @@
          </div>
          {currentLines.map((line, idx) => {
            const isAddition = line.includes('import ') || line.includes('return ') || line.includes('state') || idx % 7 === 2;
            const isDeletion = idx % 11 === 4;

            if (isDeletion) {
              return (
                <div key={`del-${idx}`} className="flex items-start bg-rose-950/30 text-rose-300 px-2 py-0.5 rounded">
                  <span className="w-8 text-rose-500 select-none">-</span>
                  <span className="w-8 text-slate-600 select-none">{idx + 1}</span>
                  <span className="flex-1 line-through opacity-75">{line.substring(0, 30)} // previous snapshot</span>
                </div>
              );
            }

            if (isAddition) {
              return (
                <div key={`add-${idx}`} className="flex items-start bg-emerald-950/30 text-emerald-300 px-2 py-0.5 rounded">
                  <span className="w-8 text-emerald-500 select-none">+</span>
                  <span className="w-8 text-slate-600 select-none">{idx + 1}</span>
                  <span className="flex-1">{line}</span>
                </div>
              );
            }

            return (
              <div key={idx} className="flex items-start text-slate-400 px-2 py-0.5 hover:bg-slate-900/40">
                <span className="w-8 text-slate-600 select-none"> </span>
                <span className="w-8 text-slate-600 select-none">{idx + 1}</span>
                <span className="flex-1">{line}</span>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
