import React, { useRef } from 'react';
import { X, Cloud, Download, Upload, RotateCcw, CheckCircle2, FileArchive } from 'lucide-react';
import { WorkspaceFile } from '../../types';

interface CloudSyncModalProps {
  isOpen: boolean;
  onClose: () => void;
  files: WorkspaceFile[];
  onImportFiles: (importedFiles: WorkspaceFile[]) => void;
  onResetWorkspace: () => void;
  onDownloadZip: () => void;
  lastSyncedText: string;
  projectName: string;
}

export const CloudSyncModal: React.FC<CloudSyncModalProps> = ({
  isOpen,
  onClose,
  files,
  onImportFiles,
  onResetWorkspace,
  onDownloadZip,
  lastSyncedText,
  projectName,
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);

  if (!isOpen) return null;

  const totalBytes = files.reduce((acc, f) => acc + f.content.length, 0);
  const formattedSize = (totalBytes / 1024).toFixed(1);

  const handleExportJSON = () => {
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(files, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `${projectName.toLowerCase().replace(/\s+/g, '-')}-backup.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = event => {
      try {
        const parsed = JSON.parse(event.target?.result as string);
        if (Array.isArray(parsed)) {
          onImportFiles(parsed);
          onClose();
        } else {
          alert('Invalid workspace format. Expected array of file objects.');
        }
      } catch (err) {
        alert('Failed to parse JSON file.');
      }
    };
    reader.readAsText(file);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-xs p-4 select-none animate-in fade-in duration-150">
      <div className="w-full max-w-lg bg-slate-900 border border-slate-700 rounded-xl shadow-2xl overflow-hidden text-xs text-slate-300">
        <div className="h-11 px-4 border-b border-slate-800 flex items-center justify-between bg-slate-950/80">
          <div className="flex items-center gap-2">
            <Cloud className="w-4 h-4 text-cyan-400" />
            <span className="font-semibold text-slate-100">Workspace Cloud & Download Center</span>
          </div>
          <button onClick={onClose} className="p-1 hover:bg-slate-800 rounded text-slate-400 hover:text-white cursor-pointer">
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="p-5 space-y-4">
          {/* Status Card */}
          <div className="p-3 bg-slate-950/70 border border-slate-800 rounded-xl flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
                <CheckCircle2 className="w-5 h-5" />
              </div>
              <div>
                <div className="font-semibold text-slate-200">Local & Cloud Storage: Active</div>
                <div className="text-[11px] text-slate-400 mt-0.5">{lastSyncedText}</div>
              </div>
            </div>
            <div className="text-right font-mono text-[11px] text-slate-400">
              <div>{files.length} Files</div>
              <div className="text-cyan-400">{formattedSize} KB</div>
            </div>
          </div>

          {/* Download Project ZIP Card */}
          <div className="p-3.5 bg-gradient-to-r from-emerald-950/40 to-slate-950 border border-emerald-500/40 rounded-xl flex items-center justify-between">
            <div>
              <div className="font-semibold text-emerald-300 text-xs flex items-center gap-1.5">
                <FileArchive className="w-4 h-4 text-emerald-400" />
                <span>Download Entire Project (ZIP)</span>
              </div>
              <div className="text-[11px] text-slate-400 mt-0.5">
                Export all workspace files and directory structure as a standard .zip archive
              </div>
            </div>
            <button
              onClick={() => {
                onDownloadZip();
                onClose();
              }}
              className="px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-medium rounded-lg text-xs flex items-center gap-1.5 transition-all shadow-sm shadow-emerald-500/20 cursor-pointer shrink-0"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download ZIP</span>
            </button>
          </div>

          {/* Export JSON Backup */}
          <div className="p-3 bg-slate-950/40 border border-slate-800 rounded-lg flex items-center justify-between">
            <div>
              <div className="font-medium text-slate-200">Export Raw JSON Snapshot</div>
              <div className="text-[11px] text-slate-500">Save workspace array schema as JSON</div>
            </div>
            <button
              onClick={handleExportJSON}
              className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded text-xs font-medium flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <Download className="w-3.5 h-3.5 text-cyan-400" />
              <span>Export JSON</span>
            </button>
          </div>

          {/* Import */}
          <div className="p-3 bg-slate-950/40 border border-slate-800 rounded-lg flex items-center justify-between">
            <div>
              <div className="font-medium text-slate-200">Import Workspace File</div>
              <div className="text-[11px] text-slate-500">Restore files from a JSON backup</div>
            </div>
            <input
              ref={fileInputRef}
              type="file"
              accept=".json"
              onChange={handleFileSelect}
              className="hidden"
            />
            <button
              onClick={() => fileInputRef.current?.click()}
              className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded text-xs font-medium flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <Upload className="w-3.5 h-3.5 text-cyan-400" />
              <span>Import File</span>
            </button>
          </div>

          {/* Reset Workspace */}
          <div className="pt-2 border-t border-slate-800 flex items-center justify-between">
            <div className="text-[11px] text-slate-500">
              Reset workspace to original template state
            </div>
            <button
              onClick={() => {
                if (confirm('Are you sure you want to reset the workspace? Any unsaved edits will be replaced.')) {
                  onResetWorkspace();
                  onClose();
                }
              }}
              className="px-3 py-1.5 bg-rose-950/40 hover:bg-rose-900/60 text-rose-300 border border-rose-800/60 rounded text-xs font-medium flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Reset Template</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
