import React, { useState, useEffect } from 'react';
import { Search, FileCode, FileJson, Hash, FileText } from 'lucide-react';
import { WorkspaceFile } from '../../types';

interface QuickOpenModalProps {
  isOpen: boolean;
  onClose: () => void;
  files: WorkspaceFile[];
  onSelectFile: (fileId: string) => void;
}

export const QuickOpenModal: React.FC<QuickOpenModalProps> = ({
  isOpen,
  onClose,
  files,
  onSelectFile,
}) => {
  const [search, setSearch] = useState('');
  const [selectedIndex, setSelectedIndex] = useState(0);

  useEffect(() => {
    if (isOpen) {
      setSearch('');
      setSelectedIndex(0);
    }
  }, [isOpen]);

  const filtered = files.filter(f =>
    f.path.toLowerCase().includes(search.toLowerCase())
  );

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'ArrowDown') {
      e.preventDefault();
      setSelectedIndex(prev => Math.min(filtered.length - 1, prev + 1));
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      setSelectedIndex(prev => Math.max(0, prev - 1));
    } else if (e.key === 'Enter') {
      e.preventDefault();
      if (filtered[selectedIndex]) {
        onSelectFile(filtered[selectedIndex].id);
        onClose();
      }
    } else if (e.key === 'Escape') {
      onClose();
    }
  };

  if (!isOpen) return null;

  const getFileIcon = (name: string) => {
    if (name.endsWith('.tsx') || name.endsWith('.jsx')) return <FileCode className="w-4 h-4 text-cyan-400" />;
    if (name.endsWith('.json')) return <FileJson className="w-4 h-4 text-amber-400" />;
    if (name.endsWith('.css')) return <Hash className="w-4 h-4 text-sky-400" />;
    return <FileText className="w-4 h-4 text-emerald-400" />;
  };

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center pt-24 bg-black/60 backdrop-blur-xs select-none">
      <div className="w-full max-w-lg bg-slate-900 border border-slate-700/80 rounded-xl shadow-2xl overflow-hidden text-xs text-slate-200">
        <div className="flex items-center px-4 py-2.5 border-b border-slate-800 gap-2.5">
          <Search className="w-4 h-4 text-cyan-400 shrink-0" />
          <input
            type="text"
            value={search}
            onChange={e => {
              setSearch(e.target.value);
              setSelectedIndex(0);
            }}
            onKeyDown={handleKeyDown}
            placeholder="Search files by name or path..."
            autoFocus
            className="flex-1 bg-transparent text-sm text-white focus:outline-none placeholder-slate-500 font-sans"
          />
          <kbd className="px-1.5 py-0.5 text-[10px] bg-slate-950 border border-slate-800 rounded text-slate-400 font-mono">
            ESC
          </kbd>
        </div>

        <div className="max-h-80 overflow-y-auto p-1.5 space-y-0.5">
          {filtered.length === 0 ? (
            <div className="p-4 text-center text-slate-500 italic">
              No matching files.
            </div>
          ) : (
            filtered.map((file, idx) => {
              const isSelected = idx === selectedIndex;
              return (
                <div
                  key={file.id}
                  onClick={() => {
                    onSelectFile(file.id);
                    onClose();
                  }}
                  onMouseEnter={() => setSelectedIndex(idx)}
                  className={`flex items-center justify-between px-3 py-2 rounded-lg cursor-pointer transition-colors ${
                    isSelected ? 'bg-cyan-500/20 text-cyan-300' : 'hover:bg-slate-800/60 text-slate-300'
                  }`}
                >
                  <div className="flex items-center gap-2.5 min-w-0">
                    {getFileIcon(file.name)}
                    <span className="font-medium truncate">{file.name}</span>
                    <span className="text-[11px] text-slate-500 truncate">{file.path}</span>
                  </div>
                  <span className="text-[10px] text-slate-500 uppercase font-mono">{file.language}</span>
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
};
