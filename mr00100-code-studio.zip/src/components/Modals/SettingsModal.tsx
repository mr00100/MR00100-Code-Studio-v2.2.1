import React from 'react';
import { X, Settings, Sliders, Type, AlignLeft, ShieldCheck, Eye, Palette } from 'lucide-react';
import { EditorSettings } from '../../types';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: EditorSettings;
  onUpdateSettings: (newSettings: Partial<EditorSettings>) => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  settings,
  onUpdateSettings,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-xs p-4 select-none animate-in fade-in duration-150">
      <div className="w-full max-w-xl bg-slate-900 border border-slate-700 rounded-xl shadow-2xl overflow-hidden text-xs text-slate-300">
        <div className="h-11 px-4 border-b border-slate-800 flex items-center justify-between bg-slate-950/90">
          <div className="flex items-center gap-2">
            <Settings className="w-4 h-4 text-cyan-400" />
            <span className="font-semibold text-slate-100 text-sm">MR00100 Studio Preferences</span>
          </div>
          <button 
            onClick={onClose} 
            className="p-1 hover:bg-slate-800 rounded text-slate-400 hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="p-5 space-y-5 max-h-[75vh] overflow-y-auto">
          {/* Theme Selector */}
          <div className="space-y-2">
            <div className="flex items-center gap-2 font-semibold text-slate-200 uppercase tracking-wider text-[11px]">
              <Palette className="w-3.5 h-3.5 text-cyan-400" />
              <span>Editor Visual Theme</span>
            </div>
            <div className="grid grid-cols-2 gap-2.5">
              {[
                { id: 'vs-dark', name: 'VS Code Modern Dark', desc: 'Default studio slate & cyan aesthetic' },
                { id: 'tokyo-night', name: 'Tokyo Night Pro', desc: 'Downtown Tokyo neon purple & blue' },
                { id: 'monokai', name: 'Monokai Pro', desc: 'High contrast amber, pink & mint' },
                { id: 'one-dark', name: 'One Dark Pro', desc: 'Obsidian charcoal with subtle warmth' },
              ].map(theme => (
                <button
                  key={theme.id}
                  onClick={() => onUpdateSettings({ theme: theme.id as EditorSettings['theme'] })}
                  className={`p-3 rounded-lg border text-left transition-all cursor-pointer ${
                    settings.theme === theme.id
                      ? 'bg-cyan-500/15 border-cyan-500 text-cyan-200 shadow-sm'
                      : 'bg-slate-950/60 border-slate-800 hover:border-slate-700 text-slate-300'
                  }`}
                >
                  <div className="font-semibold text-xs flex items-center justify-between">
                    <span>{theme.name}</span>
                    {settings.theme === theme.id && (
                      <span className="w-2 h-2 rounded-full bg-cyan-400" />
                    )}
                  </div>
                  <div className="text-[10px] text-slate-400 mt-1">{theme.desc}</div>
                </button>
              ))}
            </div>
          </div>

          {/* Typography & Sizing */}
          <div className="grid grid-cols-2 gap-4 pt-3 border-t border-slate-800">
            <div className="space-y-1.5">
              <label className="text-slate-300 font-medium">Font Size: <span className="font-mono text-cyan-400">{settings.fontSize}px</span></label>
              <input
                type="range"
                min={11}
                max={22}
                value={settings.fontSize}
                onChange={e => onUpdateSettings({ fontSize: Number(e.target.value) })}
                className="w-full accent-cyan-400 cursor-pointer"
              />
            </div>

            <div className="space-y-1.5">
              <label className="text-slate-300 font-medium">Tab Indent Size</label>
              <select
                value={settings.tabSize}
                onChange={e => onUpdateSettings({ tabSize: Number(e.target.value) })}
                className="w-full bg-slate-950 border border-slate-800 rounded px-2.5 py-1 text-slate-200 font-mono cursor-pointer"
              >
                <option value={2}>2 Spaces (Recommended)</option>
                <option value={4}>4 Spaces</option>
              </select>
            </div>
          </div>

          {/* Editor Toggles */}
          <div className="space-y-2 pt-3 border-t border-slate-800">
            <div className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
              Workspace Behaviors
            </div>

            <label className="flex items-center justify-between p-2.5 rounded-lg bg-slate-950/40 border border-slate-800/80 hover:bg-slate-800/40 cursor-pointer">
              <div>
                <div className="font-medium text-slate-200">Word Wrap</div>
                <div className="text-[11px] text-slate-500">Wrap long lines to prevent horizontal scrolling</div>
              </div>
              <input
                type="checkbox"
                checked={settings.wordWrap}
                onChange={e => onUpdateSettings({ wordWrap: e.target.checked })}
                className="rounded border-slate-700 text-cyan-500 focus:ring-0 w-4 h-4 bg-slate-950"
              />
            </label>

            <label className="flex items-center justify-between p-2.5 rounded-lg bg-slate-950/40 border border-slate-800/80 hover:bg-slate-800/40 cursor-pointer">
              <div>
                <div className="font-medium text-slate-200">Auto Save to Local Storage</div>
                <div className="text-[11px] text-slate-500">Automatically save workspace files to browser storage</div>
              </div>
              <input
                type="checkbox"
                checked={settings.autoSave}
                onChange={e => onUpdateSettings({ autoSave: e.target.checked })}
                className="rounded border-slate-700 text-cyan-500 focus:ring-0 w-4 h-4 bg-slate-950"
              />
            </label>
          </div>
        </div>

        <div className="h-11 px-4 border-t border-slate-800 bg-slate-950 flex items-center justify-end">
          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-cyan-600 hover:bg-cyan-500 text-white rounded-lg font-medium text-xs transition-colors cursor-pointer"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
