import React, { useState, useRef } from 'react';
import { 
  X, 
  Wand2, 
  Edit3, 
  ShieldAlert, 
  Code, 
  Search, 
  Copy, 
  Check, 
  ZoomIn, 
  ZoomOut, 
  AlignLeft, 
  FileCode, 
  FileJson, 
  Hash, 
  FileText, 
  GitCommit, 
  GripVertical,
  Play,
  Radio,
  Terminal,
  ChevronDown
} from 'lucide-react';
import { WorkspaceFile, EditorTab, Diagnostic, Breakpoint, EditorSettings, ExtensionModule } from '../../types';
import { highlightCode } from '../../utils/syntaxHighlighter';
import { renameSymbolInContent, wrapWithTagHelper } from '../../utils/refactoring';

interface CodeEditorProps {
  openTabs: EditorTab[];
  activeFileId: string | null;
  files: WorkspaceFile[];
  onSelectTab: (fileId: string) => void;
  onCloseTab: (fileId: string) => void;
  onReorderTabs: (newTabs: EditorTab[]) => void;
  onContentChange: (fileId: string, newContent: string) => void;
  onFormatDocument: () => void;
  onSaveFile: (fileId: string) => void;
  onRunCode?: (mode: 'live-server' | 'terminal') => void;
  diagnostics: Diagnostic[];
  breakpoints: Breakpoint[];
  onToggleBreakpoint: (file: string, line: number) => void;
  settings: EditorSettings;
  onUpdateSettings: (newSettings: Partial<EditorSettings>) => void;
  onJumpToDiagnostic?: (line: number) => void;
  extensions: ExtensionModule[];
  onSelectLanguage?: (lang: string) => void;
}

export const CodeEditor: React.FC<CodeEditorProps> = ({
  openTabs,
  activeFileId,
  files,
  onSelectTab,
  onCloseTab,
  onReorderTabs,
  onContentChange,
  onFormatDocument,
  onSaveFile,
  onRunCode,
  diagnostics,
  breakpoints,
  onToggleBreakpoint,
  settings,
  onUpdateSettings,
  extensions,
  onSelectLanguage,
}) => {
  const activeFile = files.find(f => f.id === activeFileId);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const preRef = useRef<HTMLPreElement>(null);
  const [cursorPos, setCursorPos] = useState({ line: 1, col: 1 });
  const [showSearch, setShowSearch] = useState(false);
  const [searchText, setSearchText] = useState('');
  const [replaceText, setReplaceText] = useState('');
  const [copied, setCopied] = useState(false);
  const [isRenamingSymbol, setIsRenamingSymbol] = useState(false);
  const [oldSymbol, setOldSymbol] = useState('');
  const [newSymbol, setNewSymbol] = useState('');

  // Drag and Drop Tab state
  const [draggedTabIndex, setDraggedTabIndex] = useState<number | null>(null);
  const [dragOverTabIndex, setDragOverTabIndex] = useState<number | null>(null);
  const [showRunDropdown, setShowRunDropdown] = useState(false);

  // Check if GitLens extension is enabled
  const isGitLensEnabled = extensions.find(e => e.id === 'ext-gitlens')?.enabled ?? false;
  // Check if ESLint extension is enabled
  const isEslintEnabled = extensions.find(e => e.id === 'ext-eslint')?.enabled ?? true;
  // Check if Prettier is enabled
  const isPrettierEnabled = extensions.find(e => e.id === 'ext-prettier')?.enabled ?? true;

  // Keep highlighted pre scroll in sync with textarea scroll
  const handleScroll = () => {
    if (textareaRef.current && preRef.current) {
      preRef.current.scrollTop = textareaRef.current.scrollTop;
      preRef.current.scrollLeft = textareaRef.current.scrollLeft;
    }
  };

  const updateCursorPosition = () => {
    if (!textareaRef.current || !activeFile) return;
    const pos = textareaRef.current.selectionStart;
    const textBefore = activeFile.content.substring(0, pos);
    const lines = textBefore.split('\n');
    setCursorPos({
      line: lines.length,
      col: lines[lines.length - 1].length + 1,
    });
  };

  // Drag and Drop handlers for tabs
  const handleDragStart = (e: React.DragEvent, index: number) => {
    setDraggedTabIndex(index);
    e.dataTransfer.effectAllowed = 'move';
    e.dataTransfer.setData('text/plain', index.toString());
  };

  const handleDragOver = (e: React.DragEvent, index: number) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
    if (dragOverTabIndex !== index) {
      setDragOverTabIndex(index);
    }
  };

  const handleDrop = (e: React.DragEvent, targetIndex: number) => {
    e.preventDefault();
    if (draggedTabIndex === null || draggedTabIndex === targetIndex) {
      setDraggedTabIndex(null);
      setDragOverTabIndex(null);
      return;
    }

    const reordered = [...openTabs];
    const [movedItem] = reordered.splice(draggedTabIndex, 1);
    reordered.splice(targetIndex, 0, movedItem);

    onReorderTabs(reordered);
    setDraggedTabIndex(null);
    setDragOverTabIndex(null);
  };

  const handleDragEnd = () => {
    setDraggedTabIndex(null);
    setDragOverTabIndex(null);
  };

  // Keyboard navigation & shortcuts
  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if ((e.ctrlKey || e.metaKey) && e.key === 's') {
      e.preventDefault();
      if (activeFileId) onSaveFile(activeFileId);
      return;
    }

    if ((e.ctrlKey || e.metaKey) && e.key === 'f') {
      e.preventDefault();
      setShowSearch(prev => !prev);
      return;
    }

    if (e.key === 'Tab') {
      e.preventDefault();
      if (!textareaRef.current || !activeFile) return;
      const start = textareaRef.current.selectionStart;
      const end = textareaRef.current.selectionEnd;
      const spaces = '  ';
      const updated = activeFile.content.substring(0, start) + spaces + activeFile.content.substring(end);
      onContentChange(activeFile.id, updated);

      setTimeout(() => {
        if (textareaRef.current) {
          textareaRef.current.selectionStart = textareaRef.current.selectionEnd = start + spaces.length;
        }
      }, 0);
    }
  };

  const handleCopyContent = () => {
    if (!activeFile) return;
    navigator.clipboard.writeText(activeFile.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handlePerformRename = (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeFile || !oldSymbol.trim() || !newSymbol.trim()) return;
    const { updatedContent } = renameSymbolInContent(activeFile.content, oldSymbol.trim(), newSymbol.trim());
    onContentChange(activeFile.id, updatedContent);
    setIsRenamingSymbol(false);
    setOldSymbol('');
    setNewSymbol('');
  };

  const handleWrapWithDiv = () => {
    if (!textareaRef.current || !activeFile) return;
    const start = textareaRef.current.selectionStart;
    const end = textareaRef.current.selectionEnd;
    const selected = activeFile.content.substring(start, end) || '/* content */';
    const tag = prompt('Tag name to wrap with (e.g. div, section, main):', 'div');
    if (!tag) return;
    const wrapped = wrapWithTagHelper(selected, tag);
    const updated = activeFile.content.substring(0, start) + wrapped + activeFile.content.substring(end);
    onContentChange(activeFile.id, updated);
  };

  const handleTriggerFormat = () => {
    if (!isPrettierEnabled) {
      alert('Prettier extension is disabled. Please enable it in the Extensions Marketplace to format code.');
      return;
    }
    onFormatDocument();
  };

  if (!activeFile) {
    return (
      <div className="flex-1 h-full flex flex-col items-center justify-center bg-slate-950 text-slate-400 select-none p-6">
        <div className="max-w-md w-full text-center space-y-5">
          <div className="w-16 h-16 mx-auto rounded-2xl bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400 shadow-xl">
            <Code className="w-8 h-8" />
          </div>
          <div>
            <h3 className="font-bold text-slate-100 text-lg">MR00100 Code Studio</h3>
            <p className="text-xs text-slate-400 mt-1">High-performance web IDE with live server & terminal execution</p>
          </div>

          {/* Quick Action Buttons */}
          <div className="flex flex-wrap items-center justify-center gap-2 pt-2">
            {onRunCode && (
              <button
                onClick={() => onRunCode('live-server')}
                className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-semibold flex items-center gap-2 shadow-md cursor-pointer transition-colors"
              >
                <Play className="w-3.5 h-3.5 fill-current" />
                <span>Run with Live Server</span>
              </button>
            )}
            {onRunCode && (
              <button
                onClick={() => onRunCode('terminal')}
                className="px-3.5 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg text-xs font-semibold flex items-center gap-2 border border-slate-700 cursor-pointer transition-colors"
              >
                <Terminal className="w-3.5 h-3.5 text-cyan-400" />
                <span>Open Terminal</span>
              </button>
            )}
          </div>

          <div className="pt-4 border-t border-slate-800/80 grid grid-cols-2 gap-2 text-left text-xs font-mono text-slate-400">
            <div className="flex items-center justify-between p-2 rounded bg-slate-900/60 border border-slate-800">
              <span className="text-slate-400">Quick Open</span>
              <kbd className="px-1.5 py-0.5 bg-slate-950 border border-slate-800 rounded text-[10px] text-cyan-400">Ctrl+P</kbd>
            </div>
            <div className="flex items-center justify-between p-2 rounded bg-slate-900/60 border border-slate-800">
              <span className="text-slate-400">Command Palette</span>
              <kbd className="px-1.5 py-0.5 bg-slate-950 border border-slate-800 rounded text-[10px] text-cyan-400">Ctrl+Shift+P</kbd>
            </div>
            <div className="flex items-center justify-between p-2 rounded bg-slate-900/60 border border-slate-800">
              <span className="text-slate-400">Terminal</span>
              <kbd className="px-1.5 py-0.5 bg-slate-950 border border-slate-800 rounded text-[10px] text-cyan-400">Ctrl+`</kbd>
            </div>
            <div className="flex items-center justify-between p-2 rounded bg-slate-900/60 border border-slate-800">
              <span className="text-slate-400">Format Code</span>
              <kbd className="px-1.5 py-0.5 bg-slate-950 border border-slate-800 rounded text-[10px] text-cyan-400">Shift+Alt+F</kbd>
            </div>
          </div>
        </div>
      </div>
    );
  }

  const lines = activeFile.content.split('\n');
  const fileDiagnostics = isEslintEnabled ? diagnostics.filter(d => d.file === activeFile.path) : [];
  const highlightedHtml = highlightCode(activeFile.content, activeFile.language);

  const getTabIcon = (name: string) => {
    if (name.endsWith('.tsx') || name.endsWith('.jsx')) return <FileCode className="w-3.5 h-3.5 text-cyan-400" />;
    if (name.endsWith('.json')) return <FileJson className="w-3.5 h-3.5 text-amber-400" />;
    if (name.endsWith('.css')) return <Hash className="w-3.5 h-3.5 text-sky-400" />;
    return <FileText className="w-3.5 h-3.5 text-emerald-400" />;
  };

  return (
    <div className="flex-1 h-full flex flex-col bg-slate-950 text-slate-200 min-w-0 overflow-hidden relative font-sans">
      {/* Editor Tabs Bar with Drag-and-Drop Reordering */}
      <div className="h-9 bg-slate-950 border-b border-slate-800/80 flex items-center justify-between overflow-x-auto no-scrollbar shrink-0 select-none">
        <div className="flex items-center h-full">
          {openTabs.map((tab, idx) => {
            const isActive = tab.fileId === activeFileId;
            const isDragging = draggedTabIndex === idx;
            const isDragOver = dragOverTabIndex === idx;

            return (
              <div
                key={tab.fileId}
                draggable
                onDragStart={e => handleDragStart(e, idx)}
                onDragOver={e => handleDragOver(e, idx)}
                onDrop={e => handleDrop(e, idx)}
                onDragEnd={handleDragEnd}
                onClick={() => onSelectTab(tab.fileId)}
                className={`h-full px-3 flex items-center gap-2 border-r border-slate-800/80 cursor-grab active:cursor-grabbing text-xs transition-all shrink-0 group ${
                  isActive
                    ? 'bg-slate-900 text-cyan-300 border-t-2 border-t-cyan-400 font-medium'
                    : 'bg-slate-950 hover:bg-slate-900/60 text-slate-400'
                } ${isDragging ? 'opacity-40 scale-95' : ''} ${
                  isDragOver ? 'border-l-2 border-l-cyan-400 bg-cyan-950/20' : ''
                }`}
                title="Click to switch, or drag to reorder tab"
              >
                <GripVertical className="w-3 h-3 text-slate-600 opacity-0 group-hover:opacity-100 transition-opacity -ml-1 cursor-grab" />
                {getTabIcon(tab.fileName)}
                <span className="truncate max-w-[120px]">{tab.fileName}</span>
                {tab.isDirty && (
                  <span className="w-2 h-2 rounded-full bg-cyan-400 shrink-0" title="Unsaved changes" />
                )}
                <button
                  onClick={e => {
                    e.stopPropagation();
                    onCloseTab(tab.fileId);
                  }}
                  className="p-0.5 rounded hover:bg-slate-800 text-slate-500 hover:text-slate-200 transition-colors"
                  title="Close Tab"
                >
                  <X className="w-3 h-3" />
                </button>
              </div>
            );
          })}
        </div>

        {/* Action icons right of tab bar */}
        <div className="flex items-center gap-1.5 px-2 shrink-0">
          {/* Prominent VS Code Run Button */}
          {onRunCode && (
            <div className="relative flex items-center mr-1">
              <button
                onClick={() => onRunCode('live-server')}
                className="flex items-center gap-1.5 px-2.5 py-1 bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs rounded-l transition-all shadow-sm shadow-emerald-600/30 cursor-pointer"
                title="Run Code in Live Server (Port 5500)"
              >
                <Play className="w-3.5 h-3.5 fill-current" />
                <span>Run</span>
              </button>
              <button
                onClick={() => setShowRunDropdown(!showRunDropdown)}
                className="px-1.5 py-1 bg-emerald-700 hover:bg-emerald-600 text-white rounded-r border-l border-emerald-800 transition-colors cursor-pointer"
                title="Execution options"
              >
                <ChevronDown className="w-3 h-3" />
              </button>

              {showRunDropdown && (
                <div 
                  className="absolute top-full right-0 mt-1 w-56 bg-slate-900 border border-slate-700 rounded-lg shadow-2xl p-1 z-50 text-xs"
                  onMouseLeave={() => setShowRunDropdown(false)}
                >
                  <button
                    onClick={() => {
                      onRunCode('live-server');
                      setShowRunDropdown(false);
                    }}
                    className="w-full text-left px-2.5 py-2 rounded hover:bg-slate-800 text-slate-100 flex items-start gap-2 cursor-pointer transition-colors"
                  >
                    <Radio className="w-3.5 h-3.5 text-emerald-400 mt-0.5 shrink-0" />
                    <div>
                      <div className="font-semibold text-emerald-300 text-xs">Run with Live Server</div>
                      <div className="text-[10px] text-slate-400">Port 5500 hot-reloading preview</div>
                    </div>
                  </button>

                  <button
                    onClick={() => {
                      onRunCode('terminal');
                      setShowRunDropdown(false);
                    }}
                    className="w-full text-left px-2.5 py-2 rounded hover:bg-slate-800 text-slate-100 flex items-start gap-2 cursor-pointer transition-colors mt-0.5"
                  >
                    <Terminal className="w-3.5 h-3.5 text-cyan-400 mt-0.5 shrink-0" />
                    <div>
                      <div className="font-semibold text-cyan-300 text-xs">Run in Terminal</div>
                      <div className="text-[10px] text-slate-400">Execute in multi-language CLI (Python, Node, GCC, etc.)</div>
                    </div>
                  </button>
                </div>
              )}
            </div>
          )}

          {/* Quick Format */}
          <button
            onClick={handleTriggerFormat}
            className="p-1.5 rounded hover:bg-slate-800 text-slate-400 hover:text-cyan-300 transition-colors cursor-pointer"
            title="Format Document (Shift+Alt+F)"
          >
            <Wand2 className="w-3.5 h-3.5" />
          </button>

          {/* In-Editor Find */}
          <button
            onClick={() => setShowSearch(!showSearch)}
            className={`p-1.5 rounded transition-colors cursor-pointer ${showSearch ? 'text-cyan-400 bg-slate-900' : 'text-slate-400 hover:text-slate-200'}`}
            title="Find & Replace (Ctrl+F)"
          >
            <Search className="w-3.5 h-3.5" />
          </button>

          {/* Word Wrap */}
          <button
            onClick={() => onUpdateSettings({ wordWrap: !settings.wordWrap })}
            className={`p-1.5 rounded text-xs transition-colors cursor-pointer ${settings.wordWrap ? 'text-cyan-400 bg-slate-900' : 'text-slate-400 hover:text-slate-200'}`}
            title="Toggle Word Wrap"
          >
            <AlignLeft className="w-3.5 h-3.5" />
          </button>

          {/* Copy File Content */}
          <button
            onClick={handleCopyContent}
            className="p-1.5 rounded text-slate-400 hover:text-slate-200 hover:bg-slate-800 transition-colors cursor-pointer"
            title="Copy file contents"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
          </button>
        </div>
      </div>

      {/* VS Code Breadcrumb Bar */}
      <div className="h-6 bg-slate-950/70 border-b border-slate-800/60 px-3 flex items-center justify-between text-[11px] text-slate-500 font-mono select-none">
        <div className="flex items-center gap-1.5">
          <span>workspace</span>
          <span>&rsaquo;</span>
          {activeFile.path.split('/').map((seg, i, arr) => (
            <React.Fragment key={i}>
              <span className={i === arr.length - 1 ? 'text-slate-300 font-semibold' : 'text-slate-500'}>
                {seg}
              </span>
              {i < arr.length - 1 && <span>&rsaquo;</span>}
            </React.Fragment>
          ))}
        </div>

        <div className="flex items-center gap-2">
          <span className="text-[10px] px-1.5 py-0.2 rounded bg-slate-900 text-cyan-400 font-semibold uppercase">
            {activeFile.language}
          </span>
        </div>
      </div>

      {/* GitLens Active Line Blame Bar (when enabled) */}
      {isGitLensEnabled && (
        <div className="h-6 bg-slate-950/90 border-b border-slate-800/60 px-3 flex items-center gap-2 text-[11px] text-slate-500 font-mono select-none">
          <GitCommit className="w-3 h-3 text-cyan-400" />
          <span className="text-slate-400">MR00100 Author</span>
          <span>&bull;</span>
          <span>committed 2 hours ago</span>
          <span>&bull;</span>
          <span className="text-cyan-300/80 truncate">feat: enhance responsive IDE workflow</span>
        </div>
      )}

      {/* Symbol Rename Modal Overlay */}
      {isRenamingSymbol && (
        <form
          onSubmit={handlePerformRename}
          className="absolute top-10 right-4 z-40 bg-slate-900 border border-cyan-500/50 rounded-lg p-2.5 shadow-2xl space-y-2 text-xs w-72"
        >
          <div className="font-semibold text-slate-200 flex items-center justify-between">
            <span>Rename Symbol</span>
            <button
              type="button"
              onClick={() => setIsRenamingSymbol(false)}
              className="text-slate-400 hover:text-slate-200"
            >
              <X className="w-3 h-3" />
            </button>
          </div>
          <input
            type="text"
            value={oldSymbol}
            onChange={e => setOldSymbol(e.target.value)}
            placeholder="Target identifier (e.g. count)..."
            className="w-full bg-slate-950 border border-slate-800 rounded px-2 py-1 text-slate-200 font-mono text-xs focus:outline-none focus:border-cyan-500"
            autoFocus
          />
          <input
            type="text"
            value={newSymbol}
            onChange={e => setNewSymbol(e.target.value)}
            placeholder="Replacement identifier..."
            className="w-full bg-slate-950 border border-slate-800 rounded px-2 py-1 text-slate-200 font-mono text-xs focus:outline-none focus:border-cyan-500"
          />
          <button
            type="submit"
            className="w-full py-1 bg-cyan-600 hover:bg-cyan-500 text-white font-medium rounded text-xs transition-colors cursor-pointer"
          >
            Refactor & Replace
          </button>
        </form>
      )}

      {/* In-Editor Find & Replace Bar */}
      {showSearch && (
        <div className="bg-slate-900 border-b border-slate-800 px-3 py-1.5 flex items-center gap-2 text-xs shrink-0 z-30">
          <div className="flex items-center gap-1.5 flex-1">
            <Search className="w-3.5 h-3.5 text-cyan-400" />
            <input
              type="text"
              value={searchText}
              onChange={e => setSearchText(e.target.value)}
              placeholder="Find in file..."
              className="bg-slate-950 border border-slate-800 rounded px-2 py-0.5 text-xs text-white focus:outline-none focus:border-cyan-500 w-44"
              autoFocus
            />
            <input
              type="text"
              value={replaceText}
              onChange={e => setReplaceText(e.target.value)}
              placeholder="Replace..."
              className="bg-slate-950 border border-slate-800 rounded px-2 py-0.5 text-xs text-white focus:outline-none focus:border-cyan-500 w-44"
            />
            <button
              onClick={() => {
                if (!searchText) return;
                const updated = activeFile.content.replaceAll(searchText, replaceText);
                onContentChange(activeFile.id, updated);
              }}
              className="px-2 py-0.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded text-xs transition-colors"
            >
              Replace All
            </button>
          </div>
          <button
            onClick={() => setShowSearch(false)}
            className="text-slate-400 hover:text-slate-200 p-1"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Main Code Editing Canvas with Line Numbers */}
      <div className="flex-1 flex overflow-hidden relative font-mono text-sm leading-6">
        {/* Line Numbers Gutter */}
        <div 
          className="w-12 bg-slate-950 border-r border-slate-800/80 py-3 text-right select-none shrink-0 overflow-hidden text-slate-600"
          style={{ fontSize: `${settings.fontSize}px`, lineHeight: `${Math.round(settings.fontSize * 1.5)}px` }}
        >
          {lines.map((_, idx) => {
            const lineNum = idx + 1;
            const hasBreakpoint = breakpoints.some(b => b.file === activeFile.path && b.line === lineNum && b.enabled);
            const isCurrentLine = cursorPos.line === lineNum;

            return (
              <div
                key={idx}
                onClick={() => onToggleBreakpoint(activeFile.path, lineNum)}
                className={`group relative pr-2.5 cursor-pointer transition-colors flex items-center justify-end gap-1 ${
                  isCurrentLine ? 'text-slate-300 font-semibold' : 'hover:text-slate-400'
                }`}
              >
                {hasBreakpoint ? (
                  <span className="w-2.5 h-2.5 rounded-full bg-rose-500 shadow-sm shadow-rose-500/50" />
                ) : (
                  <span className="w-2.5 h-2.5 rounded-full bg-rose-500/0 group-hover:bg-rose-500/40 transition-colors" />
                )}
                <span className="tabular-nums">{lineNum}</span>
              </div>
            );
          })}
        </div>

        {/* Synchronized Highlighting & Input Wrapper */}
        <div className="flex-1 relative h-full overflow-hidden">
          {/* Syntax Highlighted HTML Backdrop */}
          <pre
            ref={preRef}
            aria-hidden="true"
            className="absolute inset-0 p-3 m-0 overflow-auto pointer-events-none select-none font-mono whitespace-pre"
            style={{ 
              fontSize: `${settings.fontSize}px`, 
              lineHeight: `${Math.round(settings.fontSize * 1.5)}px`,
              whiteSpace: settings.wordWrap ? 'pre-wrap' : 'pre',
            }}
            dangerouslySetInnerHTML={{ __html: highlightedHtml }}
          />

          {/* Transparent Input Textarea */}
          <textarea
            ref={textareaRef}
            value={activeFile.content}
            onChange={e => onContentChange(activeFile.id, e.target.value)}
            onScroll={handleScroll}
            onKeyUp={updateCursorPosition}
            onClick={updateCursorPosition}
            onKeyDown={handleKeyDown}
            spellCheck={false}
            autoCapitalize="off"
            autoComplete="off"
            autoCorrect="off"
            className="absolute inset-0 p-3 m-0 bg-transparent text-transparent caret-cyan-400 font-mono resize-none focus:outline-none z-10 selection:bg-cyan-500/20"
            style={{ 
              fontSize: `${settings.fontSize}px`, 
              lineHeight: `${Math.round(settings.fontSize * 1.5)}px`,
              whiteSpace: settings.wordWrap ? 'pre-wrap' : 'pre',
            }}
          />
        </div>
      </div>

      {/* Editor Status Bar */}
      <div className="h-6 bg-slate-950 border-t border-slate-800/80 px-3 flex items-center justify-between text-[11px] text-slate-400 select-none shrink-0 font-mono">
        <div className="flex items-center gap-3">
          <span className="hover:text-slate-200">
            Ln {cursorPos.line}, Col {cursorPos.col}
          </span>
          <span>&bull;</span>
          <span>Spaces: {settings.tabSize}</span>
          <span>&bull;</span>
          <span>UTF-8</span>
          {isGitLensEnabled && (
            <span className="text-cyan-400 hidden sm:inline">&bull; GitLens Active</span>
          )}
        </div>

        <div className="flex items-center gap-3">
          {fileDiagnostics.length > 0 && isEslintEnabled && (
            <div className="flex items-center gap-1 text-amber-400">
              <ShieldAlert className="w-3 h-3" />
              <span>{fileDiagnostics.length} issue{fileDiagnostics.length === 1 ? '' : 's'}</span>
            </div>
          )}
          <span className="text-cyan-400 uppercase">{activeFile.language}</span>
        </div>
      </div>
    </div>
  );
};
